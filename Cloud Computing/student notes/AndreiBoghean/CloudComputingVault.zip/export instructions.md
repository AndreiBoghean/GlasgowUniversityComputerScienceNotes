export everything in A5 with betterExportPDF.
most things at 100% scale, except the following:
lecture 4 at 90%

afterwards; use browser print to pdf and do 9 pages per page
and then actually print.