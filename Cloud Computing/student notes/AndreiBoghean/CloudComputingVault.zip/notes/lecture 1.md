# cloud computing intro
## clusters, grids, clouds, edge/fog
**clusters**: many *locally connected* computers
**grids**: *loosely coupled and widely distributed* computers or clusters
**clouds**: IT resources as a *utility*
**edge/fog**: *cloud services* in *closer proximity to users* and edge devices.
##### clusters
- mostly homogeneous compute **resources** and **software stacks** viewed as *one system*
	  - the *homogeneous nature is a commodity*.
- interconnected by a **low-latency** and **high-bandwidth** *(local area) network*
- aims to *improve availability*, resource utilisation, price/performance
e.g. analytics clusters at google, microsoft, meta, alibaba, amazon, etc.
##### grids
grids are **widely distributed** *heterogeneous* compute resources.
- connected via a *slow* network. (i.e. the internet)
heterogeneous software stacks are unified by a **middleware**
they are used for a *common goal*.

e.g. *worldwide LHC computing grid (WLCG)* or *berkely open infrastructure for network computing (BOINC)*
##### clouds
according to NIST (National Institute of Standards and Technology)...
"Cloud computing is a model for enabling **ubiquitous**, *convenient*, **on-demand** *network access to a **shared pool*** of *configurable* computing resources (e.g. networks, servers, storage, applications, and services) that can be *rapidly provisioned* and released with **minimal management effort** or service provider interaction"
- this cloud model is **composed of** *five essential characteristics*, *three service models*, and *four deployment models*
###### clouds and IOT
![[Pasted image 20250501160755.png|400]]
##### edge/fog computing
![[Pasted image 20250501160827.png|400]]
- this is all u get lmafoo good luck
## dimensions the NIST definition
recall the NIST definition of clouds from the above [[#clouds]]
### overview of NIST
````col
```col-md
flexGrow=1
===
NIST states the *cloud model is composed of*
1. 5 essential characteristics
2. 3 service models
3. 4 deployment models
```
```col-md
flexGrow=1
===
![[Pasted image 20250501162542.png|200]]
```
````
### the five characteristics of cloud computing
**on-demand self-service**: *no human* required for resource provisions; fully automated.
**broad network access**: *accessible over networks* with standard mechanisms
**resource pooling**: *dynamically shared resources* among consumers, with *location independence*
**rapid elasticity**: capabilities can be *provisioned/released* **on demand**
**measured service**: resource usage is *monitored, controlled, and reported*.
### the three service models
==**software as a service** (*SaaS*)==
- **provider** has *an application on cloud infrastructure* that can be accessed over the *network*
- consumer **does not** *control/mange underlying infrastructure*
==**platform as a service** (*PaaS*)==
- consumer can deploy ***custom** application* onto cloud infrastructure using *programming languages*, *libraries*, *services*, and *tools* **supported by the provider**.
- consumer **does not control/manage** the *underlying infrastructure*
==**infrastructure as a service** (*IaaS*)==
- provider provides *processing*, *storage*, and *network* **resources** to consumer
- consumer **does not control/manage** underlying *infrastructure*, but **can control** *OS*, *storage*, *deployed applications*

### the four deployment models

|                                 | private cloud                                  | community cloud                                 | public cloud                                                     | hybrid cloud                                                       |
| ------------------------------- | ---------------------------------------------- | ----------------------------------------------- | ---------------------------------------------------------------- | ------------------------------------------------------------------ |
| user of the infrastructure?     | single organisation                            | organisations with shared concerns              | open for the general public                                      | *composition of private/community/public cloud*                    |
| owner of the infrastructure?    | organisation, third party, combination thereof | organisations, third party, combination thereof | business, academic, government organisation, combination thereof | clouds remain distinct, but bound together by standard mechanisms. |
| location of the infrastructure? | *on* or *off* prem                             | *on* or *off* prem                              | on prem of cloud provider                                        | the general goal is to enable portability.                         |
##### public cloud examples
**AWS EC2**, *DigitalOcean Droplets*, **Google Kubernetes Engine**, *AWS S3*, **Amazon EMR**, *AWS Lambda*, **Azure Machine Learning Studio**, *AWS SageMaker*, **IBM Watson**, *Google Mail; Google Docs; MS Office 365*
## intro to virtualisation
### virtualisation justification / challenges providers face
**rapid provisioning**:
- resources must be available to the consumer *quickly*
- *no human interaction* during provisioning, since **humans are slow**.
**elasticity**
- create illusion of *infinite resources*
- yet, manage the data centre in a *cost-efficient* manner
**performance**
- maintain good performance *despite other challenges*
### approach for these challenges: virtualisation.
#### what is virtualisation?
##### general idea
on an IaaS level, the idea is to provide *virtual* resources.
- provide compute resources in the form of **virtual machines** and **containers**
- also other computing resources such as *virtual* **networks**, *virtual* **network functions**, *virtual* **storage**
note that it is by definition a form of cloud computing, since it provides network access to a *shared pool of configurable computing resources* that can be *rapidly and easily provisioned/released*.
##### NIST definition
"virtualisation is the simulation of the software and/or hardware upon which other software runs. this simulated environment is called a virtual machine (VM)"
virtualisation can transform a real system such that:
- it looks like a different virtual system
- multiple virtual systems

the **real system** can be referred to as the **host system**, and the *virtual system* is the *guest*.
##### formal mathematical definition
![[Pasted image 20250501190030.png|300]]
isomorphism V:
- Si, Sj: the states of the machine
- e: sequence of operations
isomorphism V maps guest state to host state such that:
- for e that modifies the guest's state from Si to Sj..
  there exists a corresponding sequence of operations e' that performs an equivalent modification between host's states (S'i to S'j)
### categories of virtualisation
![[Pasted image 20250501190228.png|400]]

![[Pasted image 20250501190250.png|400]]
## intro to VMs and containers
### virtual machines
#### virtual machines overview
in a VM, the "hardware" it's using is virtual; but maps to real hardware on the host OS.
processes on the VM run on a machine that is software simply pretending to be hardware.

VMs can have *different hardware characteristics* (including different from the physical host)
- e.g. number of cores, assigned memory, disk space

VMs are often started from available **images**
- these images usually contain an OS and some apps installed.
- e.g. windows with SQL enterprise
#### virtual machine use cases
1. run a different operating system than installed on the host operating system
2. operating multiple isolated environments on a host (e.g. phone user accounts)
3. pool of resources shared by multiple users and applications in a private cloud
4. virtual machines available in a public cloud (AWS)
### containers
#### overview
containers are a more lightweight approach to virtualisation.
each application has a virtual environment, and processes run in *isolation* but **within** an *OS*
- containers rely on containment features of the OS kernel (e.g. *chroot*, *cgroups* in linux)

containers can have *different sizes*, are usually *started from images*, and can *run on cloud services*
#### use cases
use cases can include **isolating applications** on the same host from each other
- allowing them to still **share/pool resources effectively, useful e.g. in a cluster**
or the ability to *bundle dependencies and the environment* (libs and config) to **ship software**.
- so you can develop on a host, but then use a container for staging/production
### containers vs VMs
**containers**:
- *no virtual hardware*; if your application is not built for the hardware of your container host then RIP.
- *reduced scope*; single application in pre-build environments
- *reduced isolation*; they may be isolated on process-level, but **still share the kernel**.
- live migration of containers is less mature
**VMs**:
- *larger images*
- slower VM *startup*
- *more overhead* per VM on a physical node