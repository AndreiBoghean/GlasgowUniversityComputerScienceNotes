# virtual machines
## virtualisation
### basic designs for system virtualisation
#### virtualisation types overview
````col
```col-md
flexGrow=1
===
VMM type 1
- runs directly on hardware
- has a "basic OS" to run the VMs
- more *efficient*
- requires **special device drivers**
![[Pasted image 20250502104633.png]]
```
```col-md
flexGrow=1
===
VMM type 2
- VMM as host OS process
- VM processes are supported by VMM
- no *special drivers* needed
- more **overhead**
![[Pasted image 20250502105749.png]]
```
````
#### virtualisability (VMM type 1)
there is a fundamental problem for system virtualisation:
- the VMM must have *ultimate control* over hardware.
- guest operating system must be *disempowered* without noticing

four assumptions in analysis of popek and goldberg:
1. one processor and uniformly addressable memory
2. two processor modes: system and user mode
3. subset of instruction set only available in system mode
4. memory addressing is relative to relocation register

##### preface - categories of processor instructions
````col
```col-md
flexGrow=1
===
###### privileged instructions
1. can only be executed in system mode
2. trap when the processor is in user mode

examples of privileged instructions are:
- load PSW (S/370) : 1 bit to indicate system mode; malicious program may modify it.
- set CPU timer (S/370) : defines when user code loses CPU.
![[Pasted image 20250502120139.png]]
```
```col-md
flexGrow=1
===
###### sensitive instructions
- **control-sensitive** instructions: change configuration of resources.
- **behaviour-sensitive** instructions: behave different depending on configuration of resource

e.g.
- load real address (S/370)
- pop stack into flags register (IA-32)
![[Pasted image 20250502120124.png]]
```
````

##### recap - IA-32 architectures
IA32 uses *rings* to manage **privileges**
- *four* different code privileges possible
- designed as a generalisation of two processor modes
- for portability, only ring 0 and ring 3 are used in practice.
![[Pasted image 20250502120819.png|450]]

#### popek and goldberg's theorem
##### definition
their theorem is a basic *condition* **for** the construction of *efficient* VMMS.
- "... a virtual machine monitor may be constructed if the set of **sensitive instructions** for that computer is a **subset** of the set of **privileged instructions**"
![[Pasted image 20250502121700.png|400]]
##### implications
an efficient VMM is one where all **non-sensitive** instructions run ***natively** on the processor*.
you use *trap and emulate*: when the guest OS calls a sensitive instruction..
1. the instruction traps to the VMM
2. the VMM emulates the instruction operation
![[Pasted image 20250502121903.png|500]]
##### requirements in practice
which ISAs satisfy popek and goldberg's requirement? *IBM Power* **,** *sun Sparc*
which dont? *Arm* **,** *Intel IA-32*
IA-32 has ~17 critical instructions that are sensitive but not privileged.
- such critical instructions **do not trap**, since they're not privileged, but *can operate differently if not executed in system mode*.

#### virtualisation of IA-32 architectures
there are 3 options to consider:
1. *full virtualisation* using binary translation
2. *OS-assisted* virtualisation
3. *hardware-assisted* virtualisation
## full virtualisation (with binary translation)
the idea here is to find critical instructions and replace them.
1. run *unprivileged* instructions directly on CPU.
2. *trap and emulate* **privileged** instructions
3. find **critical** instructions and replace them with an *exception*.

whether an instruction is **critical** or not can depend on *parameters used*
- (e.g. LOAD instruction)
thus **replacement must be done at runtime**
- however, translating a book word for word is inefficient.

![[Pasted image 20250502123718.png|250]]

### basic approach for binary translation
1. **separate instruction sequence** into *translation units*
2. *check units* for **critical instructions** and modify code
3. modified code in stored in *translation cache*
translation is done lazily; some units may never be translated; some are frequently translated and in fact benefit from the translation cache.
![[Pasted image 20250502124245.png|500]]

### memory management and full virtualisation
#### preface - memory management on IA-32 architecture
IA-32 uses page tables.
- hardware knows the layout of page tables
- OS modifies the page table, and lookup happens transparently

page tables *reside in main memory*, meaning *overhead of memory access essentially doubles*.
- to check an mem addr, first retrieve page tables, and then  retrieve the mem address.

idea: introduce special *hardware-accelerated cache* to *remember recent address translations*
- the TLB.

#### preface: translation lookaside buffer (TLB)
the TLB acts as a cache of the MMU.
- typically fast (~1 cycle hit time) with a good hit rate (>99%)

on IA-32, the TLB is invisible to the operating system.
- it's **updated by  the hardware** on *every page table lookup*, and *flushed on every context switch*.
![[Pasted image 20250502130008.png|500]]

#### how VMs work with a TLB
![[Pasted image 20250502130113.png]]
the problem with this is that **additional memory access is required to resolve address**.

a practical implementation may include *shadow page tables*
1. the guest OSs maintain their own page tables (for compatability)
2. modifications to guest's page table trap, and entries are subsequently copied to the VMM's shadow page table.
3. shadow page table is then used by hardware.
	   - keeps TLB up to date
	   - works through virtualisation of page table pointer.
![[Pasted image 20250502172109.png]]
### levels of IO virtualisation
1. at the system call level
2. at the device driver level
3. at the IO operation level
##### device driver level
````col
```col-md
flexGrow=1
===
1. VMM intercepts calls to virtual device driver
2. converts virtual device info to corresponding physical device
3. redirects calls to the physical device's driver.
- pro: natural point for virtualisation. no "reverse engineering" required
- con: requires knowledge of guest's device driver interface
- pro: works in practice (e.g. for linux and windows guests)
```
```col-md
flexGrow=1
===
![[Pasted image 20250502172857.png|200]]
```
````
### summary
requires a modified guest OS? no.
requires hardware support? no

performance:
- fine for compute-intensive applications
	  since unprivileged instructions run directly on the CPU
- decreased performance for data-intensive applications
	  - IO requires syscalls -> privileged instructions & traps
	  - "trap and emulate" often requires context switches
	  - context switches lead to flush of TLB, etc.
## OS (and hardware) assisted virtualisation
### OS assisted virtualisation
the idea of OS-assisted virtualisation, you inform the guest OS it's running in a VM.
- do this by modifying the guest source code so it avoids assistance of the VMM as far as possible

today, most virtualisation platforms are aware of using virtual devices
(-> OS-assisted virtualisation for IO)

requirements for a (pure) os-assisted approach are:
- source code of guest OS is available
- modified guest OS maintains an application binary interface.

#### OS-assisted virtualisation in practice - **Xen**
XEN is a classic representative for OS assisted virtualisation.
- type I hypervisor
- available as open-source software
- originally developed at the university of cambridge, UK, on collaboration with microsoft research cambridge.

prime example for paravirtualisation, but can also be used to run unmodified guest kernels using HW-assisted virtualisation.

##### architecture and domains
###### domains
![[Pasted image 20250502180422.png|450]]
- Domain 0: privileged guest for control/management
- Domain U: guest with xen-enabled OS

###### CPU virtualisation
critical instructions do not trap on IA-32
- the guest OS is **aware of virtualisation** -> *critical instructions can be avoided*.
still, **frequent VMM intervention is required** e.g. for *system calls and page table updates*.
however XEN *minimises frequencies and costs*.
- some system calls to guest OS (ring 1) are possible without VMM intervention (registering guest OS handlers with XEN)
- mapping **hypervisor code into process address spaces**
  (so *hypercalls do not require context switches*)
- **command batching** (e.g. *subsequent* page table updates)

###### physical memory
![[Pasted image 20250502181309.png|450]]
the domain gets a **slice of physical memory** *at creation time*.
- static partitioning among domains
- no guarantee that partition is *contiguous*
- hypervisor knows which domain "owns" which pages

XEN then ***lets guests maintain their own page tables***
- requires the guest OS *knows it's fraction of physical memory*
- guest page tables are used by the **guest's MMU**
- XEN *validates page table updates* to ensure isolation
- no need for *hypervisor intervention* on **reads**

the procedure for writes is:
1. the guest requests page table updates via a hypercall
2. XEN checks if the mapping address belongs to the domain
3. if okay, allows the update to the page table.

###### IO virtualisation
in XEN:
1. presents virtual devices
2. domains use lightweight virtual device drivers,
3. physical device drivers reside in dom0

communication between XEN and domains consists of:
- hypercalls; *synchronous calls from a domain* to XEN
- events; **asynchronous notifications from XEN** to a domain.
![[Pasted image 20250502181719.png|450]]

#### OS-assisted virtualisation summary
requires a modified guest OS? yes.
requires hardware support? no.

pros: better performance through cooperation between the hypervisor and guest OS.
cons:
- limited compatability and not generally applicable
- increased management overhead for data center operator as different version of OS must be maintained.

### hardware assisted virtualisation
most virtualisation difficulties are caused by the design of IA-32.
- sensitive instructions not always trapping when in rings > 0
- guests can observe that they are not running in ring 0

however the success of VMware has demonstrated a demand for virtualisation.
so, idea: extend IA-32 architecture to *circumvent hardware virtualisation obstacles*.
- *independent developments by **Intel** and **AMD***, yet developments *share the same basic ideas*.

#### CPU virtualisation extensions
````col
```col-md
flexGrow=2
===
2 new CPU modes: *root* mode vs *guest* mode.
- the VMM runs in root mode, and guest in guest mode.

the VMM and guest run as "co-routines"
- the VMM can **give CPU** to the guest OS (VM ENTER)
- the VMM can **define conditions** for when to regain CPU (VM exit)
```
```col-md
flexGrow=1
===
![[Pasted image 20250502183342.png|200]]
```
````

#### VMM control structures
VMM controls the guest through a **hardware-defined structure**
- intel: VMCS (*virtual machine control structure*)
- AMD: VMCB (*virtual machine code block*)

VMCS/VMCB contains:
- guest state
- control bits defining *criteria for **VM EXIT*** 
	  - exit on IN, OUT, CPUID
	  - exit on write to page table register
	  - exit on page fault, interrupt, etc.
- VMM uses control bits to **"confine" and observe** the guest.

#### memory virtualisation extensions
extended/nested page tables
![[Pasted image 20250502183726.png]]
LA: Logical Address, RA: Real Address, PA: Physical Address
#### tagged TLB
the translation lookaside buffer continues to cache LA -> PA address translation

both intel and AMD introduced tagged TLBs.
- every TLB entry is associated with an **address space tag**.
- therefore only *some* entries are invalid on a context switch.

![[Pasted image 20250502183918.png|350]]

#### focus of HW-support for IO: direct assignment.
direct assignment means the guest VM **owns** a *physical device*.
- **no sharing** of the device between several VMs.
- guest VMs run the *unmodified* device drivers
- goal: **efficient IO** without VMM intervention
- challenge: VMM must still ensure **corectness & isolation**.

![[Pasted image 20250502184312.png]]

#### summary of hardware-assisted virtualisation
requires modified guest OS? no.
requires hardware support? yes.

pro: improved performance even for *unmodified guest OSes*.
con: specialised hardware required and reduced flexibility due to hardware constraints.
## resource isolation and performance implications
in commercial IaaS clouds, many VMs often run on the *same physical hardware*.
consier:
- how are resources of a physical node shared?
- how is fairness enforced?
- what are the implications of resource sharing?

##### resource distribution among VMs
**storage space**: *statically* partitioned
- each VM typically receives a pre-defined fraction of disk
**main memory**: *statically* partitioned
- each VM typically receives a pre-defined fraction of RAM
**CPU**: different methods possible
- ==pinning==; each VM is statically assigned CPU cores
- ==scheduling==: VMM dynamically assigns time slots to VMs
**IO access**: typically, *FCFS*.
- more sophisticated methods subject to research.

###### CPU scheduling
goal of the schedulers:
- each VM should receive a "fair" share of the CPU
- maintain a high CPU utilisation
- low response times

different algorithms are available, e.g. for XEN, including:
- a general-purpose scheduler
- a scheduler for latency-sensitive jobs
- several experimental real-time schedulers
- ...

###### CPU scheduling and shared IO
currently, VM scheduling focuses on CPU.
this results in good fairness/response time for compute-intensive applications,
however processing of IO requests by the VMM also consumes CPU time.
-  in particular when IO is bursty
- guest OSes are unaware of that source of processing delay.
- perceived as high delay variations by the guests, and negatively impacts performance.
## case study: amazon EC2 / AWS
public IaaS cloud by amazon web services
- subsidiary of amazon Inc, launched in 2006, most used cloud platform today

AWS encompasses a large number of services
- **Computing**: *CS2, lambda* | **storage**: *S3, ECB* |
- **databases**: *RDS, DynamoDB* | **analytics**: *EMR, SageMaker*

##### geographic distribution of EC2 data centers
![[Pasted image 20250502190231.png|500]]
- amazon calls each geographic location a *region*.
- regions are again divided into *availability zones*
- *intra*-availability zone **traffic is free** of charge
- per-GB **fee** for inter-availability zone/*inter-region traffic*.

##### EC2 per-hour pricing model
there is a per-time pricing model (hence the term "elastic")
- amazon charges a fee for each started hour of VM usage.
- customer can shutdown VMs at anytime.
	  - no long-tern obligations, reduced risk of over/under provisioning.

the concrete per-hour cost depends on several factors
- region
- virtual machine type (EC2 calls these instance types)
- OS, image (potential license costs)
- usage of external services (EBS, internet traffic, ...)

##### EC2 instance types
instance types define VM classes with particular hardware characteristics

| instace                                    | t2 small  | t2 medium | t2 large | t2 xlarge |
| ------------------------------------------ | --------- | --------- | -------- | --------- |
| compute power<br>(virt cores / comp units) | 1, 1      | 1, 2      | 2, 4     | 4, 8      |
| main memory                                | 2 GiB     | 4 GiB     | 8 GiB    | 16 GiB    |
| storage                                    | via EBS   | via EBS   | via EBS  | via EBS   |
| platform                                   | 32/64 bit | 32/64 bit | 64 bit   | 64 bit    |
| price                                      | $0.02     | $0.05     | $0.09    | $0.19     |

the "EC2 compute unit" is an ==abstract unit for compute power==
- one compute unit corresponded to a 1.0-1.2GHz AMD opteron or intel xeon of 2007
- introduced as a reference measure, allowing predictability, with different generations of HW inside data centers.

schad et al. examined EC2 performance variance and found
- instances of the same type may be hosted on different generations of hardware
- possible for *significant performance variants* across different instances of **the same type**.

## virtual machines summary
IaaS clouds let consumers rent basic IT resources in the form of a virtual machine.
- customers have full control over OS and the deployed applications in VMs.

system virtualisation enables the method.
- several customers can **share physical infrastructure**
- **different techniques** to realise system virtualisation
- *performance overhead* depends on *specific virtualisation technique, application, and hardware*.