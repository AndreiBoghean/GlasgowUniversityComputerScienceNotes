# containers
## containerisation intro (a.k.a. *OS-level virtualisation*)
system virtualisation comes with too much overhead, large images, and long boot times.
to get around this, containers dont create VMs but instead..
1. reuse the OS kernel, *still isolating applications*
2. *virtualise access* to resources used by processes
	   - (file system, devices, network, other processes, e.g.)

##### background: history of OS-level virtualisation
unix v7 chroot system call (1979)
- allows setting the filesystem root for processes
- unix  philosophy: (almost) everything is accessed through the file system -> (almost) everything can be virtualised through **chroot**
wave of container technologies in early 2000s:
- freeBSD, jails, linux VServer, solaris zones, etc.
- different degrees of isolation, different tool chains
- mostly specific to linux distributions
- not widely popular, mainly used by sys admins in large companies.

###### more history
LXC (2008)
- userspace tools 4 using linux kernel **process isolation features** (*cgroups* and *namespaces*)
Docker (2013)
- most widely used container technology and ecosystem
Rocket (CoreOS, 2014)
- alternative to docker; more focused on security and standardisation
LXD (Canonical, 2014)
- image-based, focused on entire linux distributions
Ubuntu Snap (Canonical, 2018)
- universal packaging format for linux distros
## linux containment features
the linux kernel features mechanisms to help process isolation:
- ==chroot, namespaces, capabilities, cgroups, SELinux&seccomp, etc.==
some of these have *partially overlapping functionality*, yet **different** *configuration approaches*.
##### chroot
````col
```col-md
flexGrow=3
===
this is the oldest mechanism for process isolation.
it's the system call  that changes the root directory ("/") of the *calling process*
- since "**everything is a file**" in linux, many aspects of the underlying system can *therefore be easily virtualised*.
- system calls, networking, etc. however remain unchanged.
```
```col-md
flexGrow=1
===
![[Pasted image 20250503122627.png]]
```
````
##### namespaces
namespaces provide separate views on *kernel resources* for **processes**
they can be used to isolate:
- **PID (prcesses)**, *IPC (inter-process communication)*, **Network (devices, protocol stacks, firewalls, ports, etc.)**,  *Mount (mount points, fs structure)*, **User (users and groups)**, *UTS (hostname and domain name)*
###### namespaces example
suppose you have a container with which you want to
*==share==* *users and hostname*, but **==isolate==** **processes, network, and mount points**.
you can do that like this:
![[Pasted image 20250503123324.png|500]]
##### linux capabilities
traditionally, the super user (root) has *exclusive privileges for administrative tasks* on a system.
linux capabilities allow you to assign *select* **rights** to new processes.
the list of capabilities is long, including:
- many system calls, device access, fs modifications, etc.
##### cgroups (control groups)
cgroups allow the definition of resource usage *constraints* for **parts of the process tree**.
- used for limiting CPU, RAM, network, and disk usage for containers.
![[Pasted image 20250503124545.png|500]]
##### security policies (SELinux & seccomp)
###### SELinux
SELinux, AppArmor are optional kernel modules for *security*.
- allow **rule-based confinement** to *limit **process** access to certain files and devices* **only**.
SELinux - complex, but *powerful* rule definitions
AppArmor - simpler *security profiles*
###### seccomp policies
the *seccomp* system call puts the process into a **secure computation mode**,
where **only** *selected system calls are allowed*.
## container technologies (e.g. LXC & docker)
container technology examples include
- LXC - the first container technology widely adopted
- docker - the currently most widely used container platform and ecosystem
### LXC containers
LXC uses library and userspace tools (scripts) to access **kernel process isolation features**.
*there is no daemon*, instead containers and their filesystems are accessible via `var/lib/lxc`
![[Pasted image 20250503125452.png|450]]
#### container creation
1. a *container directory is allocated* under /var/lib/lxc
2. the "*template script*" is executed to populate the fs of the container.
3. a *process is spawned* and **chrooted** into it's file system.
4. **process isolation** is *configured*
5. the **main application process** is spawned; *all child processes inherit **isolation context***

LXC does not rely on an image format.
there is not much infrastructure for sharing images.
### docker
docker is popular. docker includes:
- a **daemon** and **user space tools** for *managing local containers* and images
- *hierarchical image format*
- *build tool* for images (*Dockerfiles*)
- private and public *repositories* for sharing images (**Dockerhub**)
- internal and external tools for *automatic orchestration* of **container infrastructures**.

#### docker components
![[Pasted image 20250503130457.png]]
#### docker instances, images, and files
````col
```col-md
flexGrow=2
===
containers *share a single OS kernel*, but they're all **isolated** by *kernel containment features*

a ==container instance== is a running isolated process that's been started from an image
a ==docker image== is a **container snapshot**, packaging the *application, dependencies, and config*.
a ==dockerfile== is a file specifying instructions for creating images.
```
```col-md
flexGrow=1
===
![[Pasted image 20250503130839.png]]
```
````
##### dockerfiles
a docker file is a file specifying the process for creating container images.
it's a text file with commands that modify files or change configuration.
**intermediate steps can be cached**, resulting in reduced image build times.
```dockerfile
FROM ubuntu:18.04
RUN apt install -y nginx
COPY my-nginx.conf /etc/nginx/nginx.conf
ENTRYPOINT /user/sbin/nginx
```

##### docker images
docker images contain:
1. a list of layers
2. an ID (hash of layer IDs and other config data)
3. config data: ports, mounts, env. vars, etc.
4. meta data: creation time, autor, history, etc.

each image **layer** contains:
1. ID of the layer (hash of all files) and ID of parent layer
2. layer files (tarball): files that were **added/changed** on this layer, *relative to parent layer*.
3. command that was used to create the layer
###### docker image format
![[Pasted image 20250503131852.png|500]]
## containers vs VMs
### performance
#### performance - CPU & RAM
![[Pasted image 20250503133107.png|500]]
VMs and containers introduce a low **CPU and memory access overhead**.
- prerequisite: *exposing cache topology and CPU acceleration features* (e.g. NUMA, FPUs, SSE)
#### performance - network
![[Pasted image 20250503133436.png|500]]
there is *low* CPU **overhead** per packet.
reasons for latency increase may include:
- **NAT** in *docker networking*
- **virtual network device** in *KVM* (NAT might *further increase latency*)
#### performance - Disk IO
basically: **native and docker are the same**; *KVM is slightly worse*
![[Pasted image 20250503133715.png|400]]

### image size & boot time
virtual machine images are larger than container cuz they have a whole OS.
however you can use image caching on execution hosts for both VMs and containers.
regardless, boot time of *VMs* can be **orders of magnitude longer** than *container* startup.
### isolation & security
since containers and the host all **share the same kernel**, that then *becomes a point of failure*.
- vulnerable to **linux kernel bugs**
- **DOS attacks**: *resource usage*, *sys calls*, and *context switches* of 1 container can starve others
- ==kernel parameters **cant** be tuned to work around this==.

a VMM has orders of magnitude less code than OS kernels
- implies VMMs should be more scrutinisable? because less code to inspect?
## container orchestration
````col
```col-md
flexGrow=2
===
applications typically consist of **multiple connected components** intended to *run as a single service*.

e.g. a web application with a front-end, back-end, and persistent data store (a.k.a. 3-tier architecture?)
```
```col-md
flexGrow=1
===
![[Pasted image 20250503140145.png]]
```
````
###### preface: container analogy
containers are: **standardised**, *easy to move*, **isolated**, with many *containers fitting on a host*.
*libs and config* are **bundled with the application** to run it everywhere. this lets you
1. build your app in a container
2. test the container locally or in staging
3. and then **simply ship the container**.
###### preface: how to compose containers with docker compose
![[Pasted image 20250503140545.png]]
### design patterns of container composition
#### microservices
````col
```col-md
flexGrow=1
===
###### monolith
![[Pasted image 20250503140731.png]]
```
```col-md
flexGrow=2
===
###### microservices
![[Pasted image 20250503140713.png]]
```
````

| advantages              | disadvantages                              |
| ----------------------- | ------------------------------------------ |
| independent development | overhead (duplicated tech, e.g. databases) |
| small teams             | complexity of services and networking      |
| fault isolation         |                                            |
![[Pasted image 20250503143713.png]]
#### docker cluster
running an application on a cluster of docker hosts for fault tolerance and scalability
![[Pasted image 20250503143837.png]]
#### resource orchestration
orchestration tools: control systems for clusters
![[Pasted image 20250503143917.png|500]]
#### container orchestration 
![[Pasted image 20250503143958.png|400]]
- provisioning and deployment of containers
- configuration and networking of containers
- replication and availability of containers
- monitoring of replicated containers
- load balancing across replicated containers
## orchestration systems (e.g. kubernetes)
###### kubernetes fun facts
- greek for "helmsman" or "pilot", abbreviated "k8s"
- open sourced by google in 2014; V1.0 released july 2015
- google and linux foundation created the **cloud native computing foundation** (*CNCF*) to *make kubernetes an open standard*
- google kubernetes engine (GKE), azure container service (AKS), AWS elastic container service (EKS)

##### what does kubernetes do?
it is an *automation engine* for **cluster management**, based on a *declarative description* of the **desired cluster state**

handles *deployment*, *monitoring*, *recovery*, and *scaling*.
- **instantiating** sets of *containers*
- **connecting containers** through agreed *interfaces*
- **exposing services** to *machines outside* of the cluster
- **monitoring**, **logging**, and **re-starting** **==scheduling==**
- dynamically **scaling** the cluster


##### kubernetes clusters
a k8s cluster is a collection of nodes (bare-metal, or VMs), managed by kubernetes.
they run *groups* of **replicated containers** (called **pods**)

![[Pasted image 20250503144759.png|400]]
##### kubernetes pods
**pods** consist of:
- *groups* of **containers**
- container *configurations*
- *shared storage*

containers in a pod are *scheduled together*, and are guaranteed to be on the same node
pods can also be *replicated*.

##### kubernetes nodes
each worker node in the cluster runs two processes:
1. **kubelet** - an agent that communicates with the k8s master (*master -> cluster nodes*)
2. **kube-proxy** - makes defined services available on each node (*cluster nodes -> master*)

![[Pasted image 20250503145446.png|200]]

##### kubernetes master
the master is a **collection of processes** *managing the cluster state* on a **single node** *of the cluster*.
the master has:
- **controllers** - e.g. replication and scaling controllers
- **a scheduler** - places pods based on resource requirements, hardware + software constraints, data locality, deadlines, etc.
- **etcd** - a reliable distributed *key-value store*, used for the *cluster state*

##### kubernetes services
k8s **services** expose the functionality of *pods*, exposing both *in the cluster* and *to outside*.
e.g. load balancer service.

````col
```col-md
flexGrow=3
===
![[Pasted image 20250503150205.png]]
```
```col-md
flexGrow=2
===
![[Pasted image 20250503150231.png]]
```
````
##### kubernetes cluster state
kubernetes allows you to *specify the state of pods* in a cluster, and then **manages the cluster accordingly**. it strives to achieve the state you specified.

for stateless pods you can use **Deployments**
- doesnt preserve pod state, and doesnt need permanent storage and IDs for networking

or for stateful pods you can use **StatefulSets**
- keeps track of pod state by saving it to storage.
- pods communicate using persistent unique IDs.
- used e.g. for database pods (like mongoDB)

##### kubernetes deployments
you can specify the *deployment* of a **stateless** pod, which *k8s then establishes* (& reestablishes)

##### kubernetes horizontal pod autoscaler
````col
```col-md
flexGrow=3
===
![[Pasted image 20250503152005.png]]
```
```col-md
flexGrow=1
===
![[Pasted image 20250503152210.png]]
```
````
automatically scales the number of pods using the **replication controller**.
does this based on custom metrics or e.g. CPU usage, with target values.
- the autoscaler checks metrics regularly (e.g. every 30 secs) and **scales the replica count** to *optimise the metric* towards the **target value**.

metrics are observed as an average current metric.
if metrics are *within a tolerace* (e.g. <= 0.1), there is no scaling.
- *desiredReplicas* = **currentReplicas** * (**currentMetricValue**/*desiredMetricValue*)
- ^ note that this assumes linear scaling.

the autoscaler scales to the *highest number of desired replicas* in a **sliding window** of *5 minutes*.
- this means a quick response to more load, but reduces *thrashing*.

##### dealing with no metrics
ignore pods that are currently being shut down.
if you have normally running pods with missing metrics..
- if result without these would be to scale *out*: assume the metric to be **0**
- if result without these would be to scale *in*: assume metric to be **1**
also assume a **metric of 0** for *pods that arent ready yet*.

this protocol effectively "dampens" the scaling.

## containers summary
- containers provide an *alternative or supplement to VMs* for *isolating individual applications*.
- containerisation uses *OS kernel containment features* (e..g chroot, namespaces, cgroups)
- docker adds hierarchical images, iamge registries, and dockerfiles.
- can use *container orchestration* 2 manage *distributed, replicated, multi-container* applications.