# cloud infrastructure management
## intro to cloud infrastructure management
### bare-metal servers (the iron age)
running your service on bare-metal servers, there is no configuration capability.
if you need a machine for your frontend, you walk out there and put up a machine.

##### naive assignment
you could either dedicate a machine to a single tier of your service,
or have all of the tiers running on the same machine. (e.g. web, backend, DB)
- problem: servers are *single points of failure*
- problem: *servers not load balanced*; there's potential for **under-utilisation** or **bottlenecks**
	  - if the load is ==dynamic==

##### server consolidation
you could try to (*manually*) merge (valley) your services by putting some layers from different services together on the same node.
- only really feasible within one organisation without isolation (*needs heavy cooperation*)
- this assignment is done **static**, but *loads are still dynamic*, so care must be taken.

### improvement on bare-metal (the cloud age)
with virtualisation using VMs and/or containers, it's easier to deploy your services,
but there still remains many problems with cloud.
- ==**server sprawl**, *config drift*, **snowflake servers**, *tech debt*==
  note: **server sprawl** is basically just *internal fragmentation for servers* (i.e. underutilised)
## cloud operating systems (e.g. OpenStack)
### what are cloud operating systems
![[Pasted image 20250505090818.png|400]]

##### cloud operating systems overview
cloud operating systems help with managing many many virtualisation instances.
- they have many large pools of compute, storage, and networking resources.
- provide dashboards and APIs for *datacenter operators* (**administration**)
  and *users* (**provisioning**) that *abstracts infrastructures* (e.g. **different hypervisors**)

open-source cloud OSes include OpenStack and OpenNebula.
commercial public cloud examples are EC2, GCE, Azure, Alibaba Cloud, Digital Ocean.

##### cloud OSes features
````col
```col-md
flexGrow=2
===
**basic functions**: user interface and APIs for..
- spawning and maintaining VMs
- virtual networking
- managing images and virtual disks
```
```col-md
flexGrow=1
===
**advanced functions**:
- orchestration
- load balancing
- auto-scaling
```
````

##### cloud OS architecture diagram
![[Pasted image 20250505090925.png]]

### what does a managed cloud environment look like
in such an environment,
there are different roles for *physical, compute, storage, network, and controller* **hosts**
![[Pasted image 20250505091107.png|400]]

### OpenStack
open stack is an open source cloud OSm mostly deployed via Iaa, providing virtual machines and other resources to users.
- most **popular** open cloud platform in both *industry* and *academia*
- started in 2010 by Rackspace hosting and NASA
- contributions from IBM, red hat, HP, cisco, googlem oracle, EMC, VMWare

#### core components of OpenStack
![[Pasted image 20250505091334.png]]

![[Pasted image 20250505091348.png]]
##### compute service - nova
nova allows you to create and manage virtual machines on demand from images.
- it *schedules virtual machines* to run on **physical nodes**,
  and *defines drivers* that interact with the underlying virtualisation mechanisms
![[Pasted image 20250505093307.png]]

##### image service - glance
````col
```col-md
flexGrow=1
===
glance is the registry for virtual disk images.
users can add new images to take snapshots of existing VMs.
- snapshots can be used as templates for new servers.
```
```col-md
flexGrow=1
===
![[Pasted image 20250505093413.png]]
```
````
##### block storage service  - cinder
cinder provides *network-backed* **virtual** block storage volumes
- this enables live migration of VMs, and supports replication.

![[Pasted image 20250505094035.png|350]]

##### virtual networking service - neutron
neutron provides an API for networking between *virtual machines* and the *physical network*.
it interconnects virtual machines
- within one hypervisor, between several hypervisors, and within the internet

it also provides additional network functions such as firewalls, VPNs, public IPs, etc.

#### networking in OpenStack
##### preface: virtual switches & software-defined networking (SDN)
virtual switches enable *automation* through **programmatic extensions** and standard protocols (e.g. OpenFlow)

**SDN** aims to simplify network administration by *separating the **control** plane from the **data** plane*, and allowing *on-the-fly* **configuration** of switches (*controller-based decision making*)

##### OpenStack networking diagram
![[Pasted image 20250505094954.png]]
## VM management (and migration)
### management
##### snapshots
a snapshot is a **freeze frame** at a point in time that *saves memory & disk state* of the image.
these are useful for roll-back or migration (and potentially for backups)

virtual snapshots..
- reduce overhead for taking snapshots
- use **copy-on-write** when changing the *original*, allowing it to *store just deltas* (for 1 VM)
- are not ideal for data recovery backups, since they're stored on the same host.
##### suspending/pausing
**suspending**
- the ==full VM state is written to disk==, so only disk resources and networking resources remain required.
- **resuming takes little time** (*way less than booting*)

**pausing**
- only the ==CPU activity is halted==, so the VM is **not running**, but still needs it's resources for e.g. memory, disk, network, etc.
- **resuming from pause takes even less time** (*less than resuming from suspend*)
### migration
##### what it is
migration is the act of moving a VM from one physical host to another.

the neccessity for this arises from
- **fault management** - host reports *hardware errors*, must be shut down
- **maintainance**: needing to *update BIOS, hypervisor*, etc.
- **load balancing**: move workload to another phsyical host (with *different resources*)

##### migration types
````col
```col-md
flexGrow=1
===
###### cold migration
start a VM based on an image elsewhere
```
```col-md
flexGrow=1
===
###### warm migration
*suspend* the VM to disk; *copy* the image and syspended state; *resume* execution elsewhere.
```
```col-md
flexGrow=1
===
###### live migration
*copy the full state* ==while== **the vm executes**
```
````

##### live VM migration
in all migration cases, *what you really want (ideally) is live migration*.
- no shutdown, no disruption, no impact for the user. **minimises downtime**.

###### what needs to be migrated?
**memory pages** - ensure *consistency between the memory state* of the source and dest VMs
**network resources** - maintain *open connections*
**storage resources** - *storage must be accessible* both at the source and destination VM

##### strategies for memory migration
###### push
1. the *source VM continues running*, **sends pages to destination**.
2. memory *must potentially be sent multiple times*

minimum downtime, potentially long migration time
###### stop-and-copy
1. *stop source VM*
2. *copy pages* to destination VM
3. *start destination VM* after copying all pages

short overall migration time, long downtime.
###### pull
1. execute new VM
2. pull accessed pages from source

performance depends on *number of **page faults***.
##### migration in XEN
###### memory migration again
XEM pursues the ==pre-copy== strategy for memory migration.
- this ==iteratively== uses a *push* and a *stop-and-copy* **phase**
- tries to *balance* short **downtime** with short total **migration time**.

it uses *multiple rounds* of **push**, and then a *short* **stop-and-copy** phase in the end.
- VMware's vMotion uses a similar approach; it's capable of **slowing down the source VM** to prevent memory changes from *happening too fast for the network transfer*.
###### network migration
XEN network migration operates on the assumption that the source and destination VM are **on the same IP subnet**, with *no IP-level routers* involved.

it's approach is.. after a memory transfer.. the ***dest** host* sends an unsolicited ARP reply.
   - this is a broadcast message to all hosts on the same network
   - hosts will remove IP <-> MAC mapping from caches, and refresh with this new IP
###### storage migration
XEN storage migration operates on the assumption that the source and dest VM are on the storage network. (virtual/distributed storage)

it's solution for storage migration therefore is it's solution for network migration.
once the network is migrated, so are the network drives, so it works.
- to b clear: it assumes the VMs use virtual/distributed storage, and *dont have local stoarage*
###### XEN migration timeline
![[Pasted image 20250505105119.png|450]]
###### XEN migration performance
![[Pasted image 20250505105434.png]]
^ for the migration of a running web server VM with 800 MB of ram, that's continuously serving a 512kb file to 100 clients
## infrastructure as code (IaC) + IaC tools (ansible)
### preface
###### why do we need something like IaC?
having to *manually* configure servers often leads to:
- ==configuration drift==, where configuration changes are **undocumented and ad-hoc**
- ==snowflake servers==, where servers are **uniquely configured** and **short-lived**. i.e.
	  - there is a unique configuration
	  - are not reproducible when hardware dies
	  - are difficult to mirror for a test environment
	  - *deliberate* vs *default* configuration
	  - host-specific vs general configuration
###### IaC considerations
- what if a server fails?
- how to mirror a production environment for testing?
- how to keep a cluster of servers consistent?

disk snapshots may allow you to recover and mirror servers, but..
- still not straightforward to understand the state of servers
- cant manage *multiple servers* that are **mostly similar** but *specifically and **minutely** different*
### IaC
#### what IaC is/does
**goal**: make systems *easily reproducible*, support *testing*, and *aid understanding configurations*
**solution**: one *single source of truth* with a clear **declaration of host-specific configuration**
- this source of truth can be *executed*, *versioned*, and *shared*. like the source code for a VM.

this depends on you only ever using these definitions and automation tools,
*without manually updating single servers*.

hence, IaC must be sufficiently powerful. you should (and can)
define servers, networking, and other infrastructure elements in source code.
- configuration of environments
- dependencies with specific versions

basically, ==infrastructure should be immutable==, so you should re-create it on each change.
- there are automation tools built around infrastructure definitions *and creation*.
#### ansible
ansible is an automation language and engine.
- carries out *resource orchestration* (*allocating & provisioning new servers*) and *config management*
- started in 2012, acquired by redhat in october 2015
- well-documented **conventions and best practices**, but *no artificial limits*, so users can **choose what to ignore**.

````col
```col-md
flexGrow=1
===
it is multi-platform
- OSes: Linux, MacOS, Windows
- orchestration-related tools: MXC, libvirt, VMWware, etc.
- Iaas services: AWS, Azure, OpenStack.
```
```col-md
flexGrow=1
===
and has well-established technologies as the foundation
- python, SSH, YAML+Jinja templating

with a declarative and ==agent-less== design
```
````
##### agent-less architecture
````col
```col-md
flexGrow=1
===
![[Pasted image 20250505112217.png]]
```
```col-md
flexGrow=1
===
![[Pasted image 20250505112226.png]]
```
````
##### ansible tasks
tasks are *declarative* because **declarativeness** implies **idempotency** (*repeat does nothing*)
- ansible tasks do still permit you to create non-idempotent tasks tho.

```yaml
# an example "task":
- name: "enforce permissions for .ssh directory of {{ ansible_user_id }}"
# ↑ "name" is optional but strongly encouraged
file: # ← the module name, ↓ followed by module parameters
dest: "{{ ansible_user_dir }}/.ssh"
state: directory
mode: u+rX,go-rwx
recurse: yes
```
..but to which host should this task be applied to? that's governed by **playbooks**.
##### ansible playbooks
````col
```col-md
flexGrow=1
===
*playbooks* are ansible's **execution unit**. they map everything to hosts.
- tasks, roles, variables

further features include rolling updates (configure only n number of x% hosts at a time)
the ability to "tolerate" a percentage of hosts with a failed configuration, and more.

followup question: how does ansible know the host "webservers"? **with an inventory**.
```
```col-md
flexGrow=1
===

```yaml
# file: my_playbook.yml
# a “Play”:
- name: configure internal Web servers
hosts: webservers
roles:
- webserver
tasks:
- name: forbid external connections
iptables:
chain: INPUT
source: !192.168.1.1/24
jump: DROP
```
````
##### ansible inventory
`````col
````col-md
flexGrow=3
===

```yaml
# no FQDNs required, as long as
# ``ssh <hostname>`` works (~/.ssh/config)
mail
[webservers]
w1.example.com
w2.example.com
[dbservers]
d1.example.com
d2.example.com
[appservers]
# we can override variables:
a01.example.com www_user=web
# we can use a pattern-like syntax:
a[02-12].example.com
# we can define variables for groups:
[appservers:vars]
www_user=www-data
# a group of groups
[rootservers:children]
appservers
dbservers
```
````

````col-md
flexGrow=2
===
```yaml
# alternatively, we can use YAML:
all:
  hosts:
    mail.example.com:
  children:
    webservers:
      hosts:
        w1.example.com:
        w2.example.com:
    dbservers:
      hosts:
        d1.example.com:
        d2.example.com:
…
```
note: inventories can also be obtained from external scripts/service (e.g. IaaS clouds)
````
`````
##### ansible variables
variables can be *defined in many places* (playbooks, tasks, inventory, CLI args, roles, facts..)
but scattering variables is discouraged, of course. *role, group, and host* variables **can suffice**.
- "facts" are a heap of auto-detected variables e.g. uptime, home, SSH key, etc.

note that Jinja templating is also in variable files
- e.g. `app_user: "{{ ansible_env.SUDO_USER|default(ansible_user_id) }}"`

host and group variables can be defined in a project directory like e.g.
```
# e.g., set inventory to ./inventory.ini:
.ansible.cfg
inventory.ini
my_playbook.yml
group_vars/
	# applies to all hosts:
	all.yml
	# applies to webservers:
	webservers.yml
host_vars/
	mail.yml
```
##### running a playbook
```
$ cat my_playbook.yml
$ ansible-playbook my_playbook.yml
```
## DevOps and CI/CD on clouds
hi look at these diagrams
````col
```col-md
flexGrow=1
===
![[Pasted image 20250505120012.png]]
```
```col-md
flexGrow=2
===
![[Pasted image 20250505120029.png]]
```
````
### continuous integration
CI is the automation of *integration* and *testing* of software.
- 1st proposed by grady booch 1991; *adopted and popularised as part of extreme programming*

the motivation is to avoid "integration hell" by finding bugs while they're still easy to fix.
this requires fast feedback on the system-wide impact of local changes,
but "gives the team a common view of the software project state" (idk what this means)
#### CI practices
- have 1 common (versioned) repository
- use build automation, aiming to have short builds
- have self-testing builds
- make commits regularly
- build on every commit (usually on a CI server)
- try to keep test & production environments as similar as possible
- make test results visible for everyone
### continuous delivery/deployment
CD constitutes fast and reproducible software releases.
- from the first principle of the agile manifesto: "*our highest priority is to satisfy the customer through early and continuous delivery of valuable software*"

there is a CD metric "**cycle time**": *how long to release a 1-line code change* to production?
business case: software development as investment; *optimising **ROI*** through *small cycle time*.

#### continuous delivery vs deployment
![[Pasted image 20250505121520.png]]
the difference: delivery only delivers the product and must be manually deployed;
deployment not only delivers the product but also deploys it to production.

#### deployment strategies
##### blue/green
this is a strategy to deploy an upgrade.
- have 2 production environments: blue and green
- only 1 environment is ever active at a time.

to deploy..
1. deploy to the non-active environment
2. switch the traffic (coming through a load balancer) over to the new environment
3. monitor the new version; maybe switch back.

this way, one environment always has the newst version, and *the next has the previos newest*.
- very easy to roll back one version.

**red/black** (blue/green)
![[Pasted image 20250509131235.png]]
*rolling* **red/black**
![[Pasted image 20250509131243.png]]
**canary**
![[Pasted image 20250509131253.png]]

### CI platforms
##### spinnaker
this is a CI platform started by netflix that was l8r picked up by google
- released Nov 2015 as a successor to asgard, *a web interface for automated AWS deployments*.
- features from baking to cloud deployment
- support and common abstractions for EC2, GCE, Azure, kubernetes

can use it to *deploy applications / (micro)services*, also *organise servers into clusters or server groups*
![[Pasted image 20250509131453.png]]
![[Pasted image 20250509131506.png]]

###### spinnaker pipeline
spinnaker deployments happen via pipelines.
pipelines are built from stages, with predefined stages existing for many use cases.
- e.g. you can *bake*, make *manual judgement*, *clone server group*, and *deploy*
![[Pasted image 20250505123047.png]]

###### spinnaker stage example
![[Pasted image 20250505123104.png]]

## cloud infrastructure management summary
server sprawl, configuration drift, and snowflake servers exemplify the complexity of managing cloud infrastructure.

cloud OS, orchestration systems, and automation engines help, but development and operating processes need to change as well.
- IaC: strictly automate and rebuild infrastructure
- DevOps: reponsibility extends to operation
- CI/CD: integrate and deploy systems continuously