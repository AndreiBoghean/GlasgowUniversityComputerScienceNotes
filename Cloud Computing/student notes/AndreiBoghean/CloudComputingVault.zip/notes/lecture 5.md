# cloud sustainability
## the rising footprint of ICT and data centers
#### ICT emissions trend, growth, and breakdown
##### estimated emissions from ICT
information and communication technologies (ICT)
estimated to produce ~1.0-1.7 gigatons of CO2e in 2020.

*CO2e* is the **carbon dioxide equivalent** of all greenhouse gas (GHG) emissions
##### variancy in ICT footprint estimates
![[Pasted image 20250506191905.png|450]]
##### ICT footprint compared to global
1.0-1.7 gigatons equates to 1.8-2.8% of *global GHG emissions*.
world-wide commercial aviation around 2%. UK emissions ~0.42 gigatons in 2020.
##### rise in ICT footprint
if ICT emissions **dont** increase, and stay the same, that's still bad. we cant afford.
something something graph.
###### predictions
![[Pasted image 20250506192212.png|450]]
###### what drives the growth?
![[Pasted image 20250506192238.png]]
##### ICT footprint main contributor
datacentres are biig poluters. estimated demand from traditional, AI, and crypto datacentres are:
![[Pasted image 20250506192401.png|450]]

#### what are "lifecycle" emissions?
lifecycle emissions are the sum emissions from the factors of some electronic's life.
these factors are:
- **embodied** *emissions*: emissions from *raw material sourcing , manufacturing, and transport*
	  - suggested to be around 23% overall, or 50% for consumer devices
- **operational** *emissions*: emissions from *powering the object* in question in it's life.
	  - suggested to be around 70% overall, or 50% for consumer devices
- **end-of-life** *emissions*: emissions from *recycling and disposal of e-waste*.
	  - suggested to be around 5%

###### example lifecycle emissions breakdown
![[Pasted image 20250506145921.png]]
^ for the dell poweredge R740 LCA

#### mitigating lifecycle emissions
the software carbon intensity (SCI) specification of the green software foundation says:
**energy efficiency** - make software use *less electricity* to *perform the same function*.
**hardware efficiency** - make software use *fewer physical resources* to *perform the same function*
**carbon awareness** - time/region *shift computations* to *take advantage of lower carbon intensity*
## energy efficiency, proportionality, and power use effectiveness
#### energy efficiency

###### historical energy efficiency of PCs - koomey's law
number of computations per unit of energy has doubled every few years.
this is **slowing** in line with the slowing of moore's law and death of dennard scaling. rip.
###### hardware energy demand
recall that Energy = Power x Time (1 Joule = 1Ws; 3600 Joule = 1Wh)
we differentiate between
**static power consumption**: power consumed as soon as *the device turns on and achieves idle*
**dynamic power consumption**: demand that *scales with the load on the device*
most devices follow a relatively linear power profile.
##### energy efficiency of some cloud hardware
###### cloud server utilisation
````col
```col-md
flexGrow=1
===
data centre servers are often not fully utilised.
2 google clusters, each with over 20k servers, sampled over 3 months in 2013
```
```col-md
flexGrow=1
===
![[Pasted image 20250506193652.png]]
```
````
#### energy proportionality
````col
```col-md
flexGrow=1
===
the goal of energy proportional computing is to guarantee that
the **energy consumption per operation** is *independent of the current utilisation*.

i.e. some operation consumes the same energy whether the PC is completely chilling, or if at 80% utilisation
```
```col-md
flexGrow=2
===
![[Pasted image 20250506152115.png]]
```
````
energy-proportional data centres require optimisations on many levels, e.g.
**energy proportional hardware** : *CPUs, GPUs, memory, storage, inter-data center network*
**energy-aware scheduling** : minimise number of servers with work, *so the others can be off*
**energy-aware data centre design** : let ***cooling system** parts and **power supplies** be shut down*
#### power use effectiveness (PUE)
the PUE metric describes how efficiently a data centre uses energy.
$$PUE=\frac{\text{all electricity used by a data centre}}{\text{electicity used by computing hardware}}$$
a PUE of 1.0 is ideal, since it means ***all the electricity** entering a centre is used **exclusively** for computing*; **it is 100% efficient**.

modern hyperscale data centers can have PUEs of around 1.1, while the average for data centres globally in 2021 was estimated at 1.6.

##### sources of higher PUE; how powering a data centre works
**IT power usage** is power consumed by *computing, networking, and other IT equipment*
**facility power usage** is power consumed by the *building's mechanical & electrical systems*
- cooling, power distribution, lighting, access control, etc.

##### PUE over time
````col
```col-md
flexGrow=1
===
in large-scale google data centres, PUE generally drops as time progresses.
- note that **there are yearly variations as more cooling is needed in the summer**.
```
```col-md
flexGrow=1
===
![[Pasted image 20250506155630.png]]
```
````

##### issues with PUE
PUE can differ according to your **measurement methodology**.
- *what overhead are you including* exactly?
- how *long*, *frequent*, and *exact* are your **measurements**?
- what is the workload *while* measurements are taken? recall workload variance.

also, PUE does not necessarily reflect the *whole system's **tradeoffs***.
- e.g. heat from data centres can be re-used; wherein *high PUE is not necessarily problematic*

##### jevon's paradox; rebound effects.
````col
```col-md
flexGrow=1
===
as technology becomes more efficient, humans become more careless with it.
	- formally, "as technology makes resource use *more efficient*, *demand increases*, so *resource use overall **often** increases*."
this is a general thing for resources, but is also observed in computing
```
```col-md
flexGrow=1
===
![[Pasted image 20250506160142.png]]
```
````
## cloud carbon footprint analysis
### emissions accounting
#### greenhouse gas (GHG) protocol
the greenhouse gas (GHG) protocol is the most widely used greenhouse gas accounting standard. it is defined using 3 scopes:
**scope 1**: *directly controlled* emissions, e.g. from *burning fuels* in furnaces/boilers/vehicles
**scope 2**: *indirect emissions*; mainly through *electricity purchases*.
**scope 3**: covers *emissions occurring in an organisation's **value chain***.
- value chain as in manufacturing, transportation, facilities (networking, cooling, power), etc.

**most emissions** of cloud operators are in *scopes 2 and 3*.
**cloud customers** *perceive* these emissions within their *scope 3*.

#### flawed use of GHG
the GHC protocol is applied by big cloud vendors like AWS, GCP, and Azure.
they increasingly report carbon emissions of utilised services,
**however** methodologies are *currently not transparent*, and *not consistent between operators*

provider reporting is also often..
- not *fine-grained* (e..g break down only over services e.g. EC2 and S3)
- not *timely* (e.g. reported with a delay of many months)
- not *comprehensive* (especially for **scope 3 emissions**)

**market-based measures** are used to *minimise reported emissions*
- editor's note: unbundled recs are (I think) what u know as carbon offsetting?
#### estimating *operational* emissions (as a 3rd party)
it's hard to estimate public cloud emissions, since
- there's no direct access to *power measures* **specific to your IT**.
- you dont know the exact hardware in your datacenter

hence you can only use the abstract measures of ***compute** resource usage*,
and translate that to *indirectly obtain power*; using **conversion factors** for vCores/ram/disk

###### best estimation effort for AWS VMs
test "bare metal instances" of VM instance types
- check /proc/cpuinfo to identify CPUs, and using RAPL & microbenchmarks to create linear power models.
- guess the underlying hardware for other types.
- if you attribute physical resources to VMs in a linear manner (vCore ~= 1 phys core), *estimation is subsequently easier* (as long as you dont overcommit)

## cloud carbon footprint *estimation*
estimates for operational and embodied emissions
*operational emissions* = *cloud resources usage* x *energy conversion factor* x *PUE* x *grid emissions factor*
![[Pasted image 20250506180648.png]]

take for e.g. the galactic plane project.
it used 318,000 *vCore hours*.
assuming 50% utilisation, that means ~2.12 W for a 50% used vCore (see above)
so 318,000 x 2.12 x 1.2 PUE x 433 US carbon intensity = 350 kg CO2e
## carbon-aware cloud computing
since emissions of power grids are determined by the energy mix and demand,
carbon-aware computing tries to *compute when low-carbon energy is available*.
it informs this attempt with matrix "average carbon intensity".

#### average carbon intensity
all produced power is weighted by the *carbon intensity* of their **power source**.
this is a *good metric for carbon accounting* because it's *easy to understand*,
and *easy to calculate* on account of *publicly reported power sources* in the EU and other regions.

###### varying average carbon intensity
average carbon intensity can vary throughout the day, month, year, etc.
![[Pasted image 20250506185732.png|400]]

##### carbon-aware examples
###### scenario 1
suppose you have **periodic jobs**: nightly builds, integration tests, recurring reports, etc.
you baseline may be e.g. all jobs scheduled at 1am in the night.
in order to be carbon aware, you may instead allow a +- 1h window, to allow scheduling
when there is available low-intensity carbon.

###### scenario 2
suppose your baseline is the instant scheduling of jobs, as soon as they randomly arrive during work. to be carbon aware, you could schedule them on the next workday instead.

##### limits of average carbon intensity
problem: reporting areas are very large (e.g. entire germany), so *there is no locality*.
also, there's considerations to make if you consume energy in multiple forms
e.g. *nuclear and wind*

to account for this, you may use **marginal** *carbon intensity*,
which describes the source of any such additional unit of energy.

#### renewables excess energy
what happens if we have more power supply locally than demand?
well, you "move" it to *somewhere where there is demand*.

1. energy storage. "move" excess energy through **time**
	   - *expensive and available in limited capacity*; *conversion losses*; *charge cycles* :(
2. transmit to other area. "move" excess energy through **space**
	   - *neighbours probably also have excess*; *the public grid doesnt pay*; *infrastructure limits*

if we cant do anything, then we have to **curtail** to keep grids balanced.

##### local energy curtailment
**curtailment** is the *deliberate reduction of production* to **balance** *power supply and demand*
in 2022, california curtailed ~7% of it's entire solar production.
germany lost 5.4 million MWh of renewable energy to grid bottlenecks
scotland's wind production is increasingly curtailed too.

##### can we avoid curtailment, and use energy when in excess?
###### preface: energy fluctuates
![[Pasted image 20250506191313.png|500]]

###### ok so what do we do
well, hard to define metrics for this. you're relying on a **good quality forecast**.
there's also a tradeoff between *energy* efficiency vs *carbon* efficiency.
you also need to deal with *localised surpluses*.

## cloud sustainability summary
ICT's footprint is substantial and rising.
- 1/3rd of this is data centres; hyperscale cloud datacentres are greowing fastest cuz AI.
- footprint goes well beyond emissions.

how to deal with it?
- energy efficiency, resource efficiency, carbon awareness
- rebound effects are to be expected (Jevon's paradox)
- we will need behaviour change too