## system design in the cloud
### lecture preface
###### a famous example - titanic.
1912 - the titanic died.

it was meant to be unsinkable.
- double-bottomm hull
- 16 watertight components
- could float with it's first 4 compartments flooded

despite these engineerings, it still had some fundamental design flaws.
1. *poor handling* (couldnt avoid collosion with the iceberg)
2. *bulkheads only went as high as E deck* (progressive flooding)
3. *not enough lifeboats* (inadequate precautionary measures)
4. *brittle steel and rivets* (didnt uphold structural integrity at low temp)

all of these worked on the assumptions that the titanic is practical unsinkable and would thus allow other corners to be cut.
they assumed other faults could be disregarded provided unsinkability.

there was poor **fault tollerance**.
- overconfidence can mask vulnerabiltiies
- redundancy is essentual and must be sufficient
- communication breakdown exacerbates faulures
- cascading failures can overwhelm systems.

###### some terms
- reliability
- dependability
- availablility
- peorormance
- sustainability
- self-healing
- load balancing
- auto-scaling
#### what is a distributed system?
- "a collection of independent computers that appears to it's users as a single coherent system"
- "one in which hardware or software components located at networked computers communicate and coordinate their actions by passing messages"
- "1 that stops you getting work done when a machine you've never even heard of crashes"
#### why do we need distributed systems?
1. **necessity** - because *the world is distributed*.
	- you want to book a hotel in prague from glasgow.
	- toy want to retrieve money from any ATM, but your bank is in london
	- an airplane has 1 cockpit, 2 wings, 4 engines, 19k sensors, etc
		- similarly railway networks and other distributed transport systems.
2. **realiability** - because problems rarely hit two different places at the same time
	- as a company having only one database server is a bad idea.
	- having two in the same room is better, but still risky.
3. **efficiency** - because joining forces increases performance, availability, etc.

###### examples of distributed systems
**financial trading**, *web search*, **social media platforms**, *LLMS*, **CDNs**, *games*

#### ok distributed systems are important.. are they easy?
a bank asks you to program theur new ATM software.
- central bank computer (server) stores account information
- remote ATMs authenticate customers and deliver money

a *first version* of the programs
- **ATM**: (ignoring authentication and security issues)
	  1. ask customer how much money they want
	  2. send message with <cust ID, widthdraw, amount> to bank server
	  3. wait for bank server answer: OK or REFUSED
	  4. if OK: give money to customer; otherwise error message.
- **Central Server**:
	  1. wait for messages from ATM: <cust ID, widthdraw, amount>
	  2. check if enough money to withdraw: send OK; otherwise send REFUSED.

this all ***sounds* easy** but..
````col
```col-md
flexGrow=1
===
- what if the bank server crashes between 2. and 3. ?
- what if OK gets lost? takes too long to arrive?
- what if the ATM crashes between 1. and 4. ?
```
```col-md
flexGrow=1
===
![[Pasted image 20250503194304.png]]
```
````
#### fallacies of distributed computing (**important? I think**)
asserted at sun microsystems
1. the network is reliable
2. latency is 0
3. bandwidth is infinite
4. the network is secure
5. there is one admin
6. transport cost is 0
7. network is homogenenous
8. topology doesnt change
### key aspects of distributed system design

**system function** - the intended purpose of the system
- usually documented in a specification of features and capabilities
	*e.g.* the system function of a ride-hailing app is to connect riders with drivers, facilitate booking and pynent, and orovide real-time tracking
^ what the system should do

**system behaviour** - how the system fulfils it's functions
- the sequence of actions/states the system goes through to perform it's tasks
	*e.g.* a rider requests a ride, the system locates nearby drivers, sends request to driver, driver accepts reqeuest, app displays driver's loc and ETA, processing the payment after ride is complete
^ how the system should do it

**quality attributes** (a.k.a. *non-functional requirements*) - core qualities that determine success
- performance, cost, security, and dependability
^ how the system should *perform* while doing it

#### defining correct service & failure
**correct service** is delivered when the system implements it's function.
**failure** occurs if service ever *deviates* from the **functional specification**
failure typically has consequences:
- *user dissatisfaction, loss of revenue, damage to reputation, safety risks, further failures*

###### failures, errors, and faults
**failure** : *non-compliance of functional specification*
- crash, omission, timing, byzantine etc.
**error** : *transition of internal state into invalid state*
- erroneous data, inconsistent internal behaviour
**fault** : *hypothesised cause of an error*
- caused by vulnerability in internal or external state
- software/hardware, accidental/incompetence, natural/man-made

**not all faults and errors result in failures (i.e. reach the service interface)**
**however, all failures and errors are caused by faults**

###### fault classification
![[Pasted image 20250503195228.png|400]]

###### failure is grey
**e.g.** a web server takes 5 minutes to respond to a request
- it fulfils it's functional specification (to deliver web pages)
- it works better than a server that doesnt reply at all
- but can it be considered correctly functioning?

![[Pasted image 20250503195933.png]]
- the notion of failure is gray; there ar vraying degrees of failure

**optimal service** : meet the *functional req's* and balance the *5 properties*
**complete failure** : crash, unresponsive, or produces *incorrect* results
**partial failure** : *parts of the system* fail; *degraded performance*
**transient failure** : *temporary interruption* that the system recovers from

###### quality of service (QoS)
- is a measure of how "good" a system is
- the ability of a system to provide a guaranteed level of performance to specific applications or users
- multiple facets: latency, bandwidth, security, availability, ....
- very subjective. system designer defines it given their context.
- goal: highest QoS despite faults (and at the lowest cost)

e.g. in a video streaming service, QoS would prioritise video traffic to ensure smooth playback, even if other network traffic is congested/delayed.


##### inside a data centre
###### datacentre failures -potential sources 
nodes/servers
- **faulty hardware** -> crash, timing failure, or data corruption
- **power failure** -> crash and sometimes data corruption
- **any physical accident** -> fire, flood, earthquake, etc.

network (a special type of *nodes*)
- **routers gateways** -> whole subnet impacted
- **name servers** -> whole domain name impacted
- **congestion** -> dropped packets

software, users/people
- more complex than hardware - *more complex state sequences*
- involuntary mistakes ("whoops"), misconfigration
- security attacks, both external and internal (by legitimate users)
###### datacentre failures - examples
- 2008 amazon S3 major outages for several hours affecting US & EU
- 2009 Microsoft & T-Mobile Sidekick data outage, loss of personal data
- 2011 Gmail failure, 150k customers temporarily lost emails
- 2011 Amazon EBS and RDS outage for 4 days
  (some volumes were not recoverable)
- 2015 Apple service disruptions for iTunes, iCloud, Photos, …
- 2016 Google Cloud Platform significant outage
  due to a combination of software bugs and unexpected network behaviour
- 2021 OVHcloud fire destroyed DCs in Strasbourg, France

###### data centre failures - causes
*google* datacentres have..
- 40% of servers experience a crash/unexpected restart
- 60,000 production applications affected by server failures
- mean time to repair (MTTR) of 1.5 - 10 hours
- 57% of failures led to VM migrations, hence service disruption

*global* datacentres have..
- hard drives cause the most hardware failures (82%)
- over 60% of failures result in $100,000 or more in losses.
- cyberattacks account for a negligible portion of DC outages (1%)
- power & cooling are the most common cause of outages (71%)

#### quality attributes
**performance**
- can it handle the required workload?
- how efficient is the system?
- how responsive is the system?
**cost**
- how much does it cost to build/delpoy/maintain?
- includes hardware, software, and human resources
- not limited to money
**security**
- how well does the system prevent unauthorised access?
- how well does the system protect data?
**dependability**
- can the system be **relied upon** to operate **consistently and correctly**?
- how well does it *handle failures* and recover from errors?

##### dependability
###### aspects
**availability** - readiness for correct service when requested
- measured as a percentage of uptime; e.g. 99.00% availability
**reliability** - continuity of correct service, i.e. without failure.
- expressed as mean time between failures (MTBF)
also: **safety**, **confidentiality**, **integrity**, **maintainability**

###### dependability tree
![[Pasted image 20250503202032.png]]

###### difference between availability & reliability
consider: a car.
- *availability* : is the car ready to drive when you need it? or is it broken down?
- *reliability* : how often does it break down? does it need frequent repairs?

ideally, you want a car that is both available and reliable
- ready to go when you need it and unlikely to let you down.

*perfect* system crashes *1ms/hr* **OR** *no crashes* but *produces incorrect results*
- >99.99% availability but is unreliable
system never crashes, but shuts down a week once every year
- 100% reliable, but 98% availability

**high** *availability* systems
- E-commerce
- file storage
- streaming services
- social media

**high** *reliability* systems
- air traffic control
- nuclear power plants
- hospital intensive care units

if a system isnt highly *available*.. 
**business impact**
- bad for instagram
- bad for user expectations
	a user may expect a system to be ready 24/7 whenever I need it working seamlessly
**user expectations**
- users expect services to be available 24/7
- high availability provides a seamless experience
**critical systems**
- for essential services like healthcare, finance, and emergency response,
  *high availability is crucial for safety and well-being*
###### availability 9s

| availability     | downtime per year | downtime per month | downtime per week |
| ---------------- | ----------------- | ------------------ | ----------------- |
| 90% (one nine)   | 36.5 days         | 72 hours           | 16.8 hours        |
| 99% (2 9s)       | 3.65 days         | 7.2 hours          | 1.68 hours        |
| 99.9% (3 9s)     | 8.76 hours        | 43.8 min           | 10.1 min          |
| 99.99% (4 9s)    | 52.6 min          | 4.38 min           | 1.01 min          |
| 99.999% (5 9s)   | 5.26 min          | 25.9 s             | 6.06 s            |
| 99.9999% (6 9s)  | 32.56 s           | 2.59 s             | 0.61 s            |
| 99.99999% (7 9s) | 3.16 s            | 259 ms             | 61 ms             |
each extra 9 is an order of magnitude reduction in downtime
need to plan for downtime, even with high availability systems.
- backup systems, disaster recovery plans, clear communication strategies
###### availability and reliability key factors (note: IDK what is here)
**availability**
- *fault tolerance*
- *redundancy* - having backup ... TODO continue
- *recovery mechanisms* - efficient ways to restore service after a failure
**reliability**
- *robust design* - using high-quality components and effective error detection mechanisms
- *predictive maintenance* - identifying and addressing potential problems before they cause failures

###### means to improve dependability
**fault prevention** (*design time and runtime*)
- suitable design patterns; rigoruous requirements analysts; formal verification
**fault tolerance** (*runtime*)
- design for redundancy
- incorporate error detection and recovery mechanisms
**fault removal** (*design time*)
- early prototyping and testing; static code analysis
**fault forecasting** (*runtime, and as system evolves*)
- monitor performance; analyse incident reports; conduct vulnerability audits.

##### fault tolerance
continued system operation even when some components fail
a key ingredient for both availability and reliability
multiple strategies to achieve it
- error detection
- failover mechanisms
- load balancing
- redundancy / replication
- auto scaling
- graceful degradation
- fault isolation
- ...
###### error detection
in the titanic, detection is easy. is there water in the ship?
in distributed systems, this is more difficult.

what should be the result of a request is usually unknown.
when requesting sqrt(2), you want 1.414213
- checking the answer is the same as solving the problem

sometimes, but not always, a sanity check is possible
- checksum fields in network packets
- positive number in sqrt calculations
however these only check syntax, and not semantics.

###### error detection - circuit breaker pattern
inspired by electrical circuit breakers
- **closed** - requests pass through to a service
- **open** - a certain number of failures occur within a specified time window

this prevents overload of failing services and allows time to recover after timeout, enters a half-open states, allowing a limited number of test requests through to check if the service has recovered.

*reliability* : prevents cascading failures in distributed systems
*availability (short-term)* : degrades availability.
*availability (long-term)* : fails now rather than degrade under stress
*performance* : quickly reject requests that are likely to fail

###### error correction in data centres
**monitoring** (is it working?) - collecting key metrics, e.g.g CPU/memory/disk I/O
- typically at a specific point, not everywhere.
- *heartbeats* for basic indication of issues
- *spikes* which can indicate malfunctioning processes or malware
- *exceeding thesholds* which indicate overloaded systems
**telemetry** (what data is there?) - analysing metrics across servesr toidentify issues
- understanding usage patterns across time, applications, and users
- anomalies can detect potential security threats or hardware failures
- insights can help predict future needs and scale infrastructure
**observability** (why is it doing this?) - understanding internal state by examining outputs.
- analysis of system logs and traces of comms through the system
- helps understand complex system behaviour

###### error detection in data centres - ECC
**error correcting code** (ECC) memory adds extra parity bits to each word to detect and correct errors
- it is widely adopted as standard practice across major cloud providers.

single-bit errors
- **detect and automatically correct** single-bit errors within a word, transparently without interrupting server operation.lo

double-bit errors
- **detect** double-bit errors, but typically **cannot correct** them.
- instead, *triggers an alert* or *halts the system* to prevent corruption.

###### error detection in data centres - uber M3
M3 is a large-scale platform for storing & querying time-series metrics
handles massive volume of metrics generated by microservices
- system-level: CPU, mem, disk, network
- JMS-level: garbage collection frequence + duration, heap memory, # of theads
- application-level: service request rates, error frequency, latency
- business-specific: # of active drivers, trip requests, ETA accuracy, surge pricing

M3 client periodically pushes metrics to an aggregator
###### error detection in data centres - netflix
stream processing of real-time data (events, metrics, logs) generated by services
	- this enables **real-time** opeartional *monitoring, alerting, and troubleshooting*
	- buil to be highly scalable and reliable
- engineers can create custom mantis jobs to process streams in specific ways
	  - e.g. filtering, aggregation, anomaly detection
- can *ingest from various sources* (e.g. kafka, S3) and *output to multiple destinations* e.g. elasticsearch
- provides a query language to interact with and analyse stream data
- makes it relatively easy to build, deploy, and manage **stream processing jobs** *without needing deep expertise in distributed systems*.
##### failure recovery
###### failover
failover constitutes an automatic switch to a redundant system upon failure.

why is crucial?
- availability - ensures continous service
- reliability - minimuses disruption
- data integrity - protects against data loss

how to recover?
- **heterogeneity / diversity** - *reducing chance* of common faults
- **redundancy** - accepting that "things" *will* fail and *planning for it*.
- isolation - preventing faults from *propagating*

###### failover patterns - active-passive
active-passive consists of 3 components:
**active**
- primary system handling all workload (processing & serving)
**passive**
- idle standby system, not handling any workload
- may be kept in sync with the active system (e.g. through database replication)
**failover**
- when the active server fails, the *passive server becomes the new active system*.
  sometimes there's also a need to elect a primary server that synchronises.

**pros**
- simpler to implement and cost-effective
**cons**
- means there is now a *longer recovery time* since you have 2 servers to restart.
- may also need to elect a *new primary server* for **synchronisation**

**active-passive variants**
*cold standby* - needs to be booted and configured (e.g. to restore data)
*warm standby* - running but only sunchronised periodically (checkpointing)
*hot standby* - fully running and ready to take over instantly

###### failover strategies active-active
3 components:
**active**
- two or more systems  simultaneously handling a workload (processing & serving)
**load balancer**
- distributes incoming traffic across active systems
- allocation using various algorithms - round-robin, least load, etc.
**failover**
- when an active system fails, the load balancer automatically redirects it's traffic to the remaining active systems.

**pros:**
- short recovery (immediate)
**cons:**
- more complex (consistency) and less cost-effective

###### failover strategies - key decision factors.
**state management & consistency requirements** - active-active not best for stateful systems with lots of data to synchronise
**recovery time objective (RTO)** - active-active lowest, then active-passive and variants.
**cost constraints** - more synchronisation = more costs (bandwidth, memory)
**operational complexity** - active-active is complex to implement