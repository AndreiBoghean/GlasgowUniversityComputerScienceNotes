### some principles
###### redundancy by replication
why replicate?
- performance, e.g. of heavily loaded servers
- allows error detection when replicas disagree
- allows backwards error recovery

importance of **fault-model**
- effect of replication depends on *how* individual replicas fall.
- crash faults -> availability = $1-p^n$
  where n = number of replicas; p = probability of individual failure
- e.g. 5 servers eacj with 90% uptime -> availability = $1-(0.10)^5=99.999$%

###### architecture?
- **foundation matters** - just as buildings need a foundation for their structure, cloud architectures need robust infrastructure layers (compute, storage, networking) to support higher-level services
- **scalability & modularity** - modular construction techniques allow for easier expansion and modification
- **resource efficiency** - through auto-scaling, serverless, and efficient resource allocation
- **evolution** - cloud architectures must evolve to accommodate new technologies and requirements *while ensuring system stability*
### architectural concepts
###### monolith
a single, tightly-coupled block of code containing all application components

**advantages:**
- simple to develop and deploy
- easy to test and debug in the early stages
**disadvantages**:
- *complexity* - becomes hard to maintain application growth/evolution
- *scaling challanges* - difficult to scale individual components independently
- *limited agility* - slow and risky deployments due to the large codebase
- *technology lock-in* - difficult to adopt new technologies or frameworks

if you want to upgrade a monoloth, you must change the whole thing.
component-ised things can be upgraded component-wise.

###### layering
"layering" is the partitioning of a service into subcomponents. each layer builds on top of the previous. like **OSI network model**.
- lower layers provide services to higher ones
- higher layers being unaware of the underlying implementation details
- low inter-layer dependency
e.g.
- network protocol stacks, e.g. OSI model
- operating systems - k ernel, drivers, libraries, GUI, etc.
- games - engine, logic, AI, UI


**particularly in distributed systems..**
commonly feature 3 layers.
1. user interface / presentation - maintaining interraction between user & system
2. processing - often referred to as business logic of the application
3. data - manage persistent state; can compromise access & management sublayers

*advantages*:
- abstraction
- reusability
- loose coupling
	  - isolated management
	  - independent testing
	  - software evolution


with such layering, you could e.g. have the same app run with different presentation layers according to iOS/Android/Windows/Linux
"layering is logical"

###### tiering
tiering complements layering by mapping the organisation of and within a layer to **devices**. i.e. tiering is *an extension of layering*, further separating some layers to **devices**.
- each tier is *essentially a device*.
- this has implications about the physical location of the devices.

the classic 2 tier architecture is the **client-server model**.
split layers between a client and a server is various ways: *thin client*, **fat client**, or *others*
![[Pasted image 20250505205310.png|450]]

there's also **3 tier architectures** with the same layers, but mapped into three tiers instead.
also, **4 tiers** .. **n tiers**. (n tiers example is microservices)

*advantages* of tiering include scalability, availability, flexibility, easy management
tiering gives additional advantages onto layering such as scalaing, easier management, flexibility, etc.

###### increasing availability with multi-tier architecture?
in 3-teir architecture.. what if we *increase the number of clients*? or *a component goes down*?
in such cases, you may be able to **simply scale it up**, and then you can serve more. generally, *the cloud approach is to scale*.
- scale up for an increasing load, sclae down for a decreasing load.
###### cloud scaling
**vertical scaling**
- *increase performance* of a **single node** (more cores, memory, etc.)
- *good speedup* to a **particular point**; no change to appl. arch.
- beyond this, *speedup subsequently becomes very **expensive***. (better PCs is more expensive than more PCs)
**horizontal scaling**
- *increase the **number** of nodes*
- *cheap to grow* total amount of resources (more PCs is cheaper than better PCs)
- *more difficult to efficiently utilize* the resources; need a **coordinated system**.

**out more than up**
for several reasons, cloud typically scales horizontally rather than vertically.
- CPUs are improving less (moores law is fracturing)
- new techniques such as *IaC* and *automation/orchestration tools* make this especially easy.

**modern cloud architecture**
today's computer systems are built upon 2 architectural pillars:
1. *vertical integration* - doing more with each individual tier (service)
2. *horizontal scaling* - using many commodity computers, working together.

monoliths r dead. also, expanding this further gives u microservice architecture
###### simple dynamic scaling architecture
![[Pasted image 20250505211034.png|450]]
the automated scaling listener would notice the cloud server instances are overloaded, and then replicate whatever instances are overloaded according to some criteria e.g. reponse time > 5ms
### scaling and state
multi-tier application scalability entails two questions
1. where is the bottleneck in the architecture?
2. is the bottleneck component *stateless* or *stateful*?

stateless components
- maintain no internal state beyond a request
- e.g. DNS server, web server with static data, mathematical calculator, etc.

stateful components
- maintain prior state beyond the request, i.e. *prior state is required for future requests*.
- e.g. mail server, firewalls, stateful web server, DBMS, etc.
#### load balancing
##### stateless load balancers
suppose you have a *bottleneck in a stateless service*.. you could simply *create more instances*.
.. but.. how do clients figure out which server to contact?
you need a load balancer to direct traffic.

consider a 3 tier architecture with presentation -> application -> data layer
when your *application layer is demanding scaling*.. how? *well, depends on **stateless** or **state***
###### DNS-level
![[Pasted image 20250505212137.png|450]]
DNS level load balancing works by abusing the DNS servers to resolve domain names according to whatever IP address is closest.

**advantages**
- simple to implement
- cost-effective
- can handle high traffic volumes

**disadvantages**
- less control over traffic distribution
- can be slow to react to server failures due to DNS caching
- limited health check capabilities

###### IP-level
![[Pasted image 20250505212300.png|450]]
balancing is implemented by routers at the network layer
- multiple devices share one Ip address (IP anycast)
- routers direct clients to different locations (round robin, hashing algorithms)

**advantages**
- relatives simple
- fast response to server failures
- basic health checks and monitoring
**disadvantages**
- less granular. assumes all requests create equal load.
- more expensive than DNS load balancing (routing configuration)
- does not handle application-layer optimisations (e.g. SSL termination)
###### application level
![[Pasted image 20250505212314.png|450]]
bespoke load balancer acting as a temporary front-end.
- distributes requests among machines based on various features.
- HTTP headers, cookies, payload, application-specific configuration

**advantages**
- extremely *granular control* over how the load is balanced
- content-based routing (useful with microservices)
- can reduce load on other servers e.g. SLL offloading

**disadvantages**
- increased complexity; requires deep *knowledge of the application*
- performance overhead; *higher latency*. (while e.g. *matching cookies* or *deciding where to route*)
- resource intensive; *costly*.
- *requires dedicated hardware* compared to other methods (already have IP, DNS)

###### others
load balancing on different levels can be combined
- e.g. distribute network load among distinct LBs first through DNS

other load balancing strategies
1. feedback-based - servers report their load levels back to the LB
2. client-based - choose the server with the least network latency
##### stateful components
e.g. when the **data** tier is the bottleneck. it is *typically stateful*.
- further, requests from a client *must be handled by the same db instance*.

###### partitioning
you could divide the data into distinct, independent parts.
each server is responsible for one or more parts

partitioning improves just scalability (performance), not availability,
since *each data item is only stored in one partition*.

**general considerations**
data is spread across several machines
particular tasks might require reading-writing data from multiple servers
- this causes additional network traffic

the **challenge** is -
- the network is a scarce resource with limited scalability.
- the more machines you add, the scarcer it becomes.

for good scalability, the goal of every partitioning scheme is usually to *reduce network communication*, however this is highly application-specific.
###### per tenant partitioning
![[Pasted image 20250505215133.png|450]]
put different tenants on different machines
- isolation is typically a requirement in cloud environments
- no network traffic between machines means good scalability
- **con**: scaling a tenant *beyond one machine* becomes complex.

a hypothetical tenant with large data may suffocate their server.

###### horizontal / sharding
split table by rows across different *shards* distributed across servers
each shard has the same schema, but contains only a *subset* of rows
- based on a partitioning key, e.g. user ID, region, etc.

this has a reduced number of rows and reduced indices.
it's easy to scale out (and up)
if one shard fails, only that data is affected
**con**: cross-shard queries can be slow, and requires balancing
e.gs. google bigtable, mongoB

###### vertical
split table by columns, grouping related columns together
- can improve performance of specific queries (e.g. routine analytics)

**cons**:
- does not inherently support scaling across multiple servers
- cross-partition queries may require additional joins, increasing latency.

###### partition distribution
**range partitioning**
- goal: close DB attributes will also be stored close to each other
- pro: easy and efficient for range queries; simple to scale individual partitions.
- con: poor load balancing properties; requires manual adjustment

**hash partitioning**
- goal: uniform distribution
- pro: good load balancing characteristics
- con: *inefficient for range queries*; requires *reorganisation when the number of partitions changes*.
### microservice architecture
monoliths are incredibly **difficult** to *maintain and scale*.
even layered architectures can be too complex to evolve.

n-tiered architecture
- fragment logic into loosely coupled elements (services)
- each service focuses on one job; providing an API.
- services can have completely different tech stacks (vertical scaling allows this?)
- services communicate through lightweight API (e.g. REST)

this is the dominant architectural pattern
- top performers adopt microservices in 95.5% of applications

###### advantages
- *loose coupling* (*independent* deployment)
- *fault isolation* (not affecting other services)
- development *flexibility*, technology diversity
- *agility* - faster development cycles
- scalability - only *scale parts that need* it
- maintainability - *smaller codebases* are less complex
- *easy reuse* in different projects e.g. netflix, asgard, eureka

###### disadvantages
![[Pasted image 20250505220747.png|450]]
^ microservices networks

**complexity**
	- increased operational overhead - *more services to manage* and monitor
	- distributed debugging - *tracing issues across multiple services*
**latency** due to communication between services
**microservice sprawl** - could balloon into 100s or 1000 of services (see graphs above)
**operation overhead** - manage CI-CD pipelines for multiple servoves
**difficulties end-to-end testing**.

also..
- **interdependency chain** causes chaos
- failure of one service can trigger:
	  - failures in *dependent services* (==cascading failures==)
	  - failures in *other containers of the same service* (==death spiral==)
	  - *wasted resources on failed calls* degrading the calling service (==retry storm==)
- ***cascading* QoS violations**, due to bottleneck services
- **failure recovery could take longer** than monoliths

###### glueware
software to support monitoring. consistency, load balancing, coordination, service discovery, message passing, resilience, etc.

in 2022, glueware outweighed core microservices.

###### microservice communication
````col
```col-md
flexGrow=1
===
**synchronous communication**
REST APIs (HTTP/HTTPs), gRPC, graphQL
*pros*:
	- immediate response
	- simpler to implement
	- easy to debig
*cons*:
	- tight coupling
	- higher latency
	- lower fault tolerance
```
```col-md
flexGrow=1
===
**asynchronous communication**
message queues (rabbitMQ, Kafka), event streaming, pub/sub pattern
*pros*:
	- loose coupling
	- better scalability
	- higher fault tolerance
*cons*:
	- more complex to implement
	- harder to debug
	- eventually consistent
```
````

###### service mesh technologies (SMTs)
a dedicated infrastructure layer for managing and securign comms
1. relies on the pattern of sidecar proxies
	  - microservice - a container with core business logic and a sidecar container
2. the sidecar acts as the ingress and egress point, with auxilary logic
	   - feature-rich data plane (low latency, secure) 
	   - control plane (traffic managementm service and traffic observability, certs)
3. programatically define policies for s2s interractions
	   - extract this logic out of the core business logic
	   - version and apply consistently at different levels

SMT use increased from 27% (2020) to 47% (2022)
also note:
	- Linkerd is 6%–12% faster than Istio
	- Istio uses 20%–43% memory > Linkerd
	- Istio uses 16%–20% cpu > Linkerd

###### API gateways
a reverse proxy that sits between clients and backend services
and acts as a single entry-point for all API calls

key responsibilities:
**route incomming API requests to backend microservices**
- based on the *request path, method, etc.*. might also do *load-blancing*.
**authentication and authorisation**
- *verify the identity* of clients
- ensure they have the *necessary permissions* to access specific resources
**protocol transformation and data format conversion**
- *translate between different protocols* e.g. REST, gRPC, graphQL) when neeeded
**monitor API usage and rate-limit resetting**
- *track* (using API key or IP address) *withing a specific time window*; otherwise, 429 (idk?)
###### onlyScran (feel free to ignore)
could be
- microservices (payment , user auth) share resources
- deployed on same actual device (diff countainers same machine)
- different machines same cluster (sharing netwokr)
^ some osrt of contention such as db connections or thread pools

timeout
- place at API gateway, end-to-end client latency (3 seconds?)
  ^ action with graceful degradation (dowgrade service, disallowing checkout now) or delagate (other payment service?)

caching to reduce load on shared resources, to reduce amount of requests going back to database.

for metrics..
many ways to inspect how application is performing
- processing latency (payment processing latency.. how long for payment microserivice) timeouts, resoruce utilisation, user abbandonment (user closes, or session times out)

###### avoiding the sprawl
1. *start* with a **monolith design**
	- *gradually* **break it down** into microservices as needed
	- *identify* **natural boundaries** and avoid **over-decomposition**
2. *focus* in **business capabilities**
	   - design around *clear purposes* **rather than** *technical functions*
3. *establish* clear **governance**
	   - define guidelines and best practices for microservice development
	   - e.g. naming conventions, comm. protocols, deployment procedures
4. *follow* **fault-tolerant** microservice design practice
	   - e.g. time outs, bounded retries, circuit breakers

###### cloud-native technologies
a collection of tools and techniques to build, deploy, and mange applications designed for cloud computing environments.
- embrace the cloud's scalability, elasticity, and dynamic nature
- key principles - microservices, containers, devops, automation

**benefits**
- increased agility, faster development cycles
- improved scalability
- enhanced resilience, due to distributed architectures and redundancy.
- greater efficiency, through optimised resource utilisation
- increased portability

e.g.
**containers** - Docker ,containerd, podman
**orchestration** - kubernetes, docker swarm
**microservices** - spring boot, node.js with express
**serverless computing** - aws lambda, google cloud functions, knative
**message queues** - azure queue storage, google cloud pub/sub
**services mesh** - istio, linkerd, consul connect
**container registry** - docker hub, amazon ecr, google gcr, acr
**API gateways** - kong, apigee, ambassadorm gloo
**monitoring and logging** - prometheus, grafana, jaeger, fluentd