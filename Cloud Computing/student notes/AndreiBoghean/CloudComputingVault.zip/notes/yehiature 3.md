## more provisioning level stuff
remember: [[lecture 1#the three service models]]
additional diagrams:
````col
```col-md
flexGrow=1
===
![[Pasted image 20250505131914.png]]
```
```col-md
flexGrow=1
===
![[Pasted image 20250505132030.png]]
```
````
#### IaaS
the customer asks for VMs with a particular configuration of processor/RAM/HDD/etc.
the provider then tries to match the request against *currently available datacentre machines*.
- ideally, we find a physical machine with **>= the requested configuration** remaining.
##### nuance in this process..
a datacentre runs as few machines as possible.
when there is no more capacity among existing machines, a new one is started.

as our servers fill up, we may adjust different kinds of VM (CPU/RAM/HDD ratio) to be *cheaper/more expesive*, so we can better fill out our gaps and *minimise external fragmentation*
##### APIs
on top of providing resources, cloud service providers also offer API capabilities
- e.g. interfaces to *programmatically control IaaS deployments*
  (create/start/stop/clone; monitor, get price)
the benefits of this are:
- **flexibility** - control infrastructure by code, removing manual effort
- **automation** - fully automate business process logic
- **integration** - with other tools and systems (e.g. data pipeline)

### PaaS
#### actual PaaS stuff
###### problem with IaaS
IaaS assumes you
1. build all the software within VM images
2. setup the images accordingly; e.g. install libraries and runtimes
3. control how many replicas you need
4. manage said replicas yourself; e.g. scaling
5. setup networking, security groups, middleware

###### how PaaS removes the IaaS problem
PaaS hides these levels of details
![[Pasted image 20250505133452.png|450]]

PaaS provides a collection of APIs to **program against**
- stuff like *scaling and load balancing* is **handled automatically** by the platform
PaaS offers a *higher abstraction level* compared to IaaS
- less development / maintainence effort (e.g. OS patches)
- more is controlled by the provider meaning *less flexibility*, and *high provider dependence*.

###### the (literal) cost you pay for using PaaS
higher abstraction level means different pricing models. *you can be charged for services such as*
- time
- queries; e.g. for DB services
- messages; e.g. for message queues
- CPU usage; e.g. for request-triggered applications
this means the price you pay is a function of how much your service uses these features.
- low usage, or *unpopular app*: **low cost**.
- high usage or *popular app*: **high clost**

#### PaaS example w Amazon DynamoDB
a *highly-available key-value store* used inside amazon that powers parts of AWS such as S3
it's primary design goals are *high scalability, availability, performance*, and **low latency**
- to achieve these goals, it ==sacrifices consistency==

it adopts a p2p approach.
- no server is more important than any other
- no single point of failure

*nodes can be added or removed* at **runtime**
- guarantees **availability** and **network partition tolerance**
- weak consistency guarantees (*eventual* consistency)

designed to be a *key-value* store
- no support for range queries
- no need to range partitioning

hash partitioning has good load balancing properties

###### some random screenshot (gl reading this in the exam)
![[Pasted image 20250505134750.png|400]]

### SaaS
providers offer a ready-made applications for you to use, *possibly customised with a template*.
the provider handles: *writing code*, *managing updates*, *platform integration*, *automated scaling*
the customer (non-expert) just asks for "A service that does X"

###### profitability
the business model here is based on cost.
the provider offers some service, like email, *cheaper than you could support yourself*.
major corporations can **reduce their IT overheads** by **outsourcing to SaaS** providers.
the downside is that corps. no *longer own much of the software* they use, *instead paying monthly*.

#### SaaS example - salesforce
salesforce is an IT infrastructure to handle and connect..
- product development
- sales opportunities
- staff roles, progress, and development
- automated analysis

this replaces things like spreadsheets, to-do lists, and email with an *integrated purpose-built platform* which is **backed by an elastic cloud service as your company grows**.

another note: salesforces costs a lot :)

### choosing a provisioning level
how to decide?
1. identify your skillset; real core competency
2. how much do you want to / can spend on each layer?
3. how much flexibility can you live with/without?
4. other questions: e.g. legal or privacy concerns

this applies to both individuals and organisations.

also note: there's more levels. FaaS, NaaS, mBaaS, etc.
## serverless computing (a.k.a. **FaaS**)
this is an execution model where the provider *dynamically manages resources*.
- server management is abstracted away from the user.
- this is a successor to PaaS; it goes IaaS -> PaaS -> FaaS

###### functions
ephemeral logic (functions) are created only when needed
- event-driven : architecture changes in *reaction to specific triggers*
- scalable : without manual intervention
- pay-per-excution : *billing based on consumption*; "**no idle resources**"
- stateless execution : each function invocation is independent

such functions are executed within some environment.
- functions are deployed as standalone units of code
- cold starts occur when new container instances are initialised
- execution time is limited; typically 5-15 min max
- environment is ephemeral; no persistent local stoage; => stateless

functions have supporting services
- **API gateway** - handless HTTP requests, *routing to appropriate functions*
- **event sources** - message queues, storage events. scheduled triggers
- **state management** - external databases, cache services, object storage
- **identity and access management** - security and authentication controls

examples of such serverless computing services are: AWS lambda, Azure functions, cloudflare workers, digitalocean functions, google cloud run, IBM cloud functions

###### serverless use case?
![[Pasted image 20250505142548.png|450]]

###### serverless benefits
**lower cost**: precise *usage-based billing*
**no servers to manage**: *reduced operational complexity*
**enhanced scalability**: *automatic resource provisioning*
**easy deployment**: *faster time to market*; lets u **focus on business logic**.

###### serverless challenges
**higher latency**: *cold start* impacts response times
**vendor lock-in**: use of *platform-specific services and APIs*.
**complex state management**
**memory & time contraints**: not suitable for all *operations*
**complex debugging/monitoring**: *only local debugging* since you cant debug the remote.
## low/no code development
###### explanation and tradeoffs
this type of development uses *visual environments* to enable customers to create custom applications requiring *minimal/zero understanding of code*.
- drag-and-drop; pre-built templates; auto-deployment; built-in integrations
- used mainly to build web / mobile apps.

pros: *no need to wait 4 devs*, **low skill barrier**, *easy customisation*, **flexible control of assets**
cons: *vendot lock-in; platform dependencies*, *limited customisation*

###### industry examples
amazon honeycode, azure power apps, google app sheet
- spreadsheet-like interface for web/mobile apps.
- data-centric; central governance of data (e.g. inventory tracking)
- good for business applications and process automation

**azure logic apps** - create custom workflows to make transactions more efficient
**amazon app runner** - manages runtime config, load balancing, network, scaling
**google vertex AI** - uses natural language to describe an app that is to be auto-developed

## deployment models
#### types
**public cloud**
- third-party service providers offer services to the general public

**private/community cloud**
- organisations (or possibly third parties) set up and maintain cloud services for their own internal use

**hybrid cloud**
- a mix of both. multi-cloud, via broker, federated cloud

##### public cloud
![[Pasted image 20250505144049.png|450]]
##### private cloud
outsourced private clouds; on-site clouds managed by 3rd parties e.g. IBM, HP, oracle

there are open-source virtual infrastructure managers
- **openStack**: a collaboration project between RackSpace, NASA, and several commercial companies
- **OpenNebula**: advanced virtual environment administration
- **eucalyptus**: API compatible with Amazon EC2 & S3
- **Cloudstack Community**: by cloud.com
- **Nimbus**: based on globus toolkit 4
##### comparison
###### comparison comparison

|           | private                        | community                       | public                                             | hybrid                                  |
| --------- | ------------------------------ | ------------------------------- | -------------------------------------------------- | --------------------------------------- |
| user?     | single org                     | orgs with shared concerns       | open for general public                            | composition of the 3 basic cloud models |
| owner?    | org, 3rd party, or combination | orgs, 3rd party, or combination | business, academic, government org, or combination | bound together by standard mechanisms   |
| location? | on/off prem                    | on/off prem                     | on prem of provider                                | aims for data/application portability   |

###### which option?

|                            | upfront cost | time 2 build | security risk |
| -------------------------- | ------------ | ------------ | ------------- |
| public                     | low          | low          | high          |
| private outsourced         | high         | medium       | low           |
| private internally managed | high         | high         | medium        |

## cross-cloud computing
###### what is cross-cloud computing?
basically, it lets u operate seamlessly across multiple cloud environments

###### why use it?
**avoiding vendor lock-in**: gives portability, independence, agility
**vendor redundancy**: good **fault tolerance** in the event of *outages* or *QoS fluctuations*
**harness diversity**: and diversify *service provisions* and *geographical* presence
**compliance with policies**: e.g. *physical location of data replicas*

###### how to do it?
![[Pasted image 20250505145022.png|450]]
^ there are 4 ways u can do it. hybrid, multi, meta, or federated
###### tradeoffs of cross-cloud computing
all of this spawns a whole host of issues:
- access control, identity management, performance evaluation, etc.

each model has nuances of it's own
- **hybrid**: hardwiring still involved to some degree
- **multi-clouds**: granularity lost through abstraction
- **meta-clouds**: control lost through delegation
- **federations**: standard interfaces must be established

## computing continuum
##### motivation for this thing
````col
```col-md
flexGrow=1
===
world population: connected devices=1:4
- in 2023, 5.6Billion IoT devices generating 508 zettabytes of data
- using 20TB hard drives, we'd need 25.4 billion drives

cloud coverage is wide, but not enough. it cant cater to:
- mobility support
- centralised model
- high latency
```
```col-md
flexGrow=1
===
![[Pasted image 20250505145529.png]]
```
````

the computing continuum demands placing *lighter execution units*, closer to end users.
- *aggregation*, **pre-processing**, *fault mitigation*, **coordination & automation**, *deployment migration*, **bridging between boundaries (e.g. translation, synchronisation)**, *network middleboxes (e.g. caching, traffic scrubbing, traffic shaping)*

##### what even is it?
it aims to extend the cloud paradigm to the edge of the network
- compute and data resources on demand.
- controllable over the network using APIs

enhance delivery of current applications and services
- location and context awareness; very low latency; etc.

requires redesigning of applications
- a hot area of research and business

##### fog vs edge
![[Pasted image 20250505150509.png|450]]
###### edge
- focus on processing closest to the data source
- ideal for requirements of ultra-low latency (<10ms), low backhaul bandwudth, privacy sensitivity
- has limitations in terms of hardware constraints (e.g. storage capacity)
- can be managed by the end user or application provider

###### fog
- extend resources between central datacentres and edge devices
- broader coverage geographically and topologically
- ideal for greater computational capabilities, but not at cloud scale
- typically managed by service providers or network operators



##### high-level overview
![[Pasted image 20250505150548.png|450]]

where should you offer resources?
-  at large cloud system providers (AWS, Azure, Cisco kinetic)
- at CDN operators (cloudflare, akamai, fastly)
- at telecomm operators (BT, vodaphone, verizon, AT&T)

or even.. yourself.
single-board-chips are *affordable, small, modular* (Rasp Pi, Pine64, ODROID-C2, arduino)
and relatively easy to assemble a micro-cloud from these SBCs.
![[Pasted image 20250505150921.png|500]]