#### redundancy

###### hardware redundancy
3 types of hardware redundancy you could use:
**geographic redundancy**: *data centres are distributed across multiple geographic regions*.
- mitigates the impact of **regional outages**, e.g. natural disasters or power grid failures
- data is typically **replicated** across regions to ensure high **availability**

**server redundancy**: *servers are deployed in clusters with automatic failover mechanisms*
- servers are deployed in *clusters* with **automatic failover mechanisms**
- the transfer in event of failure is made seamless by **virtualisation stuff**

**storage redundancy**: *data is replicated across multiple storage devices and technologies*.
- within the same data centre, and across others.
- using **RAID configurations** to protect against *disk failures*

###### network redundancy
the challenge with network redundancy is *implementing it at scale* (100,000s of PCs)
while *maintaining strict quality requirements* (high bandwidth; low latency)
and dealing with *hardware failure* of **network hardware**

on the **server level**: redundant NICs, and have power redundancy.
on the **network level**: redundant switches, routers, firewalls, load balancers, etc.

###### power redundancy
- multiple *power feeds* from different **utility substations**
- UPSes as backup in temporary outages
- backup diesel/gas generators for medium/long-term outages
- **power distribution units** (PDUs) with dual power inputs to ensure *smooth transitions* when you need to swap

###### cooling redundancy
datacentres often have heating, ventilation, and air conditioning (HVAC) systems
- to control temperature, humidity, air quality

cooling redundancy measures include:
- N+1; having ***1** extra cooling unit* than required to handle the load (as a temperature buffer)
- **multiple cooling technologies** to mitigate *single points of failure*
	  - (CRAC units, free cooling, in-row cooling)
- redundant cooling loops: pipes, heat exchangers, pumps
- hot/cold aisle containment: *prevent hot and cold air from mixing*


### sustainability
#### why?
bcuz it's getting warmer :(

also: the AI factor. global datacentre electricity consuption to double by 2030 cuz genAI.


#### carbon footprint measurement frameworks
##### carbon accounting (skipped cuz see lecture 5)
##### Power/Carbon/Water usage effectiveness (PUE stuff)
PUE = **total facility** *energy* / IT requipment energy
- industry average: 1.58 (2022 data); best practice target: 1.2 or less.

CUE = **total facility** *CO2 emissions* / IT requipment energy
- not all power is created equal; accounts for **carbon intensity of energy**.

WUE = **total facility** *Water consumption* / IT requipment energy
- note that water source and disposal are important in sustainability.

###### how measure these metrics?
with real-time monitoring...
- enables dynamic optimisation and immediate response
- require substantial sensor infrastructure and data processing.
- supports carbon-aware computing decisions.

with historical analysis...
- provides *trend data* for strategic planning
- *less resource-intensive* to implement
- supports reporting and compliance requirements

if you're doing real-time, you're probably also doing historical(?)

##### life-cycle assessment (LCA) methodologies
**cradle-to-grave assessment**: *holistic and comprehensive view*; *not **just operational** consumption*
- including raw material extraction, manufacturing, transport, installation, use, EOL.

**reveals hidden impacts**
- *embodied carbon*, *resource depletion* (rare earth metals), *water usage* in manufacturing

this is based on standards ISO 14040 & 14044, giving *consistency; transparency; reliability*

##### measurement granularities
###### software-level
u can use: **intel RAPL**, *NVIDIA SMI (cli) or w NVM (C-based lib 4 SMI)*, **linux tools powerTOP powerStat**, *others CodeCarbon PowerAPI scaphandre*

###### server-level
power consumption at component level
- CPU, mem, storage, network

==intelligent platform management interface== (**IPMI**)
- standardised hardware interface for "*out-of-band*" management
  (control, diagnosis, maintenance)
- uses a baseboard management controller (**BMC**); dedicated MCU  on the motherboard.
- remote admin regardless of PC health
- *monitor*: temps, voltage, fan speed, PSU status
- *control*: power cycling, server restart, BIOS config.
- *log*: system events and errors for troubleshooting

###### rack-level
- intelligent PDUs for per-outlet metering.
- rack inlet/outlet temp monitoring.
- per-rack cooling efficiency

###### datacentre-level
total facility power consumption
- IT equipment
- HVAC
- power infrastructure
	  - **PDUs**, **UPSes**, **batteries**, **transformers** (*voltage regulation, electrical isolation, phase conversion*), **electrical switch gear** (*circuit breakers, disconnect switches, fuses*)
- lighting
- comms
- security
- building management

environmental conditions: temperature, humidity, air flow, smoke

DC manageability inteface (**DCMI**)
- a standard built upon **IMPI** to address DC manageability needs
- **power management** capabilities like *monitoring* and *capping*


###### network-level
network measurement *depends on all the devices and mediums **along the network path***
- consumption depends on *hw specs*, *utilisation* levels, *efficiency*.

estimated to consume ~1% globally.

encompasses various domains, grids, device models, ... and can vary significantly over time, so hard to do.


#### carbon intensity
CI is the among of equivalent CO2 released per unit of generated power
- unit: gCO2/kWh (the effect of greenhouse gases, normalised to CO2)

CI varies based on the *energy source*
- **renewables** have *lower CI*, **fossil** fuels have *high CI*
- **renewable** supply can be *intermittent*
- **fossil fuels** can be used *on-demand*

grid CI = $\Sigma$(CI of each energy source)
- grid CI is very diverse over geographic regions, time of daty/year

###### Ci data
historically, CI has been very coarse and sparse.
- aggregated at country-level (select countries)
- aggregated over a year -> month

and is recently becoming more fine-grained
- in location (region level) and time (sub-hour)
- captures more variability

###### CI signals
**average CI**: overall carbon emissions of the *electricity mix*
- useful for reporting general emissions e.g. policy planning, sustainability reporting
  also useful for long-term (e.g. anual) trend analysis
- **doesnt reflect** *real-time fluctuations*
- can obscure the impact of *specific energy consumption changes*

**marginal CI**: emissions from the **next unit of electricity** (*not all created equal*)
- useful for **optimising real-time decision-making** e.g. *load-shifting and time-shifting* strategies
- complex to predict accurately
- short-term view; isnt good for long-term infrastructure analysis.

#### sustainability considerations
##### energy vendor
energy sources:
- proximity to renewables (hydro, window, solar, geothermal)
- invest into renewable backup sources that are reliable across seasons

idle power consumption
- maximise server utilisation; workload consolidation

embodied carbon
- extend hw lifespan strategies (upgrade vs replace); refurbish and reuse.
- account for transporation and installation emissions (e.g. steel, concrete)

cooling
- natural cooling, especially in water-scarce locations

transparency and accountability in this space is improving, but more is needed

##### user-based decisions
###### dont waste electricity
location-shifting (a.k.a. load-shifting): **geographical placement** where *CI is low*.
time-shifting: **temporal scheduling** to *times of low CI*.

^ these are also ways to cope with excess energy. move it where u need, *through time or space*

###### be frugal.
curb expectations; cant have high avail AI, 6G, on-demand everything, etc.
- be *selective about service requirements*

rethink design goals and practices
- design applications to use fewer resources (mem, CPU, network)
- identify and eliminate unnecessary levels of indirection
- *minimise resource consumption* with e.g. lazy loading and other techniques
- *test energy consumption* as part of your development cycle
- implement *data lifecycle policies*, a.k.a. **delete unnecessary data**
- embrace multitenancy in development
	  - shared VMs, neighbouring containers, managed container platforms, etc.

right-sized comissioning; avoid **overprovisioning**
- dynamic assessment of needs and expectations
- use historical patterns for analysis; monitoring for real-time adjustment
- *dedicated and long-running* **cloud instances** are the worst offenders
- spot instances and serverless are (currently) very efficient

service and provider selection
- major implications of decisions on *cost & performance*; same applies for **emissions**
- select providers with *strong and clear **environmental commitments***
- data is not readily available or reliable, but so was performance.

###### instance-type selection
which provider? which instance type? how many? which availability zone? what time?
answers are subjective; what's best for ur application?
**something something performance prediction**.

### carbon footprint prediction
lack of transparency: hardware specs, exact location, tenancy

current resources for this are:
- provider dashboards / APIs - strill in their infancy
- 3rd-party estimators
- LCA - comprehensive analysis of the environmental impact of a cloud service throughout it's entire lifecycle (manufacturing -> disposal)

need better data and data acquisition tools
- important to use credible data sources and methodologies
- an evolving field; measurement techniques are improving.

### carbon-aware AI usage
1. the choice of DNN, datacentre, and processor can significantly reduce carbon footprint up to 100-1000x.
2. ML training can be tweaked to trade-off some accuracy for significant reduction in emissions

### grid-aware computing
grid-aware computing (suggests) carbon aware approaches can be detrimental.
- if many people time/location shift, renewable energy could be **overused**.
- this leads to resorting to fossil fiels to *cover excess demand*.
- important to understand how grids work, and thee need for a more responsible and effective implementation ("**grid-aware computing**")

also, make note that polutance is inversely corelated with flexibility.
- renewables; nuclear; coal; gas. **renewables inflexible**, *gas extremely flexible*

### secret problem with GHGP
resources are decomissioned early as their performance diminishes.
decomissioned resources are also not recycled properly because it costs.
- nuclear fuel moment