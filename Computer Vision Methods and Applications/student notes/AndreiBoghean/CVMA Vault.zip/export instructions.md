all at: 148x630 | no margin | 100% scale | portrait,

except:

lecture 7 at 88%
lecture 5, 9, 13 at 85%.
lecture 6 and 14, at 75%.