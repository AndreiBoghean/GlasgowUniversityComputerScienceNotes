# image formation basics (L1)

### real life to image

##### digital image acqusition (in a camera sensor)#

##### from scene to image

##### bidirectional reflectance distribution function (BRDF)

##### pinhole camera

### perspective

##### effects of perspective

##### parallel projections under pinhole projection

##### vanishing points

###### vanishing point examples

###### vanishing points on planes

##### properties of projection

### more on pinhole cameras

###### a basic diagram representation

##### pinhole camera problems

#### lenses

##### lenses justification

##### using a lens

##### thin lenses

### camera sensor technology

##### colour sensing

##### distortions

#### pixel coordinates

##### homogeneous coordinates

##### homogenous coordinates - distortions

##### internal coordinates - calibration matrix

##### camera transformation matrix

###### something something inner product

##### camera projection matrix

###### simple properties of P