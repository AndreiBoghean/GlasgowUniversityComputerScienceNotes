# convolutional neural networks (L10)

##### what is convolution
remember ![[lecture 3#1D convolution definition]]
also there is cross-correlation: $y(t) = (f \otimes g)(t) = \Sigma f(\tau)g(t+\tau)$

#### CNN architecture
##### CNNs vs MLPs
![[Pasted image 20250518210552.png]]

##### how the convolution works
![[Pasted image 20250518210812.png]]
notice that the output is just short enough so there's no edge effects.
- i.e. it's the length of the input, minus length of filter/weights, plus 1.

###### with padding..
![[Pasted image 20250518211219.png]]
notice the extra 0s on the input.
also notice the output is now bigger by 2.

###### with a stride..
![[Pasted image 20250518210934.png]]
notice that, with a stride of 3, every 3rd number is actually populated. the rest are empty.

###### what size is our output?
generally, the output size is given by floor($(N-F+2P) \div S +1$)
- where N is input, F is weights size, P is padding, and S is stride.

##### general CNN model
![[Pasted image 20250518212406.png]]
the model learns to **extract a hierarchy of features**.
CNN has been applied successfully both in 1D and 2D classification.

##### model layers
###### pooling
**pooling** layers are used for **downsampling**.
- reduces the number of *parameters* to learn.
- reduces *overfitting*.

can also result in **invariance**.

*pooling methods include*.. max, average, L2 norm, stochastic, spectral

###### flatten
**flattening** is *converting the data into a 1-dimensional array* for inputting it to the next layer.
we flatten the **output** of the **convolutional layers** to create a *single long feature vector*.
it is connected to the *final* **classification model**, which is called a fully-connected layer.

##### classic CNN architectures
![[Pasted image 20250518213026.png]]
![[Pasted image 20250518213034.png]]

#### CNNs summary
CNNs have been proven very efficient in computer vision, and it's one of the most successful applications of deep learning

CNNs are ==more efficient== than a *fully-connected* **multi-layer perceptron architecture**
they extract local features in a hierarchical way, making them better.
however *training in CNN* can be **more challenging** than *multi-layer perceptron*.