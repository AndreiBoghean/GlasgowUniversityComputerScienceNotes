# other feed-forward networks (L11)
### residual network
![[Pasted image 20250518215536.png]]
a residual network is a deep learning architecture wherein the layers learn *residual functions* with reference to the **layer inputs**.

a *residual function* is simply one whose output **resides** for use in some later layer.
i.e. it's output feeds forward to a future layer.
![[Pasted image 20250518215223.png]]

afaik, they're just better with less layers.

### autoencoders

##### regular autoencoders
````col
```col-md
flexGrow=1
===
![[Pasted image 20250518215733.png]]
$f_{\theta}(x)=s(xW^T+b)$
```
```col-md
flexGrow=1
===
![[Pasted image 20250518215721.png]]
```
````
they're a type of neural network architecture, used for unsupervised learning.
they have 2 parts:
- encoder: encodes input data into a lower-dimensional space
- decoder: decodes data from that lower-dimensional space back to the original input.

##### denoising autoencoders
denoising autoencoders differ in that they introduce arbitrary noise into the input,
while keeping the loss function with respect to purely the no-noise input.

this results in efficient learning of autoencoders,
while significantly reducing the risk of the autoencoder becoming an identity function.
- they also learn to deal with partially corrupt inputs, or those with noise.

##### variational autoencoders
![[Pasted image 20250518220742.png]]
variational autoencoders have a "latent space" in the middle layer.
effectively, the encoder is no longer mapping to some concrete value,
but rather a distribution within that latent space.

this is beneficial because it allows the network to avoid overfitting the training data.

##### network structure and parameters
something something number of layers, overcomplete representations, activation functions, loss functions.

also regularisation (L2 regularisation, batch normalisation, dropout)

##### more on denoising autoencoders
to denoise an image, the *autoencoder architecture* **doesnt change**, but *the training method does*.
- noise is added to the input image, but the loss function now compares the original to the reconstructed image.
- it works, and can be used in many other contexts as well.
![[Pasted image 20250518221501.png]]

##### more on variational autoencoders
![[Pasted image 20250518221721.png]]
idk. here's an image. TODO: review the lecture recording for what this slide means.

##### convolutional autoencoders
![[Pasted image 20250518221806.png]]
the standard autoencoder comprises fully connected layers
the convolutional autoencoder comprises *mirrored* **convolution layers**,
coupled by max pooling, and joined by fully connected bottleneck "code" layers

### image segmentation

#### image segmentation - SegNet
![[Pasted image 20250518222131.png]]
SegNet architecture is based on VGG16 network architecture, *however*..
- there are no fully connected layers, hence it's only convolutional.
- key component of SegNet is the **decoder network**,
  which consists of a hierarchy of decoders, with *one corresponding to each encoder*.

SegNet *reuses max-pooling indices* in the **decoding process**, which has several advantages:
- improves boundary delineation
- reduces the number of parameters, enabling end-to-end training
- this form of up-sampling can be incorporated into any *encoder-decoder* architecture.

![[Pasted image 20250518222444.png]]

#### image segmentation - UNet
UNet architecure is an (almost) symmetric network that was designed for segmenting bio-medical images.
- no fully connected layers
- uses the *same feature maps that are used for contraction* to **expand a vector to a segmented image**
- upsampling path has a large number of feature filters
- softmax cross-entropy loss function
- special weighting using morphology operations to enhance learning borders

![[Pasted image 20250518222733.png]]

### summary on other feed-forward networks
simple basic architectures for classification, auto-encoding, & regression.
highly complex current architectural developments.
highly successful applications:
- **recognition**, *semantic segmentation*, **pixel labelling**, *denoising*, **style transfer**, *video analysis*