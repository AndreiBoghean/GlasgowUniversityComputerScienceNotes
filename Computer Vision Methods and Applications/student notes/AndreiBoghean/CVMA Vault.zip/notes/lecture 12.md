# time dependent DNNs (L12)

### recurent neural networks
![[Pasted image 20250519092445.png]]
recurrent networks have a *memory*, and as a result *can remember previous states*, **unlike pure feedforward** networks.

such state memory allows recurrent networks to perform **general processing** and manipulation of sequences, e.g.
- classify input sequences
- predict the next element of an input sequence
- learn structure in input sequences
- translate sequences
- *video understanding*

###### RNN memory accumulation
RNNs accumulate information from each time step.
they can learn representations for variable-length sequences.
![[Pasted image 20250519093033.png]]

![[Pasted image 20250519100233.png]]
- $O_{t}$ is the value produced by the neuron
- $h_{t}$ is the memory of the value the neuron last produced
- there are separate weightings, U and W, for input and previous neuron output.

##### forward propagation in RNNs
![[Pasted image 20250519100537.png]]
an "internal" (fake terminology) activator function gets a preliminary result based
on input vector and previous layer output.

if going to layer output, then a second activator function is used,
which presumably prepares the value for "presentation"?
- there is a weighting used with this, before the activator.

##### back propagation in RNNs
![[Pasted image 20250519101544.png]]
- $E_{t}$ is the *error* (loss) *at time t*; i.e. the diff between the output at **t** and the *ground truth*.

![[Pasted image 20250519104832.png]]
i dont understand this, so neither do you. hope you're not reviewing this in the exam.

also:
there is a **vanishing gradient**.
- the gradient becomes too small over time.
- the network becomes incapable of learning, as no change can be made

there can also be an **exploding gradient**
- gradient becomes *too big* over time
- network becomes very *unstable*.

the solution to these is **gradient clipping**, to limit the gradient.
there also other sols.. such as LSTM

##### long short-term memory (LSTM)
![[Pasted image 20250519121253.png]]
LSTM attempts to solve vanishing/exploding gradient with input, output, forget gates.
note:
- C: **cell state** (*long-term*)
- h: **hidden state** (*short-term*)

1. there is a **forget** gate.
	   - it decides how much of *the previous data will be used/forgotten*, with a value [0.0..1.0]
2. there is an **input** gate
	   - decide *what input information is relevant* for updating the cell state
3. nothing about this lmfao. same on **4.**, **5.**, **6.**

##### gated recurrent unit
![[Pasted image 20250519122859.png]]
the key differences with LSTM are that
- the *forget and input gates are replaced* by **reset and update** gates
- there is *no output* gate

the **reset gate** decides how much previous data will *be forgotten*.
the **update gate** decides how much previous data will be used for *updating the hidden state*

##### example - predicting the next video frame using LSTM
something something **convolutional LSTM**.

### attention and transformers
#### machine translation
![[Pasted image 20250519123548.png]]

##### using RNN
![[Pasted image 20250519123733.png]]

problem: cant remember long-term dependencies (vanishing gradient problem),
so not effective for handling *long sequences*.

also, sequential computation is **time-consuming**.

##### using RNN, with attention
given a hidden state $s_{t-1}$ (for the *previous* target word $y_{t-1}$ as in the RNN decoder)
the **current** target word $y_{t}$ can be computed as follows:
1. compute scores (similarities or weights) between $s_{t-1}$ and each $h_{j}$
   (*representation of each word in the source sentence* in the RNN encoder, in the example)
2. normalise the scores using **softmax**
3. get the context vector $c_{t}$ as a weighted sum of the representations of the words in the source sentence, i.e. $c_{t}=\Sigma_{j=1}\alpha_{(t,j)h_{j}}$
4. generate the current target word $y_{t}$ with the hidden state $s_{t}=f(s_{t-1},y_{t-1},c_{t})$

![[Pasted image 20250519131708.png]]

````col
```col-md
flexGrow=1
===
the advantages of doing this include
- improving performance in a wide range of applications
- alleviating the *gradient vanishing problem*
- more interpretability of the learned model, thanks to the attention distribution.
```
```col-md
flexGrow=2
===
![[Pasted image 20250521180234.png]]
```
````

#### transformers
un like RNNs, *sequential computation is not needed*.
- relies entirely on **self-attention** to compute representations of it's input and output

self-attention, a.k.a. intra-attention, is an attention mechanism relating different positions of a single sequence in order to cpmute a representation of the sequence.

this allows more parallelisation, meaning less time needed to train.

##### transformer attention
###### scaled dot-product attention (self-attention)
````col
```col-md
flexGrow=1
===
**attention** maps a *query* to an output
- encodes each word as a query, key, value (respectively)
- computing the attention by dot-product (between Q and K)
$$\begin{align}
\text{Attention}(Q,K,V)= \\ \text{softmax}(\frac{QK^T}{\sqrt{ d_{k} }})V
\end{align}
$$
```
```col-md
flexGrow=1
===
![[Pasted image 20250519132831.png]]
```
````
###### multi-head attention (cross-attention)
**multi-head attention** involves learning different sets of *linear projections* for *query, key, value*
- allows the model to **jointly attend to information** from *different representation subspaces*.
- e.g. shorter-term vs longer-term dependencies.

there's also **positional encoding**: represent the *location* of items in a sequence.

##### object detection
the encoder (which represents each pixel as a word)
can separate individual instances.
e.g. focusing on a few points in the image.
![[Pasted image 20250519133854.png]]

different interaction categories have different patterns
![[Pasted image 20250519133935.png]]