# intro to reinforcement learning (L13)

so far, we've met networks which are trained using *supervised* learning methods.

on the other hand, reinforcement networks are capable to learning a **series** of actions,
to train an agent **without direct supervision**

such networks still require a goal to guide them, and this comes in the form of a "reward"

###### breakdown
reinforcement nets undertake a selection of *actions*, perhaps even **random** *actions*.
a reward is computed based on whether the *action* brought the system **closer** to it's goal.

after a number of such exploration phases, *backpropogation* (or similar optimisation)
is used to update the network weights.

hence the network is trained such that, given a *current world state*, it **recognises what to do next** to move the world state in a *direction consistent with achieving* it's overall goal.

deep recurrent networks, in combination with deep **reinforcement learning**,
are often *used to build systems that learn to undertake complex tasks* without supervision.

note: the environment and interpreter often get lumped together as a single unit,
as in the following slides

#### combining computer vision and reinforcement learning
###### autonomous driving example
input: a single monocular image (at each timestep)
the model: DCNN
output: steering angle and speed
reward: dist travelled b4 human intervention
- the model learns to maximise reward; i.e. minimise human intervention

#### deep reinforcement learning (DRL)
the typical framing of a reinforcement learning (RL) scenario:
1. an agent takes actions in an evironment
2. an interpreter decides on a reward based on the outcome of the action
3. the interpreter generates a representation of the environment state
4. the reward and state are fed back into the agent.

![[Pasted image 20250519140545.png]]

##### some core definitions:
###### random terms:
**Agent**:
- an agent takes actions.

**Action** (A):
- A is the set of all **possible moves** *the agent can make*

**Discount factor ($\lambda$)**:
- this is multiplied by future rewards as a discovered to *bias against future rewards*, so they're **worth less** than immediate rewards.

**environment**:
- the environment takes, for input, the *agent's current state* (environment and agent state) and **action**, and then outputs the **agent's reward** and it's *next state*.

###### more stuff
**State** (S): a *state* is a concrete and immediate situation in which the agent finds itself
**Reward** (R): *reward* is the *feedback* by which we indicate the *success/failure* of an *agent's actions*
**Policy** ($\pi$): *policy* is the **strategy that an agent employs** to *determine the next action* based on the **current state**. it ==maps states to actions==. the actions that promise the highest reward.
**Utility** (U): the expected *long-term return with **discount***, as opposed to the *short-term reward **R***.
**Q-value**/**action-value** (Q): similar to unity, but takes an extra param, *current action a*.
- Q$\pi$(s, a) refers to the *long-term return* of the **current state s**, taking *action under policy* $\pi$
- Q maps state *state-action* **pairs** to *rewards*

**trajectory**: a sequence of *states and actions* that influence those states.

##### core algorithm in DRL
![[Pasted image 20250519150934.png|450]]
1. environments are *funtions* that transform an **action taken** in the *current state*
   into the next state, and a reward.
2. agents are functions that transform the new state and reward into the next action.

we can know the *agent's function*, but we **cant know the function of the environment**.
- it's a black box, where we only see the inputs and outputs.

in the feedback loop, the subscripts denote the time steps $t$ and $t+1$,
(each of which refers to different state.)

###### something something reasoning
unlike other forms of machine learning (e.g. supervised/unsupervised)
reinforcement learning can only be thought about *sequentially* in terms of *state-action pairs*.

reinforcement learning judges actions by the results they produce.

its **goal-oriented**, and it's aim is to learn sequences of actions that will load an agent to achieve its goal, or maximise its objective function.


###### evaluating reward
an example of a reward function: $\Sigma^{t=\infty}_{t=0} \gamma^tR(x(t),\alpha(t))$
- sum *reward function* **R** over **t** *time steps*

this objective function calculates the total reward we obtain by running through a window of t time steps, for a finite number of steps t.
- **x** is the state at a given time step
- **a** is the action taken in that state
- **R** is the reward function for x and a
- $\gamma$ is the *discount factor*, to *bias rewards* from more ***immediate** actions over **future** actions*, where $\gamma \leq 1$.

why $\gamma$?
- "but this long run is a *misleading guide to current affairs*. **in the long run we are all dead**. economists set themselves too easy, too useless a task if in tempestuous seasons they can only tell us that when the storm is long past the ocean is flat again"
- so basically, if you bias for long-running actions, that's stupid?

###### action selection
reinforcement learning is the process of running the agent through *sequences*
of **state-action pairs**.
1. observing the rewards that result
2. **adapting** the *predictions of the Q function* to those rewards, **until** it *accurately predicts the best path* for the agent to take

that prediction is known as a policy, $\pi$.

reinforcement learning is an attempt to model a complex *probability distribution of rewards*, in relation to a very large number of *state-action* pairs

since DL is iterative, it doesnt know which pairs will produce good rewards.
instead, it learns these relations by running through states again and again.
to do this, it must **rank** *actions* relative to one another.

we map state-action pairs to the *values we expect them to produce*, by means of the **Q function**
- the Q function takes input an agent's state and action, and *maps them to probable rewards*

##### the deep part of deep reinforcement learning
**neural networks** are the *agent* that learns to map state-action pairs to rewards.
like all NNs, their learning consists of *iteratively optimising* **coefficients/weights**.

![[Pasted image 20250519165054.png]]
**convolutional networks** can also be used to *recognise an environment's state*.
- .e.g the game environment of mario, or the terrain before a drone
- i.e. they have a preliminary step of standard image recognition

in reinforcement learning, given an image that represents a state,
a **convolutional net** can *rank the actions* **possible** in that state.
- e.g. it might predict right:5, jump:7, left:0


##### more random stuff on the optimisation formula
$$\Sigma^{t=\infty}_{t=0} \gamma^tR(x(t),\alpha(t))$$
a = $\pi(S)$.

Q maps state-action pairs to the highest combination of immediate reward,
**including** *all future rewards that might be harvested by later actions*
![[Pasted image 20250519170719.png]]
- state-action pairs mapped to the values we expect them to produce with Q.
- Q func inputs an agent's state-action, and maps them to probable rewards.
- reinforcement learning is the process of running the agent through sequences of state-action pairs, observing the resulting rewards, and **adapting the predictions of Q** to those rewards until *it accurately predicts the best path*.
- that predicting is the policy $\pi$


Q operates over a *time window* to take both **immediate**, and **delayed** rewards.
- blended by a learning rate $\alpha$
- there's also a discount factor $\gamma$, which suppresses reward from *distant future actions*.

###### ACTUALLY NEW INFORMATION WOA
the neural network coefficients **may be initialised stochastically**.

using feedback from the environment, i.e. by applying an action, the NN can use the difference between it's expected reward and the *ground-truth reward* to adjust it's weights and improve its interpretation of state-action pairs using optimisation.
- somewhat like backpropagation

reinforcement learning relies on the environment to send it a scalar number, reward,
in response to each new action.
- the rewards returned by the environment can be varied, delayed, or affected by unknown variables, *introducing noise to the feedback loop*

this leads us to a more complete expression of the Q function, which takes into account not only the *immediate rewards produced by an action*, but also the *delayed rewards that may be returned several time steps deeper* in the sequence.

the Q function is recursive: calling it in a given state-action pair requires us to call a nested Q function to predict the value of the next state, which in turn depends on the Q function of the state after that, etc.

##### implementation issues
actual implementations vary widely, depending on the context of the task and application scenario.

typically, DRL might spend a number of timesteps **exploring**, followed by **learning**
- i.e. network update

initially this exploration is based on
- undertaking actions essentially randomly
- or based on initially little state-action-reward knowledge

however, the inital exploration is followed by updates of the networks which learn to rank (state, action) pairs.

here is a simple reward predictor network:
![[Pasted image 20250519181854.png]]

#### deep learning for robots:
"observing the behaviour of the robot after over 800k grasp attempts, equivalent to ~3k robot hours, we can see the beginnings of intelligent reactive behaviours."

##### CNN grasp servoing approach:


**entirely data-driven**
- *doesnt rely on human annotation* either in training or test time (unsupervised learning)
- contrasts to prior methods based on defined grasp points

**method consists of two components**
- a *grasp success predictor*, which uses a deep convolutional neural network (CNN) to determine how likely a given motion is to produce a successful grasp
- a *continuous servoing mechanism* that uses the CNN to continuously update the robot's motor commands

by continuously choosing the **best predicted path to a successful grasp**,
the servoing mechanism provides the robot with:
- fast feedback to perturbations
- ability to deal with object motion
- robustness to inaccurate actuation (by *correting actuation mistakes iteratively*)

###### contributions of this work
- a method for learning *continuous visual servoing* for robotic grasping from monocular cameras
- a novel *convolutional neural network architecture* for learning to predict the outcome of a grasp attempt
- a large-scale *data collection framework* for robotic grasp

###### doing this with CNNs:
grasp prediction network $g(I_{t}; v_{t})$ is trained to predict whether a given task-space motion $v_{t}$ will result in a seccessful grasp, based on the current camera observation $I_{t}$

in order to make accurate predictions, $g(I_{t}; v_{t})$ must be able to..
1. parse the current camera image
2. locate the gripper
3. determine whether moving the gripper according to $v_{t}$ will put it in a position where closing the fingers will pick up an object

each grasp $i$ consists of $T$ time steps, with each time step corresponding to an iamge $I^i_{t}$ and pose $p^i_{t}$.
the final dataset contains samples $(I^i_{t}; p^i_{T}-p^i_{t} Ib_{i})$ that consist of
- the image, $I^i_{t}A$
- a vector from the current pose to the final pose, $p^i_{T}-p^i_{t}$
- the grasp success label, $Ib_{i}$

each grasp consists of $T$ time steps.
1. at each time step, the robot records the current image $I^i_{t}$, and the current pose $p^i_{t}$, and then chooses a direction along which to move the gripper
2. at the time step $T$, the robot closes the gripper and evaluates the success of the grasp, producing a label $Ib_i$
3. each grasp attempt results in $T$ training samples, given by $(I^i_{t}; p^i_{T}-p^i_{t}; Lb_{i})$

each sample includes the image observed at that time step,
the vector from the current pose to the one that is eventually reached,
and the success of the entire grasp.

**this procedure trains the network to predict whether moving a gripper along a given vector and then grasping *will produce a successful grasp***.

note that this differs from the standard reinforcement learning setting,
where the prediction is based on the current state and motor command,
which in this case is given by $(I^i_{t}, p^i_{t}, v^i_{t})$

###### random slides I've not bothered to write properly:
![[Pasted image 20250519190824.png]]

CNN grasp predictor architecture $g(I_t; v_t)$:
- Input image $I_t$ & pre-grasp image $I_0$ (no grippers in field of view), fed into a 6 × 6 convolution with stride 2
- Followed by 3 × 3 max-pooling and 6 5 × 5 convolutions
- Followed by a 3 × 3 max-pooling layer
- Motor command $v_t$ is processed by one fully connected layer pointwise added to each point in the response map of pool2
- Result is then processed by 6, 3 × 3 convolutions, 2 × 2 max-pooling, 3 more 3 × 3 convolutions, and two fully connected layers with 64 units
- Network outputs the probability of a successful grasp through a sigmoid
- Each convolution is followed by batch normalization
- Once trained the network $g(I_t; v_t)$ can predict the probability of success of a given motor command, independently of the exact camera pose

next slide:
CNN continuous servoing architecture:
- A servoing mechanism $f(I_t)$ uses the prediction network to control the robot continuously to servo the gripper to a successful grasp
- The servoing mechanism performs inference using the grasp predictor $g(I_t; v_t)$ , in order to determine the motor command $v_t$ given an image $I_t$
- Rather than randomly sample possible $v_t$ commands and feeding these to $g(I_t; v_t)$, run an optimiser to determine the best available command $v^\ast_t$ and thus evaluate $f(I_t)$
- Use the predicted grasp success $p(I=1)$ produced by the network to inform a heuristic for raising and lowering the gripper, as well as to choose when to stop moving and attempt a grasp
- i.e. when the predicted grasp success label becomes TRUE, use a preprogrammed function to cause the gripper to close on the target object

next slide:
Deep Reinforcement Learning Interpretation:
- In the case when T = 2, and only one decision is made by the servoing mechanism:
- The Q-function for the policy is defined by the servoing mechanism f(It) and a reward function that is 1 when the grasp succeeds and 0 otherwise
- Repeatedly deploying the latest grasp network g(It; vt), collecting additional data, and refitting g(It; vt) can then be regarded as fitted Q
- When T > 2 it gets complicated! Read the paper for details…