# introduction to generative models (L14)
###### overview
generative models are useful when your task is e.g.
- image **synthesis** - generating new images
- image-to-image **translation** - for *style transfer*, image **restoration**, etc.

this is different from what we've discussed so far, i.e. image analysis.
generative models..
1. learn the *distribution of the data*
2. create some **new content** from the *learned model*

examples include GAN, VAE, diffusion models.

### generative adversarial networks (GANs)
#### regular GANs
![[Pasted image 20250519205912.png]]

in a GAN, the structure is as follows:
1. the *first model* is a **generator**.
	   - generates new data of the desired type.
	   - alternatively, consider it as a "forger" creating *fake* (rather than real, natural) data
2. the *second model* is a **discriminator**.
	   - ==goal== is to recognise if input data is "**real**" (hence part of the *original dataset*)
	   - or if it is "**fake**" (i.e. produced by the *generator*)

"this model is analogous to having an expert who attempts to establish fidelity or otherwise."

##### formal mathematical description
note that $\theta_{i}$ below represents the *weights* that **define each neural network**.
the **generator** is modelled by a neural network, $G(z, \theta_{1})$
- this maps *input noise variables* **z** -> *desired data space* **x** (e.g. images)
- a **specific** *image latent space* activation is *combined with noise* to generate a **plausible variation** of the image.

the **discriminator** is also a neural network, $D(x, \theta_{2})$
- outputs a probability [0.0..1.0] that the data is real.

the loss/error function used **maximises $D(x)$**, and *minimises $D(G(z))$*
so *if* the discriminator is trained to correctly classify the input data, that means..
- it's weights appropriately **maximise** the probability that any *real* data input **x** is classified as belonging to the *real* data.
- it's weights appropriately **minimise** the probability that any *fake* image is classified as belonging to the real dataset.

###### tomfoolery of the generator
the generator is trained to *fool* the discriminator, by generating data as *realistic as possible*.
thus, the generator's loss function optimises to **maximise** $D(G(z))$
- unlike the discriminator, which minimises it.

specifically, its loss function uses a log of the probability, since it heavily penalises classifiers that are **confident** about an *incorrect classification*

###### eventual GAN state
after several steps of training..
if *the generator and discriminator have* **enough capacity**,
and the *networks can approximate* the **objective functions**..
then a point will then be reached where *both cant improve anymore*.
- the **generator** now generates *realistic synthetic data*
- the **discriminator** is *unable to differentiate* between the two types of input.

this is the eventual result of a minmax game with value function $V(G,D)$
wherein there is a statistic, amount of synthetic data recognised as real,

and 1 agent (**generator**) is *trying to maximise it*,
whereas the other (**discriminator**) *is minimising it*.

![[Pasted image 20250519212707.png]]

###### image code (latent) space arithmetic; also *DCGANs* (**D**eep **C**onvolutional..)
DCGANs demonstrated that GANs can learn from a distributed representation,
that separates the concept of gender from the concept of wearing glasses.
1. begin with the representation of a man with glasses
2. subtract the representation of a man without glasses
3. add the representation of a woman without glasses

and you obtain the vector representing the concept of a woman with glasses.
the generative model correctly decodes all of these representation vectors to images that may be **recognised as belonging to the correct class**.

#### CycleGANs
````col
```col-md
flexGrow=1
===
a major issue with implementing GANs is the requirement for **paired training data**.
- when mapping from domain A to B, examples for the *same instance* of **each domain** are required, for training
```
```col-md
flexGrow=1
===
![[Pasted image 20250519231039.png]]
```
````
CycleGAN removes the need for paired training data, since it learns the **underlying image distributions**, and maps between those.

CycleGAN comprises two generators, each consisting of an **encoder** and **decoder**.

these are two discriminators, each implemented as a **PatchGAN**
- i.e. to evaluate if each local patch is "real" or "fake"

##### mathematical model
![[Pasted image 20250519222145.png]]
the cycleGAN model contains
two mapping functions, $G: X\to Y$ and $F: Y\to X$,
and associated adversarial discriminators $D_{Y}$ and $D_{X}$.

two cycle consistency losses
- to minimise the difference after translating into another domain, and then back.
- *forward*-cycle consistency loss: $x \to G(x) \to F(G(x)) \approx x$
- *backward*-cycle consistency loss: $y \to F(y) \to G(F(y)) \approx y$

##### CycleGAN process
###### horse-first GAN (made up term by me)
1. feed an input image from domain $Do_{A}$ to our first generator, $\text{generator}_{A\to B}$
	   - to transform a given image from $Do_{A}$ to $Do_{B}$
2. feed the newly generated image to another generator $\text{generator}_{B\to A}$
	   - to convert it back into an image, $\text{Cyclic}_{A}$ (from $Do_{A}$)
3. this output image must be *close to the original input image*,
   to *define a meaningful mapping* that is **absent in the unpaired dataset**.
	   - we ==need== cycle consistency *lossses*!

![[Pasted image 20250519223345.png|500]]
###### zebra-first GAN (made up term by me)
![[Pasted image 20250519223401.png|500]]
in the zebra-first GAN, we give a real zebra.
the discriminator then decides which zebra was the original, and which one was subjected to horse insanity.
... I think?

###### purpose of the process
two inputs are fed into each discriminator
- one is the **original** image for the domain
- the other is the *generated* image, via a generator
	  - (or, can be formulated to classify a *single* image as **real/fake**)

the job of each discriminator is to distinguish between these inputs.
- defy the adversary (in this case, the generator) and reject images generated by it.

each generator wants their **generated images** to get *accepted by the discriminator*.
- to make *generated images* very **similar to real ones**

##### example of a CycleGAN working
![[Pasted image 20250519224942.png|500]]
the *input images* $x$, *output images* $G(x)$, and *reconstructed images* $F(G(x))$ from experiments.
top -> bottom: photo <-> cezanne; horses <-> zebras; aerial photos <-> maps

##### generator's encoding, transformation, and decoding pipeline
![[Pasted image 20250519225223.png|500]]
###### encoding
generator's encoding has input an image from domain $Do_{A}$ of size [256, 256, 3]
and output [64, 64, 256]

###### transformation
generator's transformation..
- is combining different nearby features of an image, and making a decision about how to transform that feature vector/encoding
- makes a decision about how to transform that feature vector/encoding

![[Pasted image 20250519230037.png|400]]
in cycleGAN, 6 layers of Resnet blocks were used.
  final output: [64, 64, 256], seen as the feature vector for an image in domain $Do_{B}$

the transformation **resnet** block consists of two convolutional layers
- with a residue of input added to the output,
  to ensure **properties of input** of previous layers are *available for later layers* as well.
	  - so the output doesnt deviate much from the original input.
	  - otherwise, *characteristics of the original image will not be retained*, e.g. size/shape,
	    which would make very abrupt results
	  - residual networks are very suitable for these kinds of transformations.

###### decoding
in the generator's decoding..
- we get another feature vector (from transformation) with size [64, 64, 256]
- the decoding step is the exact opposite of the encoding step.
	  - to rebuild the low-level features back from the feature vector
- this is done by applying a deconvolution (or transpose convolution) layer
- we will convert this low-level feature to an image in domain $Do_{B}$
- and then we finally get an image of size [256, 256, 3]

##### CycleGAN in **discriminator** *mode* (single-image)
in this layout, there is no real image input for comparison.
###### architecture
the discriminator is simply a convolutional neural network in our case.
1. we will extract the features from the image
2. deciding whether these features belong to that particular category or not,
   using a **final convolution layer** that produces a *1-dimensional output*
![[Pasted image 20250519230723.png]]

![[Pasted image 20250519231253.png]]
note: only a single image is to be evaluated as *real* or *fake* as input to the discriminator here.
- though some formulations can use two inputs, as shown in [[#CycleGANs]] above.

##### training a CycleGAN
###### training process
to train the network, there are 2 steps:
1. training the discriminator,
2. and 2. training the generator.

to train the discriminator:
1. the generator generates an output image
2. the discriminator looks at the output and produces a guess on the realism.
3. the *weights of the discriminator* are then **adjusted** via the *classification error of the output*
4. the generator's weights are then adjusted based on the output of the discriminator.

###### Network, Training, and Testing
you can take the cycle consistency loss like $L_{CYC}(G, F)$
and combine it with the adversarial losses on domains
- $X(L_{GAN}(G, D_{Y},X,Y))$ and $Y(L_{GAN}(F, D_{X},Y,X))$

which yields the overall cycleGAN objective, expressed as:
$$L(G,F,D_{X},D_{Y})=L_{GAN}(G,D_{Y},X,Y)+L_{GAN}(F,D_{X},Y,X)+\lambda L_{CYC}(G,F)$$
where..
- $D_{Y}$ is the associated adversarial discriminator that encourages $G$ to translate $X$ into outputs indistinguishable from domain $Y$, and vice-versa for $D_X$
- $\lambda$ is a constant that controls the relative importance of the 2 objective functions $G$ and $F$ in the cycle consistency loss.

##### CycleGAN examples
![[Pasted image 20250519222026.png]]

![[Pasted image 20250519222039.png]]


### variational autoencoder (VAEs)
###### overview
![[Pasted image 20250519215709.png|500]]
autoencoders learn a latent presentation to enable a 1-to-1 mapping between the input and the output.
they are trained by minimising reconstruction loss, e.g. $||x-x'||_{2}$

... so we can generate new output (an image) by feedback-ing "*random*" **latent representation** to the ==decoder==?

##### setup
###### preparing the decoder
![[Pasted image 20250519220653.png|500]]
VAE must first learn the distribution of the latent space.
- i.e. maps input to multivariate normal distribution.

this is trained by minimising **1.** *reconstruction loss*,
and **2.** *kullback-leibler (KL) divergence* to measure *distance loss* between $N(\mu_{x},\sigma_{x})$ and $N(0, 1)$

afterwards.. latent representation can be sampled from such distribution,
and be used as input of the decoder, to generate new images at inference.

###### conditions
you can then add conditions (text, class label, etc.) to ***control** image generation*
- note that the conditions may need to be encoded first.

so the input includes conditions, and so does the latent vector z.

### diffusion (probablistic) models
there are 2 processes you could use:
1. **forward diffusion** process; *gradually map input data* to **noise**
2. **reverse diffusion** process; **generate data** from *pure random noise*, with *iterative denoising*.
	   - (using a trained model)

![[Pasted image 20250519221509.png]]

##### more control on generative models
by providing "conditions" as input (e.g. image, text, class label(s), etc.)
you can get more control.
- e.g. CGAN, CVAE, stable diffusion, etc.

![[Pasted image 20250519221703.png|450]]