# sampling and fourier transform (L2)
### sampling and quantisation
digital processing operates on discrete signals.
to digitally process a *continuous* **analogue** signal, it must be **discretised**; **==quantised==**.

quantisation occurs both in *amplitude* and in *space/time*.
any signal can be perfectly reconstructed, provided the sampling rate is high enough
- nyquist criteria

###### nyquist frequency
the **nyquist criteria** states a signal can be *reconstructed* if sampling at *2 x (highest) frequency*.
- i.e. $f_{s} > 2f_{0}$, where $f_{s}$ is the sampling frequency and $f_{0}$ is the original signal

##### sampling in space
![[Pasted image 20250515132902.png]]

##### aliasing
###### what it is
````col
```col-md
flexGrow=2
===
aliasing is the result of not meeting the nyqist criteria.
as a result, high-frequency components "fold over" into lower ones.
e.g. in **framerate** this makes it seem like **fast objects** are *much slower*.
```
```col-md
flexGrow=1
===
![[Pasted image 20250515133105.png]]
```
````


###### anti-aliasing
aliasing can be removed by **filtering**, which *removes high-frequency* components.
- note that this removes some detail (in the form of sharpness, when an image)

![[Pasted image 20250515133639.png]]

### interpolation & resampling operations (remaking a sampled signal)
preface: look at these samples we took of a signal.
````col
```col-md
flexGrow=1
===
![[Pasted image 20250515134227.png]]
```
```col-md
flexGrow=1
===
![[Pasted image 20250515134219.png]]
```
````
so how do we rebuild? a few options:
- nearest-neighbour interpolation
- linear interpolation
- cubic spline interpolation
- signal reconstruction

````col
```col-md
flexGrow=1
===
#### nearest-neighbour interpolation
![[Pasted image 20250515135311.png]]
```
```col-md
flexGrow=1
===
#### linear interpolation
![[Pasted image 20250515135334.png]]
```
````

#### cubic spline interpolation ==TODO: understand?==
![[Pasted image 20250515135546.png]]
the curve is passed through all specified data points.
the first derivative and second derivatives are both continuous at interior points
boundary conditions are specified at free ends.


![[Pasted image 20250515140316.png]]
for any arbitrary segment of points $(x_{1}, y_{1}), (x_{2}, y_{2}), (x_{3}, y_{3})$, we get
````col
```col-md
flexGrow=1
===
a formula for spline segment **#1** like:
$$\begin{align}
y=&a_{1}(x-x_{1})^3+b_{1}(x-x_{1})^2+c(x-x_{1})+d_{1} \\
y'=&3a_{1}(x-x_{1})^2+2b(x-1)+c_{1} \\
y''=&6a_{1}(x-x_{1})+2b
\end{align}$$
```
```col-md
flexGrow=1
===
a formula for spline segment **#2** like:
$$\begin{align}
y=&a_{2}(x-x_{2})^3+b_{2}(x-x_{2})^2+c(x-x_{2})+d_{2} \\
y'=&3a_{2}(x-x_{2})^2+2b(x-1)+c_{2} \\
y''=&6a_{2}(x-x_{2})+2b
\end{align}$$
```
````

these constraints effectively impose that $y''=y_{1}''$ at $x=x_{1}$ and that $y''=y_{2}''$ at $x=x_{2}$
the constants are derived from requiring $y_{2}'$ in spline 1 be equal to $y_{2}'$ in spline 2.

#### signal reconstruction

##### with impulse responses
![[Pasted image 20250515141718.png]]
we can reconstruct a function by summing up "**impulse response**" functions placed on the sample points, weighed by the sample values.
$$f(x)=\Sigma^{k=\infty}_{k=-\int y}F[k]h(t-kT)$$
the reconstruction of the original function f, from a discrete signal F,
is ideal when the impulse response is the sinc function $\text{sinc}(t)=\frac{\sin(\pi t)}{\pi t}$
![[Pasted image 20250515141656.png]]

there are **other impulses you can use** with this method.
![[Pasted image 20250515142751.png]]

##### with harmonics (fourier transform)
###### preface: signal waveform
![[Pasted image 20250515151104.png]]

###### harmonic analysis
harmonic analysis makes it possible to reconstruct arbitrary signals by superimposing combinations of sines and cosines of differing $A$, $\omega$, $\psi$
![[Pasted image 20250515143659.png]]
- k indicates the precision to which the fourier tries to recreate the signal.
  (how many component waves it uses)

###### *continuous* fourier transform
the *continuous* fourier transform expresses a function F(x) as an **infinite sum** of simple waves (sinusoids) with distinct frequencies, amplitudes, and phases.
````col
```col-md
flexGrow=2
===
$\hat{F}(f)=\int^\infty_{\infty}F(x)e^{-i_{2}\pi fx}dx$

euler formula for complex exponentials:
$e^{i\theta}=\cos(\theta)+i\sin(\theta)$

inversion of fourier transform:
$F(x)=\int^\infty_{\infty}\hat{F}(f)e^{i_{2}\pi fx}df$
```
```col-md
flexGrow=1
===
![[Pasted image 20250515144644.png]]
```
````

###### *discrete* fourier transform
the fourier transform is defined for periodic, continuous functions
for a discrete vector of data $X=x_{0}, x_{1}, \dots, x_{N-1}$, you can you this instead:
````col
```col-md
flexGrow=2
===
$$X_{k}=\Sigma^{N-1}_{j=0}x_{j}e^{-i_{2}\pi k \frac{j}{N}}$$
- where k represents the frequency component of X.
- the results of DFT are a sequence of complex numbers.
```
```col-md
flexGrow=1
===
![[Pasted image 20250515145126.png]]
```
````
### fourier transform and convolution
![[Pasted image 20250515150950.png]]

if we have $f(x)$ and want a **smoothed function** $g(x) = f(x)*h(x)$

````col
```col-md
flexGrow=1
===
we could try using a gausian kernel $h(x)=\frac{1}{\sqrt{ 2\pi }\sigma}\exp[-\frac{1}{2}\frac{x^2}{\sigma^2}]$
```
```col-md
flexGrow=1
===
![[Pasted image 20250515153448.png]]
```
````

````col
```col-md
flexGrow=1
===
note: the fourier transform of a gaussian is a gaussian
$H(u)=\exp[-\frac{1}{2}(2\pi u)^2\sigma^2]$
```
```col-md
flexGrow=1
===
![[Pasted image 20250515154053.png]]
```
````
random note: fat gaussian in space is skinny gaussian in frequency


ok so
==**convolution** in *space* is **multiplication** in *freq*==.
$G(u)=F(u)H(u)$
- H(u) *attenuates* high frequencies in F(u). low pass filter :D

###### practical "example"
![[Pasted image 20250515160017.png]]

###### applications of fourier transform
**image editing** removing *texture*, more patterns and similar *distortions*
**image filtering** - images can be *smoothed* (low-pass filtered) or *detail-enhanced*
**image compression** - chunk images, compute DFT (or similar DCT), and *discard high freqs*.
	- this is how JPEG works (with refinements)
**pattern recognition** - certain patterns are more distinguishable in the *freq domain*.
	- *image patches* can be *transformed* via the *DFT* and matched in a db via *similarity metrics*.
**image alignment** - images can be nicely aligned with *phase diff* of 2 images. (*video frames*)

