# filters into (L3)

#### the basic ones:
![[Pasted image 20250515160847.png]]

## point and area filters
**point filters** are filters that modify independently, *without surrounding pixel info*.
- include operations like *gamma correction*, which **independently scales pixels**.

**area filters** have access to a *limited neighbourhood* of nearby pixels.
- they include operations like **smoothing** and **edge detection**

**area filters** have two further categories:
- *linear* filters, where each pixel `I[x, y]` is a weighted sum of neighbours.
	  - e.g. $I[x, y]=a_{0}I[x, y]+a_{1}I[x-1, y]+a_{2}I[x+1, y]$
- ***non**linear filters*, where each pixel `I[x, y]` is any other function
	  - e.g. $I[x, y]=min(I[x,y], I[x, y+1])$

### point filters
point filters apply a function f(x) to each pixel in an image independently.

###### gamma correction
e.g. gamma correction, a non-linear scaling of brightness $I[x, y]=I[x, y]^{\frac{1}{\gamma}}$
![[Pasted image 20250515162140.png]]

###### quantisation
![[Pasted image 20250515162248.png]]

###### colour transformations
![[Pasted image 20250515162320.png]]

### area filters
#### *linear* area filters
in linear area filters, the output is a *weighed sum* of neighbouring values.
$f(I[X, y]) = \Sigma_{i}\Sigma_{j}I[x+i, j+k]K_{ij}$
where we sum over i rows and j columns around `[x, y]`
$K_{ik}$ are the coefficients matrix, and it is called the **Kernel**.
- the kernel fully specifies the linear filter.

##### effects of local smoothing
![[Pasted image 20250515163708.png]]
observe the image diff. notice there is still some detail from the image.
that means **our noise reduction has in fact removed some detail**.

generally, filtering operations applied to an image *dont conserve the image info*.
filters have to be optimised to be suitable for the specific task.

##### how linear filters work - 1D convolution
###### 1D convolution definition
![[Pasted image 20250515164601.png]]
###### 1D convolution examples
![[Pasted image 20250515164747.png]]

###### 1D convolution kernel normalisation
kernel normalisation is useful to not change the intensity of the signal, e.g. brightness.
$$K_{N}=\frac{K}{\Sigma K}$$
![[Pasted image 20250515165639.png]]

###### 1D convolution algebraeic properties
the convolution operator commutes and associates:
$$\begin{align}
f \ast g=g \ast f \\
f \ast (g \ast h) = (f \ast g) \ast h
\end{align}$$
and also distributes over addition
$$f \ast (g+h) = f \ast g + f \ast h$$
something something efficient implementation of filtering

#### *nonlinear* area filters
##### how nonlinear filters work - 2D convolution
$$H(x, y) = \Sigma^{height}_{j=i}\Sigma^{width}_{i=1}I(i, j)M(x,i, y-j)$$

###### issues with convolution
**time complexity**: convolution is O(MN) for a signal of length M and one of N.
**changed size**: convolving a $W\times H$ image with a $Wk \times Hk$ kernel is $W \times H \times Wk \times Hk$

**edge effects**: convolution is well-defined for infinite signals, but ours are finite in practice.
we need to define what happens  at the edges, ideally according to signal properties.
- Zero: everything is 0, or another constant, beyond the edges.
- Flat: the value at the edge is repeated forever
- Wraparound: self-explanatory (only appropriate for **periodic signals**)
- Mirror: the signal is "reflected" at the edge, so we read out values in reverse order.

##### applications of nonlinear filters

###### unsharp masking
if you smooth over an image, i.e. remove the high frequencies,
and then diff it with the original, the difference you get is whatever you removed.
i.e. your diff shows the high frequencies from the image.

take these "*edge residuals*" and readd them to the img, and *you've effectively sharpened the image*
![[Pasted image 20250516081034.png]]

the unsharp masking operation requires `edge_residuals = input - smoothed`
and then `unsarp_masking = edge_residuals + input`
which is just `(input-smoothed) + input` = `2xinput - smoothed`
this can be expressed in a single kernel, as below.
![[Pasted image 20250516081341.png]]
note that the sum of the kernel is it's "value"
- a kernel with all 0s except one 2 is 0+0+...+2 = 2.
- a kernel with all 1/9 is 1/9+1/9+...+1/9 = 9 x (1/9) = 1.

# edge detection

##### edges as image gradients
discontinuities in intensity are often associated with physical discontinuities in the world, e.g. those caused by
- changes in surface *slope*
- *occlusions* of one surface behind another
- changes in *material properties* resulting in a change in **albeo** (reflectivity)

accordingly, edges have perceptual significance, i.e. they relate to something important in the real world for the observer.

gradients can be estimated as the partial derivates of the image intensity
$$\frac{\partial I(x, y)}{\partial x}, \frac{\partial I(x, y)}{\partial y}$$
for continuous functions:
$$\frac{df(x)}{dx}=\lim_{ h \to 0 } \frac{f(x+h)-f(x-h)}{2h}$$

for discrete domains:
$$(f[x]-f[x-1])\Delta H$$

this can be approximated as:
$$\frac{(f[x]-f[x-1])+(f[x+1]-f[x])}{2}$$

##### robert's kernel
the roberts kernel is a basic **finite difference** kernel. it consists of:
1. a horizontal kernel $K_{h}=[1-1]$
2. a vertical kernel $K_{v}=\begin{bmatrix}1 \\ -1\end{bmatrix}$

the total derivitive at any given pixel is the combination of the horizontal and vertical kernels, $dI=\sqrt{ (K_{h} \ast I)^2 + (K_{v \ast I})^2 }$

![[Pasted image 20250516084814.png]]

##### sobel kernel
the sobel kernel similarly has 2 separate kernels for vertical and horizontal.
````col
```col-md
flexGrow=1
===
vertical kernel:
$$\begin{bmatrix}
1  & 0 & -1 \\
2 & 0 & -2 \\
1 & 0 & -1
\end{bmatrix}$$
```
```col-md
flexGrow=1
===
horizontal kernel:
$$\begin{bmatrix}
1 & 0 & -1 \\
2 & 0 & -2 \\
1 & 0 & -1
\end{bmatrix}^T$$
```
````
it combines edge detection with smoothing, and is symmetric to the central pixel.
it handles *noise* better than the roberts kernel.
![[Pasted image 20250516085820.png]]

##### oriented kernels
the roberts and sobel kernels are "separable"; they can be applied sequentially along the image rows as *2 separate* **1D filter operations**.

to obtain a single edge map, the two edge images must be combined pixel-wise.

kernels can also be **tuned** in orientation, i.e. *ehance edges* in each of the *8 compass directions*.

##### problems with edge filters
**resolution sensitivity**: the filter's sensitivity to edges depends on the resolution of the image. you *cant easily rescale the roberts kernel for a new image size*.

**noise**: the edge detecting filters are a kind of *high-pass filter*.
this does enhance edges, but also **enhances noise**

**false edges**: the edge detecting filters cannot distinguish "true", perceptual edges, from lightness variations that are irrelevant.
*post-processing* is needed to "parse" the edge-enhanced images into meaningful data, and *discard glitches* such as **short isolated edge fragments**, or *coalesce* **broken edge elements** into a single continuous edge.