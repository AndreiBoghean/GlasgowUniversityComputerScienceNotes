# filters II (L4)
#### separable filters
###### why we like separable filters
2D convolutions are expensive
- recall, a $W \times H$ image with a $W_{k} \times H_{k}$ takes $O(WHW_kH_k)$

instead, if we can somehow get 2 1D convolutions instead..
- time complexity is just $O(WHW_{k}) + O(WHH_{k})$; much faster.

but we can only get 2 1D convolutions if **a kernel is separable**
- e.g. gaussian blurring, sobel kernel

###### conditions for a kernel to be separable
a kernel K is *separable* if it can be written as an **outer product** of two vectors
- $K=k_{a}k_{b}^T$

this can be tested by checking the **rank** of the matrix.
- i.e. finding the number of *linearly independent rows*.
- the rank can be computed using methods such as singular value decomposition (SVD)

==separable filters have rank 1==

#### convolution theorem
the convolution theorem states that
the *fourier transform* of the **convolution** of *2 signals*
is equal to the **(elementwise) product** of the *fourier transform* of *two signals*.
- i.e. we can compute the *convolution* by taking **products** of the *frequency/spatial freq domain*
  and then transforming back to the time or spatial domain.

if using fast fourier transform, the time complexity of this process is..
- $O(N_{x} \log N_{x} + N_{x}\log N_{y})$
- where $N_{x}=WH$ and $N_{y}=W_{k}H_{k}$

##### frequency domain effects of filtering (according to conv theorem)
the convolution theorem tells us how the spatial domain convolution affects the frequency domain.

analyse the effects of filters before applying, e.g. downsizing of an image by ratio r
- must ensure no frequency components $\frac{fn}{r}$ before dropping pixels, *otherwise we get alias*.

i.e. the prefiltering kernel K must have DFT(k) so that $|DFT(K)| = 0, > \frac{fn}{r}$
- DFT: discrete fourier transform

##### linear filters in the frequency domain

a linear filter can change the *amplitude* of frequency components,
but it can never introduce new frequencies.
- since it's a weighted sum of the input signal; it cant transmute it but only scale.

==only **non-linear** filters can introduce new frequencies==.

#### random dissing of the gaussian
true gaussian blurring is not practical on a digital image of any size.
this is because *every single pixel* in an image **contributes** to the *blurred value of every pixel*.

instead, we use truncated versions of the gaussian
- such as hamming, hann, blackman-harris, etc.

#### identifying an unknown kernel (dirac moment)
what if we have some black-box filter, and want to find out how it works?
- e.g. the distortion effects of a lens?

if we *assume the system is linear*, then it's transformation will be a **convolution**.
- in fact, many systems can be well-approximated with a linear model,
  and the maths is particularly easy for linear systems.

doing this then reduces our problem to that of estimating K, a convolution kernel,
from data observed from an imaging system.

##### dirac impulse
the diract function $\delta$ is defined as:
- an infinitely tall and infinitely thin pulse/spike whose area sums to infinity.
- it exists at the origin in time $\delta(t)$ at t=0, or in space $\delta(x)$ at x=0, etc. for 2D.

the mathematical definition of the Dirac impulse is then:
````col
```col-md
flexGrow=1
===
1 dimension
$$1=\int^{\infty}_{-\infty}\delta(x)dx$$
```
```col-md
flexGrow=1
===
2 dimensions
$$1=\int^{\infty}_{-\infty}\int^{\infty}_{-\infty}\delta(x, y)dx\ dy$$
```
````
###### why use it?
it's the mathematical equivalent of a *probe*.
- if you apply anything to it, it coaxes out the **characteristic** response.
- e.g. bell with hammer, push car suspension system, voltage spike to electronic filter.

after obtaining a modified signal, we can inspect it to infer the underlying kernel.

###### convolving a dirac impulse in theory
the *convolution process* is defined in terms of the dirac impulse to a filter kernel e.g. M
- $M = M \ast \delta$

the *discrete* form of the convolution is as we saw:
$$H(x, y)=\Sigma^{height}_{j=1}\Sigma^{width}_{i=1}I(i, j)M(x-i, y-j)$$
- where H is the output image, I is the input, and M is the convolution kernel

according to the above property of the dirac impulse, it should be possible to convolve an image containing such an impulse.

the resulting output image should just contain a copy of the convolution kernel used for the definitions to hold true.

what does an image of a dirac impulse look like?
- since the value of the dirac impulse has a unit area, and digital images comprise **intensity values** over a *finite area*, a not unreasonable interpretation might be a **unit valued pixel**

###### convolving a dirac impulse in practice
to perform a dirac impulse test to find an unknown kernel:
1. get an image (of odd dimensions) > 2x expected kernel dimensions (to *avoid edge effects*)
	   - this image should *contain all **0** values*, except for a *single pixel* in the *centre*, **value 1.0**
2. convolve the system to be tested on this image
3. observe the non-zero values generated in the output image,
   which should now theoretically contain the unknown kernel.

*optical systems* also **generate convolutions**, ==point spread functions== (**PSFs**),
as the convolution will spread out a point of light as above.

#### use of PSFs
convolution is, in practice, not a reversible operation.
however if we consider the convolution theorem, then..
$$FT(f \ast g)=FT(f)FT(g)$$
and thus you might write..
$$FT(f)=\frac{FT(f \ast g)}{FT(g)}$$
- i.e. you can *recover* an un-convolved function f by dividing FT(f * g) by FT(g)
  it gives FT(f), and then u invert the FT of that to get just f.
- in practice, **FT(g) may have lots of 0s**, so the division is undefined.
  this division is also incredibly sensitive to any noise in measuring $f \ast g$ or $g$

#### convolution properties
kernels can also be tuned in size:
- *small kernels* suffice for **sharp edges** with ***high** spatial frequencies*.
- *large kernels* are needed for **more blurred edges** with ***low** spatial frequencies*

linear kernels can be combined directly into a single kernel
- ==multiple convolutions can be combined==: $I \ast M1 \ast M2 = I \ast (M_{1} \ast M_{2})$

kernels should *sum to unity*, to avoid adding **offset** or **gain** to the filtered output.
- note: image noise tends to occupy the high spatial frequencies, hence **gradient filters** *amplify image noise*, which is problematic.

#### problems implementing convolution
the usual implementation approach is to compute the convolution directly *for each pixel* in the input image. this has problems at image boundaries.

a good solution is to copy the image into a slightly larger image to deal with edge effects.
- e.g. for a 3x3 kernel, add 2 extra rows and columns, and *extend out the original image to fill*

you can compute the convolution only for the area of the original image
- **no loop tests** are now required to check if the kernel is *crossing the image boundary*

**alternatively**, kernels can be computed by multiplying the input image by each kernel coefficient and storing in a separate image.

these images are then *shifted* and *added*.
- very efficient, esp for **symmetric** kernels, but costly in memory.

#### nonlinear filters - rank order filters.
==rank order filters== rank in *magnitude order* the **pixel values** under a local window,
and then select a given rank as the output pixel, according to some criteria.
- the most common forms are **min**, **max**, and **median**

these filters are **robust**; they work well for both *binary* and *gray* level images.

median filtering is used for *removing **impulsive noise*** without *blurring*.
min and max both shrink and expand binary image features, respectively.

![[Pasted image 20250516121455.png]]

##### categories of rank order filters
###### opening operation (dilation)
if the output rank **>** median, that means it **increases** the *size of the disc*
- favours *brighter*-than-median pixel values
###### closing operation (erosion)
if the output rank **<** median, that means it **decreases** the *size of the disc*
- favours *darker*-then-median pixel values
###### neutral(?) operation
if the output rank **=** median, that means it **maintains** the *size of the disc*
- favours ***uniform** image regions*
- removes *isolated compact features*, e.g. **speckles**.

###### combinations thereof
opening and closing operations can be combined to suppress or enhance features,
according to their *relative brightness*.

##### implementing rank-order filters
for *byte/int/float* images with a *small kernel* (e.g., less than 16x16 window size = 256 samples)
1. use a sorted linked list to represent the window values
2. extract the ***old** window values* and ***insert** new values* as *the window traverses the image*

this gives a *direct index* to **each rank** in the list.


alternatively, for ***large** window byte images*, use a look up table based on a *window histogram*.

#### more non-linear filters
###### bilateral filtering
this blurs pixels less if there's a large *value disparity* in the window
- this preserves edges while blurring out noisy areas

###### morphological operations
these are most commonly used for binary images (i.e. only 0 or 1)
- **erosion** - shrinks the "on" portion
- **dilation** - expands the "on" portion

for non-binary images:
- *erosion* is replaced by "**min**" operations
- *dilation* is prelaced by "**max**" operations
