# image segmentation (L6)
###### segmentation philosophy
to analyse an image's content, you need to break the image into **isolated components**.
these segments can then be processed into symbols or tokens,
and subsequent reasoning can then be applied to the symbolic form.

we assume that image components can comprise:
- **regions** of *uniform* **intrinsic** properties
	  - potentially **uniform texture** (difficult to analyse maybe)
- **edges**, where *regions meet*.
	  - in some sense, edges and regions are dual (*redundant*) representations.

###### segmentation assumptions for an easier life
image segmentation is not grounded in a general theory.

appropriate segmentation can be achieved ad-hoc (heuristics) on a *case-by-case basis*.
- abusing *simple underlying assumptions* that clearly **DONT** hold *generally*,
  but can serve as the basis for useful segmentation algorithms
	  - e.g. uniform image regions correspond to uniform surfaces in the scene
	  - e.g. edges correspond to the interface at real object boundaries.

uniform regions and their edges may have both *physical*, but also *perceptual* **significance**.

###### segmentation uses
you might segment an object to determine its:
- **position**: by computing it's centre location
- **size**: by counting the number of pixels forming its area
- **shape**: by computation applied to its boundary

many vision-based tasks require segmentation e.g.
- *object detection and recognition*: inspection systems, content-based image retrieval (CBIR)
- *post-production manipulation of media images*: isolating actors and props (matte pulling), special effects, background replacement, etc.
- *document analysis/text recognition/character isolation*
- *medical image interpretation and measurement*: isolation of tissue types in MRI slices, X-RAY analysis, etc.

###### what does this lecture cover? USEFUL BIT HERE I THINK
- simple two-region segmentation (foreground object set against a background)
- k region segmentation, with a specified minimum region size
- sampled region segmentation
	- e.g. a user can point to the desired regions which are then segmented automatically
- image subtraction
- colour segmentation
- adaptive segmentation, allowing parameters to vary over the image
	  - as opposed to having global, fixed, segmentation settings.

### (gray) histograms
image histograms are generated from the **gray**-level properties of an image.

the histogram of an image is computed by *counting the number of each shade of gray* found in the image, and displaying this as a **classical histogram**.

#### constructing a histogram
if we have N shades of gray, the histogram can be stored in a 1D array of N elements.
1. initialise H as 0s `for t=1..N: H(t)=0`
2. for each pixel in image, +1 to that shade count. `for g in I(x, y): H(g) = H(g)+1`

#### histogram properties
the basic approach is to consider an image region to have **uniform** grey-level properties.
- near-uniform grey-levels (practically..) is reflected in a peak in the histogram **centred** at the ***mean** grey-level value*

a uniform region will *manifest as a separate peak*, **if**:
1. it's sufficiently large (in area) w.r.t. other peaks
2. it's  got a sufficiently different mean value (otherwise, it merges with other peaks)

in a histogram, darker regions appear (as peaks) on the left,
and brighter regions appear (again as peaks) more to the right.
hence, **histogram valleys** often correspond to the *edge pixels between regions*

all explicit **spatial information** is lost in the histogram.

#### applications of histrograms
##### thresholded images
you can use a histogram to threshold an image
- select dark region `O(x, y) = I(x, y) < t`
- select right region `O(x, y) = I(x, y) > t`
![[Pasted image 20250517103526.png]]

#### histogram modality
each peak in an image corresponds to an (almost) uniform region.
````col
```col-md
flexGrow=1
===
histogram of an img with 2 regions
![[Pasted image 20250517104505.png]]
```
```col-md
flexGrow=1
===
histogram of an img with 3 regions
![[Pasted image 20250517104453.png]]
```
````
the **highest point** in each peak centres on the *mean shade of grey* of the region.

#### histogram limitations (by "pathological" example)
![[Pasted image 20250517104629.png]]
input: top. outputs: below, with thresholds 25, 45, 75, 160.
note that **no single threshold** *captures the entire figure*.
==setting a **double threshold** like `O(x, y) = t2 > I(x, y) > t1`==
==can help detect an intermediate region sometimes==,
but potentially not in this case.

#### histogram function
##### histogram peak analysis
###### modality (number of peaks)
the **==modality==** of a histogram refers to the number of peaks present.
- the modality is assumed to indicate the number of "significant" regions in the image.

a *uni***modal** histogram has *only 1 peak*, **indicating** the image has **1 quasi-uniform region**
a *bi***modal**  histogram has *2 peaks*, **indicating** the image has **2 quasi-uniform regions**

bimodal histograms are the easiest to deal with, and can serve many situations.
- e.g. text and diagram segmentation from scanned documents

a *multi***modal** histogram  contains an arbitrary number of peaks, indicating the image comprises **simple quasi-uniform regions**
- the *higher the modality*, the *less likely the image will comprise* **simple quasi-uniform regions**

###### peak width
the ==broader== each peak is, the greater the *range of shades* is in the **corresponding** *image region*.
- this means it will likely be *harder to segment*

the ==narrower== the peak, the *more homogenous* the **corresponding** *image region* is
- this means it will likely be *easy to segment*

#### histogram as a probability distribution
if we *divide through* the histogram (element-wise) values by the image pixel count,
we now have a **probability distribution for each shade**.
- `p(g) = h(g)/(N*M)` = probability of grey level g.
	  - h(g) is the histogram, and N&M are the image dimensions in pixels.

==this gives u the *grey-level* **probability density function** (*PDF*)==
- a histogram with values in the range 0..1
- this indicates the density (likelihood) of finding a pixel of a given shade of grey,
  when inspecting the image locally.

#### (coloured) histograms
the aforementioned concepts extend to colour images in several ways:
- we can compute **separate 1D histograms** for each of the *red, green, and blue colour panes*.
- we can convert to a *different colour space*, and histogram this.
- we can compute a single **3D histogram for rgb simultaneously**, to get a 3D histogram with a *PDF of each unique colour*.

#### segmenting an image with histograms
##### bimodal histogram (p-tile method)
it's helpful to have additional info about the image we're segmenting
- the potential *contrast phase* (*light on dark* / vice-versa) of the **target region to be isolated**
- the *nominal size of the target region*, as a percentage of the whole image or a fraction.
	  - this fraction is the **prior probability** of a *random pixel* being *within the target region*.

knowing the above allows us to simply *search from the target shade end* of the histogram,
**summing the fractions** of the image contained in *each (normalised) histogram bin*,
until this corresponds *most closely* to the **fraction of the image** we believe *the target occupies*.
- thresholding segmentation is then used at the histogram gray level to separate out the desired fraction of the image.

this approach is simple, but not very robust.

###### concrete algorithm for naive histogram search (single threshold)
1. search for the histogram *peaks*, i.e. **bin values**, bounded by lower values..
	- `H(h) > H(n+1)` && `H(n) > H(n-1)`
2. rank these by *peak value* order
3. between the highest pair of peaks, search for the **lowest histogram valley**.
	   - i.e. bin values bounded by the lower values `H(n) < H(n+1)` && `H(n) < H(n-1)`

the **lowest valley between the highest pair** of peaks *is the threshold*

problem with this: the histogram may be "noisy", with many peaks close together.
- i.e. the second peak may be right next to the first
- synthetic images may have *several maximum bins of the same height*.

solution for this: filter, e.g. smooth, the input image.
- this results in a smaller range of histogram values
	  - (may need **severe smoothing**; *computationaly intesive* and *distorts the image*)
- this also results in fewer local valleys
	  - which may *reduce the peaks too much*.

###### estimating a threshold
an alternative approach to segmentation can be based on the following heuristic:
1. select an initial estimate for t
2. segment the image using t.
	   - this will produce 2 groups of pixels, $G_{1}$ with pixels > t, and $G_{2}$ with <= t
3. compute the *average grey level values*, $\micro_{1}$ and $\micro_{2}$, for pixels in $G_{1}$ and $G_{2}$
4. compute a *new threshold value* $t=\micro_{1} + \micro_{2} \div 2$
5. repeat steps 2 through 4 until the difference in t in successive iterations meets a predefined threshold $t_{0}$

![[Pasted image 20250517120430.png]]

##### generalising the estimator for k regions (k-means clustering)
suppose we know that we have **3** *regions*.
that means we need to find **2** *thresholds*. (to separate them)

0. either select initial values for the ***2** thresholds*, or for the ***mean** grey levels* ($\mu_{1}$, $\mu_{2}$, and $\mu_{3}$)
1. as before, segment the image into 3 regions using the 2 current thresholds
2. compute new mean values ($\mu_{1}$, $\mu_{2}$, and $\mu_{3}$) for each region.
3. compute new thresholds: $t_{1}=(\mu_{1}+\mu_{2}) \div 2$, and $t_{2}=(\mu_{2}+\mu_{3}) \div 2$
4. **halt**, *if* the thresholds ($t_{1}$ and $t_{2}$)  have **stabilised**, *else iterate* from step 1.

it's straightforward to extend this algorithm to **k** regions.
editor's note: doesnt this assume the regions are equi-distant in their means?

##### user-defined regions
in certain situations, it may be known in advance where specific regions in an image are likely to be located.
- e.g. in an inspection system, *parts are likely to be presented to the inspection camera in the **same position***.  this means *definite fg and bg images can be determined in advance*
- in photo booths, the **centre** will *likely contain* the *subject's face*, and **corners** the *background*
- in photo editing, a user might be given the option to select the centre location of an object and background regions.

knowing where *samples of the pixels* of the **regions of interest** *can be obtained*
means that *good initial estimates* can be obtained for **mean values of the regions**.
- useful for the aforementioned algorithms.
- without *user prompt*, a *one-shot version* based on *a single pass of the algorithm* may even work

### background subtraction

###### what it is
if a *reference image* is available, this can be used to provide a better segmentation.

when the target object enters the scene, a *target image* is captured.
the ref image is then numerically subtracted from the target image, revealing differences.

these changes are usually predominantly caused by the presence of the target object.
the difference image can then be thresholded as before, to find the target object's region.

note that negative intensity values may appear in the img diff.
so you should take the **modulous** of the diff, or **re-scale** to a *positive range of gray levels*.
- where the target and the background have the same gray level, holes will appear in the target.

###### dealing with changing backgrounds
background subtraction works, as long as..
- the camera hasnt moved
- everything else in the FOV is the same
- there are no new non-target objects
- the lighting is the same
- the target's presence hasnt significantly changed the scene (e.g. lighting, reflections)

it's often necessary to devise methods for updating the reference image to accommodate changes in the scene and ambient illumination.
the usual approach is to **store a running average of images**.
- $T_{n} = (1-\alpha)T_{n-1} + \alpha I_{n}$, where $\alpha$ [0..1] sets the fraction of the *input image* $I$ that is accumulated into the average reference image $T$ for the nth input sample
  (initialise T with a known good reference image)

![[Pasted image 20250518094528.png]]
![[Pasted image 20250518094537.png]]

#### colour segmentation (using background subtraction)
##### how it's done
the most direct colour segmentation process either..
1. assumes a **background image is available**
2. or the bg colour has been sampled, to get a *mean background colour* $\mu^{bg}$

you then compare the vector distance of the input RGB values *to the mean* using
- $D(x, y) = [(r(x,y)-\mu_{r})^2+(g(x,y)-\mu_{g})^2+(b(x,y)-\mu_{b})^2]^{\frac{1}{2}}$

or, comparing with a background reference image..
- $D(x, y) = [(r(x,y)-r_{bg}(x, y))^2+(g(x,y)-g_{bg}(x, y))^2+(b(x,y)-b_{bg}(x, y))^2]^{\frac{1}{2}}$

in both cases, a distance image D(x, y) has now been formed,
that can be segmented using gray-level techniques

it's sometimes advantageous to convert from RGB to hue, saturation, intensity
and then make the comparison based on hue alone.
- this affords a degree of invariance to illumination changes, by basing the segmentation only on the primary colour information.

##### colour space conversion
to increase the contrast between foreground and background objects,
we can *change to a different colour space*.

e.g. by doing intensity = $(r+g+b) \div 3$, **2.** RG = $(r-g) \div (r+g)$, **3.** BY = $(b-y) \div (b+y)$
- (note: yellow = red + green)

![[Pasted image 20250518104416.png]]
with this new colour space, the red target shows strongly against the green background,
in the RG channel of the space.
- (there are some remaining bright spots as a result of div by 0 artifacts)

#### dealing with illumination effects
illumination gradients have the effect of *smearing the histogram peaks*.

in fact, the *background could become lighter* than the foreground in some areas,
making **global segmentation based on a single threshold** *impossible*.

the solution is to **break the image** into sub-images, and then *threshold these independently*.

##### basic adaptive sub-division
1. *subdivide* the image into 3 sub-images, and sub-divide again (16 sub-images).
2. compute the *variance* (spread or range of values) in each sub-image
3. if the *variance is >= v*.. it **likely has 2 regions**, so *compute a threshold on this block*
	   - otherwise.. the block is probably almost uniform.
4. for all **uniform** *blocks*.. treat them together as a composite image, and *threshold as before*

this test represents a homogeneity criterion.

![[Pasted image 20250518105821.png]]
see that
- results are generally better
- 2 segments failed to segment, as they contained too small an area of bg to be detected.
- the histogram looked essentially unimodal for these blocks

also: increasing the subdivision improves the *spatial resolution of the segmentation*.
![[Pasted image 20250518111202.png]]