
# multi-resolution images; pyramids (L7)
## images at different scales
##### concept of image scale
scale is important when attempting to detect, identify, and classify images of objects.
scale can also be important when tracking objects, regardless of their size or proximity.

### multi-resolution (the image pyramid technique?)
multi-resolution is important from a computational perspective.
the idea centres on processing an image within a "pyramid" data structure
- this involves taking the image, shrinking it by a fixed amount (2x), and recursively repeating this process to generate a "pyramid" of increasingly small images.
- each smaller image is progressively "coarser".

we can apply **scale-independent** *processing* to this multi-resolution image data structure to achieve efficient computation over a range of image scales.

such techniques are also useful for guiding **efficient** *image search processes*,
and **scale-independent** *feature extraction* used in object recognition and DB search.

##### image scale issues (justification for image pyramids)
as we've seen, scale is important when extracting image features such as edges.
generally, **we dont know** the *range of scales of structures* **that will be present** in an image in advance.

we only know that:
- the *smallest feature* is limited by the **size of a pixel** (==inner structure==)
- the *largest feature* is limited by the **size of the whole image** (==outer structure==)
- a continuum of possible scales can exist in an image, *between the above extremes*

clearly, we *cant construct filters for every possible scale*,
therefore we need a method to allow us to **apply** the *same algorithm* (or kernel) **regardless**
**of the scale** of image feature present.

##### progressive scale change
this is the basis for a unified framework for *managing image analysis* over **differing scales**.

![[Pasted image 20250518133112.png]]
varying the blurring parameter $\sigma$ for a gaussian filter allows us to compute filters with different degrees of attenuation of high frequencies (low-pass)

applying this set of filters to an image as above gives a set of images containing features according to their *spatial scale*.
- think of the gaussian kernel as a centre-weighted averaging filter.

examining the above sequence of filtered images from *coarse->fine* scale, we see that, as **high frequencies are introduced** (with reducing scale), *new levels of complexity appear*.

however each *new feature that appears in a given scale then persists* and evolves into subsequent scales, i.e. **each new scale contains all the information of the previous scale**.

hence it's possible to **track/trace these features** *between coarse->fine* images.
- the evolution of image features with scale is referred to as the ==image deep structure==,
  and understanding this is the subject of cutting-edge research.

###### low-pass blur
frequency response of low-pass gaussian filters:
- high frequencies are attenuated according to $G(\omega)=\exp(\frac{-\omega^2 \sigma^2}{2})$,
  where $\omega =2\pi f$, and f = cycles/pixel.

![[Pasted image 20250518133323.png]]

#### scale space decomposition
###### what it is
it's more useful to attempt to *isolate the **new** information* to the **scale at which it** *appears*,
i.e. represent the information difference between scales.

to do this, and image can be deconstructed into a *series of bandpasses*.
each bandpass comprises only a *range* of **image spatial frequencies**.
- c.f. an audio system that breaks a signal into bass, mid, and treble

information is now (partially) separated between spatial scales.
- there is **overlap** *between scales*, which gives **continuity** when *comparing scales*.

![[Pasted image 20250518140001.png]]

###### scale space properties
with each *new scale*, the only information passed is that which is
**associated with the bandpass** frequencies of that scale.
this increases in resolution/complexity as scale *size decreases*.
- less scales, means the info is divided less, so *each individual diff contains a bigger portion*.

each *new feature that appears* in a scale **subsequently persists and evolves** into *future scales*.
- this is because image information tends to be contained in edges, and these edges contain **spatial frequency harmonics** present over a *range of scales*.

a feature will have the strongest "repsonse" (i.e. contrast) in the scale that is most closely matched to the size (i.e. scale) of the feature.
- this is similar to tuning a radio to receive specific frequencies, only we're now working with 2D signals and 2D spatial frequencies.

it's possible to track/trace features across scales, with less interaction between scales.
- e.g. when finding edges, we could employ a coarse-to-fine strategy
  first to find large strong edges, and then associate (i.e. trace along scales) these
  with their finer (smaller) versions at finer (higher-resolution) scales.

###### building scale space
we could make the above set of images by *subtracting images filtered with gaussian* kernels of **differing** $\sigma$.
alternatively, we can *form a kernel* comprising the **difference of two gaussian functions** of differing $\sigma$, and then apply this combined kernel to the input image.

varying each of the two $\sigma$ parameters for the difference of gaussians filter allows us to compute **filters with different bandpasses**, ("sub-bands") that can be understood as effectively *operating at different spatial scales*.

the closer the *two gaussians are in size*, the *narrower the range of frequencies* passed by the DOG filter, and vice-versa.

as it happens, a good ration of $\sigma$ to choose for the gaussians is 1.6.
- in this case, the DOG kernel closely approximates a laplacian of gaussians (LOG)
- LOG discussed l8r in course.

###### effect of filter scale (size)
the gradient *magnitude* at different scales (controlled by $\sigma$) is different.

different features are emphasised according to scale.
- at fine scales, **fine detail is preserved**, at the expense of *emphasising noise as well*.
- at coarse scales, **noise is suppressed**, but *fine details are lost* while *strong features remain*

which scale should we choose?
this is addressed with ==image pyramids==

#### image pyramids
##### overview
having **decomposed an image** into a low-passed (or band-passed) **image set**,
it's possible to represent this set within a *multi-resolution pyramid*.
- pyramids provide *increased storage efficiency* & a *uniform basis* for **analysis** over scales

it's possible to represent each image scale with a reduced number of pixel samples,
according to the nyquist sampling criteria.
- the **coarser** the *scale*, the **lower** the *max (significant) frequency present*.
- there's fewer samples (pixels) required in total to capture 2 samples/cycle as per the nyquist sampling criteria.

here r image pyramids with gaussian, and DOG.
![[Pasted image 20250518144333.png]]
**expanding and summing** the *pyramid levels in the DOG* pyramid *reconstructs the original* img.

##### building pyramids
###### gaussian pyramid overview
gaussian pyramid basic operation:
gaussian filter -> sub-sample by factor of p; repeat for next level as before
- a *sub-sampling (decimation) factor* $p=2$ is typical, but $\sqrt{ 2 }$ *useful for image matching*.
- note, a sub-sampling factor of p *reduces the effective size of **sigma*** by p

it's possible to combine **sub-sampling and convolution** into a *single operation*.
- e.g. if *sub-sampling by a factor of **2***, simply **step the kernel over every second pixel** of the input image to *output a half-resolution image*.

###### assembling pyramids
to construct a regular pyramid:
1. apply an *initial* filter of $\sigma_{init}$
2. filter subsequent levels by the same constant, $\sigma_{c}$
3. sub-sample by the same $p$ factor at each level.

to combine filtering and sub-sampling:
1. sub-sample x2 by stepping the filter kernel over every second pixel
2. filter subsequent levels by the same $\sigma_{c}$

##### gaussian pyramid requirements
###### what the requirements are
we would like to have the *same **apparent** level* of blur at *every level in the pyramid*.

recall:
- in a digital imaging system, a diract impulse comprises a unit (1.0 valued) pixel set against a black (0.0 valued) background.
- applying any linear kernel filter to a diract stimulus will generate the kernel itself.

when we apply the pyramid to a diract impulse image, the impulse response at each level in the pyramid should be the same, i.e. $\sigma_{0} = \sigma_{1} = \sigma 2 \dots \sigma_{i}$

since *the response is the same* at each level, we can apply the **same analysis algorithms** at each level such that they *respond in the same manner*.
- the only thing that should change is the scale (size) of the structures from the image.

we need to determine, for a given reduction $p$, what is the relationship to $\sigma_{c}$ and $\sigma_{init}$

###### meeting the requirements
each level of the pyramid shown earlier can be implemented efficiently by
repeated convolution of a gaussian filter, $\sigma_{c}$, sub-sampled by a factor p.

by inspection we can observe that, for the $i$th pyramid level,
we can find the blur $\sigma_{i}$ for the *current level* via $\sigma_{i} = \frac{1}{p} \sqrt{ \sigma^2_{i-1}-\sigma^2_{c} }$
then substituting $\sigma_{i} = \sigma_{0}$ and $\sigma_{i-1} = \sigma_{0}$ in the equation gives $\sigma _c = \sigma_{0}\sqrt{ p^2-1 }$
- where $\sigma_{0}$ should ideally equal the intrinsic blur (pre-existing) in the input image
  (for $\sigma_{c}$ to remain constant at each level.)

for an octave pyramid $p=2$ and $\sigma$ increases in powers of 2 for each level.
- therefore $\sigma _c = \sigma_{0}\sqrt{ 3 }$. (since $\sigma_{c} = \sigma_{0}\sqrt{ p^2-1 } = \sigma_{0}\sqrt{ 2^2-1 } = \sigma_{0}\sqrt{ 3 }$)
- alternatively, in the case of a pyramid with $p=\sqrt{ 2 }$, then $\sigma_{c}=\sigma_{0}$

the effective $\sigma$, had they not been reduced, is $\sigma_{\text{effective}} = \sigma_{0}p^i$
- note, i is numbered such that 0 corresponds to the finest scale.

##### existing blur in gaussian pyramids.
in the previous pyramid construction, no intrinsic blur has been assumed.
however, any image captured with a real (optical) imaging device
will typically exhibit a finite **==point spread function==** that may well approximate a gaussian sufficiently for the purposes of pyramid construction.

assuming we've measured the intrinsic input image blur, $\sigma_{image}$,
the correct value of $\sigma_{0}$ is simply $\sigma_{0}=\sqrt{ \sigma^2_{init} - \sigma^2_{image} }$

if the intrinsic image blur $\sigma_{image}$ is known, the extra blur, $\sigma_{init}$, required to reach $\sigma_{0}$
can therefore be calculated from $\sigma_{init}=\sqrt{ \sigma_{0}^2 - \sigma^2_{image} }$

so having an initial level of blurring by $\sigma_{init}$ might seem redundant,
but it allows us to tune the remaining filter $\sigma_{c}$ parameters to be *the same for each level*.

it also allows us to generate any arbitrary degree of blur for each level
- useful if we want to compute *gaussian derivatives* at each level

##### gaussian and DOG pyramids
````col
```col-md
flexGrow=1
===
top: a gaussian pyramid and histogram of the top level
bottom: a DOG pyramid and histogram of the top level

notice the difference between the *histogram* structure
the top version has teh full image grey-levle structure present
the bottom histogram only shows the *distribution* of **highest spatial frequency** *second order gradients* (zero mean)
```
```col-md
flexGrow=1
===
![[Pasted image 20250518155148.png]]
```
````

##### expanding pyramid levels
![[Pasted image 20250518160134.png]]
to **expand** by (gaussian) interpolation, use 2 gaussian kernels A & B applied to the same window in the input img, but with their *gaussian functions displaced by +/- 0.5 a pixel w.r.t. each other*
- the output from these kernels subsequently fills *two consecutive output pixels*.

since the current level of blur, $\sigma_{i}$, is combined with the expansion $\sigma_{e}$,
the total blur $\sigma_{\exp}$ becomes $\sigma_{exp}=p\sqrt{ \sigma^2_{i}-\sigma^2_{e}}$

the above example illustrates a factor of 2 expansion,
showing how *disparity maps can be expanded between pyramid levels*

##### DoG & LOG pyramids
the DOG pyramid can be created from the gaussian pyramid.
1. convolve the current level with a gaussian filter
2. sub-sample
3. apply a second gaussian convolution, with $\sigma=p\sqrt{ \sigma^2_{i} -\sigma^2_{e} }$
   to get a second image, now blurred with a $\sigma$ of 1.6x that of the current level's blur
4. substract this additionally blurred level from the original level, i.e. compute the difference of gaussian-filtered images.
5. repeat for next level as before.

$DOG(I_i(x,y)) = I_{i}(x,y)-G_{\sigma}(I_{i}(x,y))$

some approaches to the above involve expansion and subtraction of pyramid layers,
however these approaches contain intrinsic innacuracies.

a LOG pyramid can be constructed similarly by
1. getting the *second order partial derivatives* (horiz & vert) at *each level of the gaussian pyramid*
2. adding these together to form each new level.

##### pyramid uses
- multi-resolution image processing, and efficient scale-space tracing.
- *anti-aliased* image zoom-in and zoom-out
- multi-resolution preview structure for above:
	  - view images at *any octave resolution* (penalty of 1/3 *storage increase* for octave pyramid)
	  - preview image operations in low-res while *computing full-rez in background*
- possible to couch many image analysis algorithms on pyramids to obtain scale-independent processing:
	  - at each level of the pyramid, apply the *same* operator, e.g. run a kernel to enhance a specific pattern and detect instances.
	  - starting at the **coarsest level**, *detect instances of the pattern*
	  - at the next level search, *refine the previous estimate* by searching around the **location found in the previous level**, and detect new instances.
	  - note: this process is good for simple patterns such as edge segments.


###### more..
in general, search over a pyramid is a 2-step process:
1. **apply the same detection** algorithm at *all levels*
2. for **each instance** found at each level, *refine the solution at higher levels*.
	   - refinement search is now highly constrained.
	     e.g. if the expansion factor between levels 2 we *only need to search 5 pixels in the next level*.

pyramids first propoed by burt and adelson in 1980s for image coding using *LOG pyramid*.
they also proposed seamless image splining:
1. merge two images without a join using pyramids
2. form DOG pyramids for each image
3. average each pyramid level over a constant N pixels, N usually = 1

no seam visible as each scale averaged over an appropriate spatial distance of N at each scale.
DOG pyramid is the basis for the SIFT recognition algorithm.

###### pyramid seamless splining
far left input images are converted to pyramids as is the mask image (half white/black)
the mask pyramid and it's inverse are used to select opposite halves of the input images.
these halves are averaged by *1 pixel overlap at each level*, and *expanded to form a complete image*
![[Pasted image 20250518163242.png]]