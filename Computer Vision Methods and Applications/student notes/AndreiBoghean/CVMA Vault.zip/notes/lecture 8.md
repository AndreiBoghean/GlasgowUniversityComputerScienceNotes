# machine learning (L8)
#### machine learning vs statistics
ML is slightly distinct from statistics, which is traditionally concerned with making *inferences* from data; e.g. determining if an effect is present in a scientific study.

instead, machine learning focuses on trying to *estimate the value of unknown variables* given **some data which might predict them**.

ML makes minimal assumptions about the data-generating systems.

**classical statistics make assumptions** about the model that fits the data,
and vary considerably from ML in terms of *computational traceability*.

classical statistics normally can deal only with a few dozen variables,
and sample sizes are relatively small.

##### what is machine learning?
it's a subset of **artifical intelligence**. learn automatically and improve from experience.
ML itself is comprised of *supervised*, *unsupervised*, and *reinforcement* **learning**

#### supervised learning
in **supervised** learning, the learning makes use of **labelled datasets**
![[Pasted image 20250518183516.png]]

another example is predicting the length of hospitalisation in cancer,
given a BMI and actual length of hospitalisation.

#### unsupervised learning (clustering)
clustering is an unsupervised machine learning technique designed to *group **unlabled** data*
- e.g. relationships between people, relationships between proteins

![[Pasted image 20250518183930.png]]
- the data is not labelled, **the model groups it** according to *patterns it sees*.

something something, if you want to discover an unknown structure,
use principal component analysis, which is a technique used to simplify a large data set into a smaller one while maintaining significant patterns and trends

#### supervised vs unsupervised ML

| supevised                                        | unsupervised                         |
| ------------------------------------------------ | ------------------------------------ |
| learning to approximate reference labels/answers | learning underlying data structure   |
| requires *correct labels*                        | no labels or feedback is required    |
| model does not affect the input data             | model does not affect the input data |
#### k-nearest neighbours (KNN)
![[Pasted image 20250518185001.png]]
KNN is an algorithm for supervised learning (classification/regression)

it uses distance metrics to decide which group to relate a new datapoint to.
````col
```col-md
flexGrow=1
===
euclidean distance
$$d(x,y)=\sqrt{ \Sigma^N_{i=1}(y_{i}-x_{i})^2 }$$
```
```col-md
flexGrow=1
===
manhattan distance
$$d(x,y)=\sqrt{ \Sigma^N_{i=1}|y_{i}-x_{i}| }$$
```
````
![[Pasted image 20250518185233.png]]

#### data encoding
###### ordinal (integer) encoding
basically: assign numbers to ur stuff.
blood type **A+? 1**. *A-? 2*. **B+? 3**. *B-? 4*. **AB+? 5**. *AB-? 6*. **O? 7**.

###### one-hot encoding
basically, each of ur options has a dedicated bit in a binary string.
**A+? 1000000**, *A-? 0100000*, **B+? 0010000**, *B-? 0001000*, **AB+? 0000100**, *AB-?, 0000010*, **O? 0000001**
#### model performance
##### evaluation vs model selection
![[Pasted image 20250518185743.png]]
have 3 phases: train, eval, test.

##### overfitting and underfitting
![[Pasted image 20250518190226.png]]

###### overfitting: high variance
the model is **hyper-flexible**, and has *learned irrelevant characteristics* from the training data.
- it performs poorly on the testing data

###### underfitting: bias
the model *cannot capture the complexity* of the data (few parameters)
- it's very stubborn

###### polynomial fitting example
$y = a_{0} x^0+a_{1}x^1+\dots+a_{q}x^q$
![[Pasted image 20250518190240.png]]

###### avoiding overfitting; k-fold cross validation
![[Pasted image 20250518190721.png]]
**cross-validation** is a re-sampling procedure used to evaluate ML models.
one key advantage is that the testing samples are **independent** between folds.
there is a need to control the class' distributions of the training/testing data.

###### other (sub)sampling methods
- **hold-out method**
- **simple resampling methods**
	  - k-fold cross validation
	  - stratified k-fold cross validation
	  - leave-one-out cross validation
- **multiple resampling methods**
	  - nested k-fold cross validation
	  - random sub-sampling
	  - bootstrap sampling
	  - permutation testing

##### performance metrics

###### F1 score
the F1 score is a way of combining the precision and recall of the model.
it's defined as the **harmonic mean** of the model's *precision* and *recall*.
$$F_{1} = \frac{2}{\frac{1}{\text{recall}} \cdot \frac{1}{\text{precision}}}=2 \cdot \frac{\text{precision} \cdot \text{recall}}{\text{precision} + \text{recall}}$$

###### receiver operating characteristic (ROC)
````col
```col-md
flexGrow=1
===
the ROC curve is a performance measurement
for **classification problems** at *various threshold settings*.

ROC is a **probability curve**.
AUC represents the *degree/measure of separability*

the ROC curve is plotted with TPR against the FPR,
where TPR is on the y-axis, and FPR is on the x.
```
```col-md
flexGrow=1
===
![[Pasted image 20250518180225.png]]
```
````

##### comparing algorithm performance
###### NHST
![[Pasted image 20250518180335.png]]

null-hypothesis statistical testing for algorithm evaluation.
the **t-test** is a *statistical hypothesis test*, in which the *test statistic* follows a student's t-distribution **under the null hypothesis**.

common assumptions include:
- independence of measurements
- normality
- adequate sample size
- equality of valiance in standard deviation.

###### non-parametric tests (wolcoxon)
the **wilcoxon signed-rank test** is a general test to *compare distributions in paired samples*.
this test is usually the *preferred alternative* to the **paired t-test**
- used when t-test's assumptions (e.g. normal distribution) are not satisfied

it determines if the two populations seem to be the same or different,
based upon the ***ranks** of the absolute differences*.
- *ranking procedures* are common in **non-parametric methods**, since they *moderate the effect of any outliers*

##### image classification example
problem: train an alg to identify whether these images were taken during the day or night
![[Pasted image 20250518181737.png]]
for any given classification problem, we need to prepare our input data for the algorithm.
- features, labels, (X,Y) pos.

this is a *binary* classification problem. labels are 0, 1

one approach would be to use colour histograms.
![[Pasted image 20250518182031.png]]