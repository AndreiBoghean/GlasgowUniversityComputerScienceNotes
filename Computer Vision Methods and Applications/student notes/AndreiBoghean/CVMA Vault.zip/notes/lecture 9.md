# intro to deep learning (L9)
###### what does it try to do?
mimic how brain neurons communicate and learn.
- allows a high level of abstraction in learning.
- eliminates the need for handcrafted features
- state-of-the-art in image recognition
- high demand in data and computational power

###### deep learning and big data
![[Pasted image 20250518192512.png]]
traditional ML doesnt scale nicely when you feed it more data. deep learning does.

###### different vision tasks
![[Pasted image 20250518192911.png]]

## the perceptron
````col
```col-md
flexGrow=2
===
perceptrons are inspired from how brain neurons work.
input is connected to the output via an *activation function*.
it can learn to classify **linearly separable patterns**.
$y(x)=F_{A}(W^Tx)$
```
```col-md
flexGrow=1
===
![[Pasted image 20250518193050.png]]
```
````
the bias term introduces an offset to the function.
the input to the bias term, $x_{0}$, is always equal to 1.
$y(x) = F_{A}(w_{0}x_{0}+w_{0}x_{1}+\dots+w_{n}x_{n}) = F_{A}(w_{0}+w_{0}x_{1}+\dots+w_{n}x_{n})$

###### multiple outputs
![[Pasted image 20250518193635.png]]

### multiple layer perceptron
the neural network multi-layer perceptron (NNMLP) are **feed-forward** *neural networks*.
they consist of >=3 layers of nodes: the input, hidden, and output layer.
![[Pasted image 20250518193826.png]]

###### is dense
each neuron in a layer receives an input from all the neurons present in the previous.
- hence, they're **==densely connected==**
- in other words - the dense layer is a **fully connected layer**.

##### activation functions
internal nodes of a network are *processing functions*.
**activation functions** are required to be differentiable functions
- *small change in the **weight*** results in a *small change in the **output***.

**activation functions** are *monotonic*, but their derivates are not.
- monotonic: *consistency **increases/decreases*** throughout its domain. *never changes direction*.

###### sigmoid (a.k.a. logistic function)
````col
```col-md
flexGrow=1
===
popular for neural networks. input is transformed between 0.0 and 1.1
```
```col-md
flexGrow=1
===
![[Pasted image 20250518194540.png]]
```
````

###### tanh (hyperbolic tangent function)
````col
```col-md
flexGrow=1
===
produces a 0-centred output, thereby supporting **backpropagation**. mostly used in *recurrent neural networks*
```
```col-md
flexGrow=1
===
![[Pasted image 20250518194616.png]]
```
````

###### ReLU (rectified linear unit)
````col
```col-md
flexGrow=1
===
is a simple function allowing models to account for non-linearities and interactions
```
```col-md
flexGrow=1
===
![[Pasted image 20250518194629.png]]
```
````

###### Leaky ReLU
````col
```col-md
flexGrow=1
===
circumvents classical ReLUs problem where 0 gradient deactivates neurons in the region of x < 0, causing the dying ReLU problem.
```
```col-md
flexGrow=1
===
![[Pasted image 20250518194640.png]]
```
````

###### Maxout unit
````col
```col-md
flexGrow=1
===
a generalisation of leaky/regular ReLU. a piecewise linear function that returns the *maximum of the inputs*. both leaky/normal ReLU are special cases of maxout.
```
```col-md
flexGrow=1
===
![[Pasted image 20250518194649.png]]
```
````

###### ELU (exponential linear unit)
````col
```col-md
flexGrow=1
===
tends to converge cost to 0 faster and produces more accurate results. different to other activators, ELU has an extra alpha constant that should be positive.
```
```col-md
flexGrow=1
===
![[Pasted image 20250518194659.png]]
```
````

###### softmax
````col
```col-md
flexGrow=2
===
- useful when the *total sum of the output of a layer* **needs to be 1**.
- used to produce a vector of probabilities.
- common in the last layer of deep NNs for multi-class classification.
```
```col-md
flexGrow=1
===
![[Pasted image 20250518194709.png]]
```
````

###### hierarchical softmax
useful when the # of classes is high, making regular softmax too expensive.
approximates probability distributions as a binary tree with larger depth corresponding to less probable class activations.


#### training an MLP (TODO: understand)
there are 4 phases to training an MLP:
1. forward propagation
2. error computation
3. backpropagation
4. parameter update

##### forward propagation
![[Pasted image 20250518200513.png]]

##### error computation
![[Pasted image 20250518200530.png]]

##### backpropagation
![[Pasted image 20250518200606.png]]

##### parameter update
the **hyperparameters** in a multi-layer perceptron (NNMLP) are normally:
- learning rate
- layer size
- regularisation constant

something something **weight initialisation**

**grid search** is a basic *hyperparameter tuning method*
1. builds a model for *each possible combination* of all the hyperparameter values
2. evaluates each model
3. selects the architecture which produces the best results

#### optimisation process
##### gradient descent
````col
```col-md
flexGrow=2
===
$\theta_{t+1}=\theta_{t}-\alpha \nabla_{\theta}E$

this approach minimises the loss function *iteratively*.
1. computes the slope (gradient): *first-order derivative* of the function at the **current point**
2. move in the **opposite direction** of the *slope increase* from the current point
```
```col-md
flexGrow=1
===
![[Pasted image 20250518201116.png]]
```
````

###### convex vs concave functions
![[Pasted image 20250518201147.png]]

###### convergence in DNN
![[Pasted image 20250518201555.png]]

##### stochastic gradient descent
in **stochastic** gradient descent, there's an additional process:
1. take each sample
2. feed it to a *neural network*
3. calculate it's *gradient*
4. use the gradient to update the weights.

something somthing minibatch gradient descent

###### learning rates
![[Pasted image 20250518202053.png]]
a *small* learning rate **slows down training**, and might be prohibitive in large models.
a *large* learning rate causes **large parameter jumps**, and subsequently *divergence problems*

##### types of loss function
![[Pasted image 20250518202228.png]]
![[Pasted image 20250518202235.png]]
![[Pasted image 20250518202243.png]]
![[Pasted image 20250518202251.png]]

##### regularisation; why?
![[Pasted image 20250518202349.png]]
regularisation is a set of techniques that helps reduce under/overfitting;
it's a small hit in training data, for a larger improvement in test data.

````col
```col-md
flexGrow=1
===
###### L2 regularisation
![[Pasted image 20250518202804.png]]
```
```col-md
flexGrow=1
===
###### L1 regularisation
![[Pasted image 20250518202819.png]]
```
````

###### regularisation - dropout
![[Pasted image 20250518203006.png]]
the **dropout** layer is a mask that nullifies the contribution of some neurons towards the next layer, and leaves unmodified all others.

it can be applied to the **input vector**, in which case it *nullifies some of it's* **features**,
but we can also apply it to a **hidden layer**, in which case it *nullifies some hidden* **neurons**.

##### normalisation
![[Pasted image 20250518203146.png]]
normalisation of the input data is a standard process for ML models.
it involves removing the mean, and dividing by the standard deviation.
it **reduces the amount** the *weights of the NN need to shift*.

##### more regularisation
###### batch normalisation
batch normalisation is a technique to normalise the output of each layer of a network.
it estimates a *moving average* and *variance* during **training**.

batch normalisation **accelerates training**, since it **reduces convergence time**.
the *mean* and *S.D.* are calculated over the mini-batches, using $\gamma$ and $\beta$ (*learnable parameters*)
![[Pasted image 20250518203706.png]]