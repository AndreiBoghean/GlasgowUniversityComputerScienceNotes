sidebar -> right click notes folder -> export to pdf -> export each file to PDF
custom size 148x630; no margin; no downscale (i.e. 100%); portrait.

EXCEPT lecture 3, downsacle = 77%
AND lecture 7, downscale=73%