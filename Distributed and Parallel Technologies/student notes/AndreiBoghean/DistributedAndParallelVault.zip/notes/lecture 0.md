##### motivating the need for distrib and parallel
computing *architectures* are increasingly **parallel**
- 2-12 core phones, 16 core (hyperthreaded) laptops/desktops, server-class machines with 32 or 64 cores, GPUs with 500+
- machines in data centres with many other machines
- "frontier" supercomputer with a combined 8,699,904 cores.

*hardware* is increasingly **heterogeneous**
- big cores (CPUs), little cores (low power phones), FPGAs, TPUs, analog compute

the challenge is - how do you *understand* and *write* software that can **target**
such a *wide array of devices*?
while properly **exploiting the benefits** of these devices; *scale, performance, energy efficiency*.

##### moore's law
there is still a (near) exponential growth in the *number of transistors per chip*
- non-trivial to get to 1-2nm

performance/frequency per core is *not* increasing (much)
- programs dont really get faster anymore just because the hardware did.
- pushing frequency at this point just melts the chip.

workarounds?
- more caching; multiple cores per chip; novel architectures

##### multi-core hardware
there are lots of cores around that we can use to run our software :D
but we need to write code that can use them D:
keeping *code up to **scale** with the hardware*; does my code *targeting 8* cores *still perform on 16*?

further challenge: devices have many different *types* of cores
**GPU cores**, *vector processors*, **low-power (E cores)**, *tensor processing units (AI cores)*, **FPGAs**.

these all enable performance, throughput, and energy sustainability
but how do we use the **right compute** for the *right job*?
- how much do we expose to the programmer?
- can we use the compute without understanding all it's details?
- what is the porting effort for existing code?

##### memory architectures
###### shared memory architectures
in shared memory architectures, there is a single (possibly virtual) address space.
- threads synchronise on shared variables
- programming models: pthreads, Go, OpenMP, etc.

**locality** is not a *huge* issue; high bandwidth with low latency memory access lets you make do, but if you **need** every cycle of performance then *maybe an annoyance*.

but *there is limited scalability* (~32 cores/socket (& memory bus) b4 *contention kills performance*)

###### distributed memory architectures
in distributed memory architectures, there is *no direct memory access*
- synchronisation done instead via explicit messages (assuming no DMA)
- networks are *scalable* (thanks to fancy topologies e.g. dragonfly)
- low bandwidth, high latency.

sets up *high performance computing* e.g. ***cloud*** (maybe with adaptable networking) or ***clusters***
since it allows 100s+ of (full-featured) cores

##### hybrid memory architectures
###### overview
hybrid architectures may have elements of both shared and distributed memory.
- racks of shared memory machines connected via networks
- different memory on one machine: CPU memory + GPU memory
	  - this is still "distributed" but the bandwidth/latency is different
- most systems are *Non-Uniform Memory Access (**NUMA**) architectures*
	  - some memory blocks are closer to certain cores.
	  - still "shared" memory (*single address space*) but performs like *(fast) distributed memory*.
	  - lots of effort is put into pretending memory is flat/uniform.

###### challenges
how to best utilise the components?
- *placement* of **computations**
- *placement* of data? data **replication**?
- **communication** of data? when to *communicate*? when to *recompute*?

what are the programming models?
- do we need two languages? one local, one remote?
- how to port *tricky abstractions*?
	  - e.g. moving a thread barrier to distributed threads *works* **but** *kills performance*

##### why use multiple compute units?

**parallelism**
- do many things at *once* towards a common goal. make things faster.

**concurrency**
- express computations as interactions between different threads.
- a way to structure programs; *less concerned with **performance***.
- **GUI** is *concurrent to the model* underneath.

**distribution**
- some problems need multiple hosts. e.g. TESCO cant have 1 single point of sale.
- locality constraints; wireless sensors are *locality based*.

**mobility**
- robustness to failures
- microservices *moving over a cloud*

##### some metrics
###### for parallelism..
how well does the program use extra cores?
- if it takes 1h on 1 core, how many hours on 10k cores?
- to use HPC facilities, you need to **demonstrate** *you can scale with more cores*.

###### for distributed systems..
requests per second?
specific service-level agreements e.g. uptime, response latency, QoS
delivery requirements: how many cores to deiver 30bn whatsapp texts per day?

##### reliability
failures can be expensive :(
distributed systems mitigate them via *redundancy*.
- multiple software copies on multiple hosts (maybe multiple locations)
- the microservice architecture is based on this

problem:
more points of failure (network cards, drives, etc.) and more chance of component failure

###### reliability solutions
HPC:
- buy very expensive hardware with low failure rates
- *checkpoint* progress regularly.
- if something fails, stop everything, resume from checkpoint.
	  - scales, very easy to implement, utilises fancy parallel file systems well
	  - can take ages to get rescheduled

cloud systems:
- *buy cheaper commodity hardware* (standard intel class)
- understand *things will fail*
- *embed recovery* in frameworks: microservices, hadoop/mapreduce, erlang, scala/akka

note that these are all *just hardware failures*; you **still need your business logic to be right**!

##### programming multithreaded software
"concurrency is hard because concurrent systems can be in a lot of different possible states, and the number of states grows much faster than anyone is prepared for."

it's *already difficult to get sequential software right*, **handling** *correctness, architecture, efficiency*.
multithreaded also has the *additional consideration* of **coordination**.
- when and how are resources being used. where the states explode.
###### coordination aspects
**partitioning**
- what parts of the computation *can* and **should** be *broken up*?
- large partitions might not use all the resources; small ones might use too many.

**placement**
- *local* or *distributed*? where is the data/memory?
- what if my computation *moves*? **should** it *move*?

**communication**
- what data to send? when to send? should we **just recompute** instead?

**synchronisation**
- handle the "state space explosion"
- how should threads *interact*, who has *priority*, on *which resources*?

**scheduling**
- which thread executes next? (esp. 4 concurrent programs)
- is there an *ordering needed* even over **distributed hosts**?

**fault tolerance**
- how to *detect* failures?
- how to *recover* from failures?
###### coordination in programming models
different *programming models* have different ways to think about coordination.
they have different tradeoffs
- some **dont allow** *accessing the scheduler*; some **abstract** all *memory access details*

they have different levels of control
- **pthreads** (almost) gives "*full control*" but that's high effort to get right.
- **go** is mid-level; has **DMA** control, but gives *primitives to help structure*.
- **openMP** is high-level; say what you want, and *hope the compiler does something good*.