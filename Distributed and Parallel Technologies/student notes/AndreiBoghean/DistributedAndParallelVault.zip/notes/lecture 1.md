note: processes have their own (virtual) address space.
- important for distributed memory concurrency
- even on one host, this is essentially distributed (due to page security)

`cat file.txt | sed -e 's/foo/bar` is *technically* **concurrency** *synchronised on stdin/out*

### threads
##### overview
threads are sequences of instructions *within* a process; **using shared address space**.
the OS (usually) maps these to *physical* threads.
- you can use the posix thread standard to maintain portability.

the definition of "threading" is overloaded with meaning.
- lightweight "green" threads,
- hardware threads

they have the same "sequence of instructions" semantics, but *different implementations*

##### thread lifecycle
you can **fork** to create a thread with a specified set of instructions (usually a func (func*))
and then wait until it finishes by **join**ing another thread. (assuming it does finish)

```cpp
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <assert.h>

void* printHello(void*) {
	printf("Hello from a thread\n");
	return NULL;
}
int main() {
	pthread_t t;
	// (Thread id, attributes, fn, args)
	int e = pthread_create(&t, NULL, printHello, NULL);
	assert(e == 0); // No error
	// Second arg is address for ret value
	e = pthread_join(t, NULL);
	assert(e == 0); // No error
}
```

### synchronising threads
u need communication between threads to organise them.
communication needs some *resource*.
- usually memory when you have a shared address space, otherwise file handles, network, etc.

##### data races
**critical region**
- code area where shared resources need to be consistent, e.g. constant value

**mutual exclusion**
- ensure only a single thread is ever in a critical section.
- using a *mutex*/*lock*; a **shared flag** + **atomic** (hardware) *memory instruction*. (*compare+swap*)

**acquire/release**
1. obtain lock before executing the critical section (code blocked until it gets the lock)
2. *release* lock after done with critical section

`````col
````col-md
flexGrow=1
===
```cpp
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <assert.h>

static int counter = 0;
pthread_mutex_t m;

void* foo(void*) {
	for (int i = 0; i < 1000000; i++) {
		pthread_mutex_lock(&m);
		counter = counter + 1;
		counter = counter - 1;
		assert(counter == 0);
		pthread_mutex_unlock(&m);
	}
}
```
````
````col-md
flexGrow=1
===
```cpp
int main() {
	pthread_t t1, t2;
	pthread_mutex_init(&m, NULL);
	pthread_create(&t1, NULL, foo, NULL);
	pthread_create(&t2, NULL, foo, NULL);
	pthread_join(t1, NULL);
	pthread_join(t2, NULL);
	pthread_mutex_destroy(&m);
}
```
````
`````

###### no progress?
if no thread can make progress; we get **deadlock** :(
you can also **livelock**, when threads are working but *keep passing back and forth unproductively*

you can try using *lockfree parallelism* which is a **guarantee of progress**.
if we can remove data from a structure then one thread will *eventually* manage.

##### condition variables
they enable "something happened, please check" behaviour e.g. when *a buffer gets a value*
they help to *avoid busy* waiting. you can **wait** for a cond var, and **signal** a cond var.

```cpp
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>

static int counter = 100;
static pthread_mutex_t m;
static pthread_cond_t c;

void* zeroer(void*) {
	pthread_mutex_lock(&m);
	while (counter != 42) {
		pthread_cond_wait(&c, &m);
	}
	counter = 0;
	pthread_mutex_unlock(&m);
	return NULL;
}
```


```cpp
void* setter(void*) {
	sleep(rand() % 5);
	pthread_mutex_lock(&m);
	counter = 42;
	pthread_mutex_unlock(&m);
	pthread_cond_signal(&c);
	return NULL;
}

int main() {
	pthread_t t1, t2;
	pthread_mutex_init(&m, NULL);
	pthread_cond_init(&c, NULL);
	// (Thread id, attributes, fn, args)
	pthread_create(&t1, NULL, zeroer, NULL);
	pthread_create(&t2, NULL, setter, NULL);
	pthread_join(t1, NULL); pthread_join(t2, NULL);
	printf("Counter: %d\n", counter);
	pthread_cond_destroy(&c);
}
```

##### semaphores
semaphores are a higher level abstraction.
they *consist of a **counter**, **mutex**, and **condition varaible***.
they *count* how many items of a resource are available.
you can wait, which **decrements the semaphore** or blocks if < 0
you can signal, which **increases the semaphore**, and *by consequence signals waiting threads*.

##### futures
futures are another higher-level abstraction. they represent *possibly* uncomputed values
you can **pass them around**, so the *creating thread* doesnt need to be the **reader**.
`Future f = async(f)` is common.

##### barriers
we might need to wait for all threads to be done with some action before proceeding.
such barriers are common in scientific processing where you compute a round, wait,
compute the next round, etc.

barriers are basically a counter that **wakes all threads** once **n** threads call *wait*.