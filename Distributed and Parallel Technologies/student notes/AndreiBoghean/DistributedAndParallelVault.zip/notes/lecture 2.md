###### a common pattern of parallelism (*fork-join-parallelism* below)
a lot of parallel programs follow a similar pattern:
1. read in a bunch of *data that needs processed*
2. fork a bunch of threads to *process this data in parallel*. (ideally *minimal synchronisation*)
3. wait til all *the threads are done*
4. *do something* with the results

###### OMP assesable constructs
- omp parallel
- omp parallel for (and how *different schedules* work)
- private, shared
- omp reduction
- omp parallel task
### OpenMP ("open multi-processor-ing")
##### what is OpenMP
OpenMP is an API for shared memory parallelism
- actual implementations may differ, e.g. using pthreads vs win32 threads.

it is **directive-based**; uses special *pragmas* to denote *where parallelism should go*.
- this is a high-level but limited form of explicit communication

probably the most widely used shared-memory paradigm.
- sometimes combined with others e.g. OpenMP + MPI within HPC.

##### hello world example
```cpp
include <omp.h>
#include <stdio.h>
int main(int arc, char* argv[]) {
	#pragma omp parallel
	{
		printf("Inside parallel\n");
	}
	return 0;
}
```

##### components of OpenMP
**compiler directives**. various adoption; in Fortran, C, C++, not in haskell.
**runtime library**. liked with -fopenmp. features functions for e.g. active threads, etc.
**environment variables**. *dynamic configuration*, portability (e.g. different NUM_THREADS)

##### compiling openMP programs
OpenMP is compiler based so there's no library to link (*unless you're using the runtime tools*)
instead it's a compiler flag `gcc -fopenmp -o hello_omp hello_omp.c`
different compilers can produce **different** (but *still to spec*) code. (leaky abstraction?)

##### fork-join parallelism
1. start a *team* of threads (fork)
2. divide work between them
	   - challenge with deciding how/when this is done.
3. wait til they all finish (join)

##### big idea of openMP
programmers should focus on **defining** the work, **not** on ***how** the work* is distributed, threads spawned, barriers, etc.

##### OMP pragma-code equivalence
`````col
````col-md
flexGrow=1
===
```cpp
pragma omp parallel
{
	someFn();
}
```
````
````col-md
flexGrow=2
===
```cpp
omp_create_team(...);
parallel_for (t : team) {
	t.someFn();
}
omp_team_end(...); // Includes a barrier
```
````
`````
these 2 code snippes are *functionally equivalent*.

##### number of threads
the default number of **hardware** *threads* can be > number of cores.
this is ==hyperthreading==.

to control this, you can specify the OMP_NUM_THREADS variable, as an easy way to try scaling out behaviour.
but you can also *set* an **explicit NUM_THREADS** for a region.

##### OMP **parallel for**
OMP's parallel for is the most widely used.
it simply executes the for loop in parallel, with *different indices passed to different threads*.
- note that indices must support *intervals* over the data. (tho int usually anyways)

this is kind of like ***SIMD** data parallelism*
with a single instruction (the for block) operating over different data depending on what thread you're looking at.

###### example 1
```cpp
int* xs = (int*) malloc(sizeof(int) * 100000000);

#pragma omp parallel
{
	#pragma omp for
	for (int i = 0; i < 100000000; i++) {
		xs[i] = (i*5) - 2;
	}
}

for (int i = 0; i < 10; i++) {
	printf("xs[%d] = %d\n", i, xs[i]);
}

free(xs);
```

###### example 2
```cpp
...
int main(int arc, char* argv[]) {
	int* xs = (int*) malloc(sizeof(int) * 1000000000);
	
	#pragma omp parallel for
	for (int i = 0; i < 1000000000; i++) {
		xs[i] = (i*5) - 2;
	}
	for (int i = 0; i < 10; i++) {
		printf("xs[%d] = %d\n", i, xs[i]);
	}
...
```

##### shared memory
as always, *controlling memory is key*.
- private(i, ...) says i should be localised to each thread; they *need their own copy in memory*
- shared(x, y) lets **any thread** *access x or y without copy*. basically a **reference**.

this is similar to call-by-value vs call-by-reference

##### controlling chunking
how to determine *what thread gets what*?
this is non trivial. there are many parameters to tune.

there is a **schedule** option. can take a *chunksize* that is static (since pragmas moment)
- schedule(*static*, chunksize) - *round robin* **based on chunk size**
- schedule(*dynamic*, chunksize) - create iterations of chunk size. *threads take work when they need more*.
- schedule (auto) - compiler/runtime implementation specific.

##### reductions
parallel for is useful when the data remains disjoint, e.g.
- when you read an index and write back to that index (no one else touches it)
- when you read and write to *different* arrays

sometimes you want to *collapse* loop iterations to a single value.
- e.g. reduce, fold, sum, etc.
- e.g. count the number of "1"s in a large structure; sum all values

OMP has syntax for this.
```cpp
#include <omp.h>
#include <stdio.h>

int main (int argc, char* argv) {
	float a[N], b[N];
	
	// Generate some random data
	for (int i = 0; i < 100; i++) {
		a[i] = i * 1.0; b[i] = i * 2.0;
	}
	
	float result = 0.0f; // Implicitly shared (could add a shared clause)
	#pragma omp parallel for reduction(+:result)
	for (int i = 0; i < 100; i++) {
		result = result + (a[i] * b[i]);
	}
	printf("Final result = %f\n",result);
}
```

##### task parallelism
many applications fit nicely into data-parallelism, especially in science,
but *sometimes you need more flexibility*.

what if you dont know what work is available ahead of time, or have different data structures not supporting for loops?

here, we can use **task parallelism**.

it is a similar fork/join structure as before, but with some flexibility.
- *tasks can **spawn** other tasks*
- "waiting" *threads can **take** tasks*
- join when *all tasks are **complete***

```cpp
// Very silly fib implementation!
unsigned long long fib(unsigned long long n) {
	if (n <= 2) { return 1; }
	unsigned long long fib_minus_1, fib_minus_2;

#pragma omp task shared(fib_minus_1)
{
	fib_minus_1 = fib(n-1);
}
#pragma omp task shared(fib_minus_2)
{
	fib_minus_2 = fib(n-2);
}
#pragma omp taskwait
	return fib_minus_1 + fib_minus_2;
}
```

```cpp
int main(void) {
	unsigned long long res = 0;

	#pragma omp parallel shared(res)
	{
		#pragma omp single
		{
			res = fib(30);
		}
	}
	
	printf("Fib(30) = %llu\n", res);
	return 0;
}
```

##### OMP benefits
cross-platform uptake (linux, windows, cray, intel, AMD)
*incremental* program updates. you *might* need large restructuring
often you can get parallelism benefits for just a few pragmas on loops.

##### OMP disadvantages
not all languages are supported
*only supports **shared** memory* (often coupled with *MPI* for this reason)
limited error handling (however, a hot topic). programmer *responsible for **not dumb** code*.
limited fine-grained control (have to rely on the compiler to get it right)

###### can fail silently
```cpp
...
#pragma parallel omp for
	for (int i = 0; i < 1000000000; i++) {
		xs[i] = (i*5) - 2;
	}
...
```
here, it should be "omp parallel for", but *compiles and just ignores* the OMP calls