## go
### language basics

##### overview
go is a systems-level language that's low-level with pointers and memory manipulation.
it's focus is on being a small language with a small std lib.
it has **static types** and **type safety**, **automatic garbage collection**, simplified use of pointer, and *built-in support for concurrency*

##### hello world
```go
// Real packages
package main

// #include like
import "fmt"

func main() {
	fmt.Println("Hello World") // No semicolon needed
}
```

to build, you can `go mod init hello # in dir with hello/hello.go`
and then `cd hello`; `go build`; `./hello`

##### typing
has usual c-like types *bool*; **string**; *int*; **int8**, ..; *uint*; **uint8**, ..; *float32*; **float64**

```go
var i int = 42 // explicitly typed
var i := 42 // infered typed
```

also **strong typed** so no `var x float = 3`; must `var x float = float(3)`

##### functions
```go
func add (x, y int) int {
	return x + y
}
```
as with variable declarations. types go after both params and functions.
`x, y int` is syntactically equivalent to `x int, y int`.

##### loops
###### for
```go
sum := 0
for i := 0; i < 10; i++ {
	sum += i
}
```

###### while
```go
func hcf(x, y int) int {
	var t int
	// Equivalent to for ; y != 0; { ... }
	for (y != 0) {
		t = x % y
		x = y
		y = t
	}
	return x
}
```

##### pointers
**no pointer arithmetic**
```go
func main() {
	i := 42
	p := &i
	fmt.println(*p)
	*p = 21
	fmt.println(i)
}
```
##### structs
```go
type IntPair struct {
	A int
	B int
}
func main() {
	p := Pair{1,2}
	fmt.Println(p)
	fmt.Println(p.A)
}
```
also no -> syntax to access pointer members; can still use just .

##### arrays
fixed size arrays: `var arr [5]int {1, 2, 3, 4, 5}`
**slices** are ***referential*** *views* on arrays: `v := arr[0:2]`

##### time measurement
```go
package main

import ("fmt" "time")

func main() {
	start := time.Now()
	var sum int
	for i := 0; i < 1000000; i++ { sum += i }
	end := time.Now()
	elapsed := end.Sub(start)
	// Alternatively
	// elapsed := time.Since(start)
	fmt.Println("Elapsed time: ", elapsed)
}
```

##### printing
`fmt.PrintLn("text", var, "more text")`
or sometimes `var str string = fmt.Sprintf("cant parse something")`

### concurrency in go

###### concurrency vs parallelism
primitives are about *structuring* a computation by **breaking it apart** into several (*coordinated*) computations that **==maybe==** execute in *parallel*.
- the computation must still be correct even if it **doesnt** execute in *parallel*.

- "**parallelism**" experts assume *some hardware*, and match a computation to it.
- "**concurrency**" experts express coordination of tasks, and *distribute across hardware* *maybe*, if they **can**.

###### runtimes vs libraries
concurrency is *built-in* to go; it's not a library.
- this permits better runtime system support, specific syntax/language constructs, etc.

it's historically quite common to have built-in concurrency/parallelism.
- erlang, occam, concurrentML, etc.

utilising existing untimes via libraries is a (relatively) recent research idea.
- Scala Akka (JVM), cloud haskell

#### goroutines
###### overview
goroutines are ==lightweight== "threads" managed by the go runtime.
go f(x, y, z)
caveats:
- x,y,z evaluated in the *current* go routine.
- non-blocking; continues execution once f is launched.

###### goroutines are plentiful and in userspace
go handles many (millions) "lightweight threads".
these are **multiplexed** onto *OS threads*.
- these r much *cheaper* to create/manage in **user-space**, than pthreads in the kernel.
sometimes these r called "green threads"

###### goroutines have **no handles**; possible cuz distrib mem.
**no handle for created thread**, and hence..
- no return value.
- no control over it once it spawns

this is unlike C++ async or javascript.

also, no location is specified, since it's ***shared memory** only*.
- in distributed memory, we might expect `go f() on machine1`

#### channels
*channels* move values from one **goroutine** to another.
they are **synchronous** (by default); both the sender and receiver *need to be waiting*.
channels themselves are **values**. you can pass, return, and even *send them with other channels*
==channels are the synchronisation primitive; they're *not* memory locations.==

##### example
```go
package main
import "fmt"
func sum(s []int, c chan int) {
	sum := 0
	for _, v := range s {
		sum += v
	}
	c <- sum // Send a value down c
	// No return, since it's a thread
	// and we sent the value in a channel
	// instead
}
```

```go
func main() {
	s := []int {7, 2, 8, -9, 4, 0}
	c := make (chan int)
	go sum(s[:len(s)/2], c)
	go sum(s[len(s)/2:], c)
	// Blocking so wait for the sums
	x, y := <- c, <- c
	fmt.Println(x, y, x+y)
}
```

##### buffered channels
fully synchronous channels can be painful bcuz you typically want to leave a buffer to *get work from as soon as you are finished with the previous thing*.

buffered channels allow **n** elements at once. they **block** when full/empty.
- the classic bounded buffer with condition vars example you probably saw in pthreads.

###### example
```go
package main
import "fmt"
func main() {
	ch := make(chan int, 2) // 2 element bounded buffer
	ch <- 1
	ch <- 2
	fmt.Println(<- ch)
	fmt.Println(<- ch)
}
```

##### closing channels
a channel can be closed with `close(ch)`

when consuming from a channel, you can consume a 2nd parameter that gives u a bool
for whether the channel is closed

```go
v, ok := <- ch
if !ok {
	return
}
```

this logic can be thrown into your goroutine, but there is also explicit syntax for
"recieve from a channel until closed". it involves passing the channel to `range` like
```go
package main
import "fmt"
func summer(in_ch chan []int, out_ch chan int) {
	for s := range in_ch {
		sum := 0
		for _, v := range s { sum += v }
		out_ch <- sum
	}
	fmt.Println("Done!")
	out_ch <- 0
}
```

```go
func main() {
	s := []int {7, 2, 8, -9, 4, 0}
	in := make (chan []int, 10)
	out := make (chan int)
	go summer(in, out)
	in <- s[:len(s)/2]
	in <- s[len(s)/2:]
	close(in)
	x, y, z := <- out, <- out, <- out
	fmt.Println(x, y, x+y)
	fmt.Println(z)
}
```

##### recieve only channels.
for better type safety, you can specify a *direction* on a channel; send or recv only.
- this only makes sense in local scope, since each send needs a recv.
  note the *type checker doesnt check this*.

```go
// c is recv only
// d is send only
func worker(c <-chan int, d chan <- bool) {
	<- c
	d <- true
}
```

##### channels are first-class
channels can be *stored* and **passed down** *other channels*.
this is a very powerful idea; pi-calculus is based on this.
e.g. a *worker can create new workers* and pass their management to the *main goroutine or other supervisor*

##### selecting communications from multiple channels (multiplexing)
goroutines can take *input from multiple channels*. using `select` which..
- **blocks** until *any case can run*
- **random** if *multiple are ready*
- **default** if you *dont want blocking*

###### example
```go
func adder(c, quit chan int) {
	x, y := 0, 1
	for {
		select {
			case x <- c: x, y = y, x + y
			case <- quit:
			fmt.Println("Quit");
			return
		}
	}
}
```

```go
func main() {
	c := make(chan int)
	q := make(chan int)
	go func() {
		for i := 0; i < 10; i++ {
			fmt.Println(<-c)
		}
		quit <- 0
	} ()
	adder(c, q)
}
```

##### non-determinism
go concurrency can lead to non-deterministic behaviour.
- *random* selection between channels
- **multiple** senders (random send order)
- **multiple** recievers (random consume order)
- goroutine *scheduling order* (implementation defined)

this can all make **debugging** *difficult*
- a *common issue* with concurrency code in general
- often needs *higher-level* **property** thinking; "for *all **orderings**, P will eventually be true*"

##### synchronisation
channels simplify synchronisation.
- no explicit *locking requests* or **direct sharing**.

there is an *implicit* ownership transfer through the channel.
- not enforced; systems like session types can track this.

this can aid in scaling, meaning new "helpers" can *monitor the channels transparently*.
- no need to know *how* output channels are configured, **you just send**

##### mutual exclusion and other primitives
channels are the preffered communication/synchronisation method,
but sometimes *you want to synchronise on a **shared value*** e.g. some *global identifier **generator***

you could try doing this with goroutines.
you could also try using the **sync** package, which provides the usual primitives
- mutexes, cond vars, concurrect data structures (maps)

###### mutual exclusion *example* with **channels**
```go
func counter(
	c chan string, val chan int64) {
	// Functions are /closures/ so can hold local state
	var count int64 = 0
	for {
		op := <-c
		switch op {
		case "inc":
			count++
			fmt.Println("inc")
		case "dec":
			count--
			fmt.Println("dec")
		case "val":
			val <- count
			fmt.Println("val", count)
		default:
			panic("unrecognised operation")
		}
	}
}
```

```go
func sendIncs(c chan string) {
	for i := 0; i < 10; i++ {
		c<-"inc"
		time.Sleep(1*time.Millisecond)
	}
}

func sendDecs(c chan string) {
	for i := 0; i < 5; i++ {
		c<-"dec"
		time.Sleep(2*time.Millisecond)
	}
}

func sendVals(c chan string) {
	for i := 0; i < 3; i++ {
		c<-"val"
		time.Sleep(3*time.Millisecond)
	}
}
```

and lastly
```go
func main() {
	c := make(chan string, 20)
	val := make(chan int64, 10)
	go counter(c,val)
	go sendVals(c)
	go sendIncs(c)
	go sendDecs(c)
	time.Sleep(100*time.Millisecond)
	// Wait for goroutines to finish (in practice do something more sensible!)
}
```

###### mutual exclusion *example* with **sync package**
```go
var count int64
var cmutex sync.Mutex

func doIncs() {
	for i := 0; i < 10; i++ {
		countMutex.Lock()
		count++
		countMutex.Unlock()
		fmt.Println("inc")
		time.Sleep(time.Millisecond)
	}
}

func doDecs() {
	for i := 0; i < 10; i++ {
		countMutex.Lock()
		count--
		countMutex.Unlock()
		fmt.Println("dec")
		time.Sleep(time.Millisecond)
	}
}
```

```go
func main() {
	count = 0
	countMutex = sync.Mutex{}
	go doIncs()
	go doDecs()
	// Wait for goroutines to finish
	time.Sleep(1000*time.Millisecond)
	fmt.Println("counter value", count)
}
```