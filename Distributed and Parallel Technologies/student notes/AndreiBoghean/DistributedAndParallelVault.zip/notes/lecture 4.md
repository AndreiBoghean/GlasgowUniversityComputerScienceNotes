###### preface: shared memory space. message passing.
so far we've considered *shared-memory* processes, where threads have **direct access** to shared memory, that needs constructs to mange this e.g. critical regions, etc.

what if we want to support multiple memory spaces?
- essential to scale to multiple machines/hosts
- possibly useful on a single host

### MPI

##### overview
MPI is a message passing **specification** *designed for high-performance*.
- supercomputers are essentially designed for MPI.
- remember the specification vs library vs language vs compiler spectrum.

many implementations exist (cray, until, open, etc.) that are *in theory* **compatable**, but are sometimes optimised e.g. cray for supercomputers.

many programming languages have a **binding to MPI**.
- contract to OpenMP: libraries can do this because they *dont modify compilers*.

##### single-program multiple-data
```c
if (proc_id == 0) {
	// Do something
} else {
	// Do something else
}
```

every process runs the same program, directly from main,
with explicit conditionals for roles.

MPI is kind-of like having an `omp parallel` around the whole program.
- launching the *processes* and *calling* is a **fork**. (potentially over multiple nodes)
- processes *finishing* is a sort of **join**.
- *usually* no dynamic process spawns, unless using "elastic" MPI runtimes (*research thing*)

##### hello world
```c
#include <stdio.h>
#include <mpi.h> // for MPI specification calls

int main(int argc, char ** argv) {
	MPI_Init(&argc, &argv); // Start MPI
	
	// MPI Sets up "communicators" between processes
	// WORLD is a communicator between all processes (you can make your own if needed)
	int nump, id;
	MPI_Comm_size(MPI_COMM_WORLD, &nump); // Get number of processes
	MPI_Comm_rank(MPI_COMM_WORLD, &id); // Get rank within communictor
	
	printf("I am %d of %d\n", id, nump); // payload
	
	MPI_Finalize(); // Stop MPI
	return 0;
}
```
##### how to compile
`mpicc hello_mpi.c -o hello_mpi`
- *not* a compiler plugin like openMP.
- all it does is *set includes*/**link libraries**/*specific versions*/etc

##### executing MPI
there is a *special execution program*, mpirun (or sometimes mpiexec) that *launches n processes*.
- `mpirun -n 10 ./hello_mpi` launches 10 hello_mpi processes on the **current host**
###### running on distributed hosts
`mpirun -n 2 --hosts gpgnode-01,gpgnode-02 ./simple-send`
- uses ssh (by default) to shell into and launch the process
- assumes *passwordless login* is setup (e.g. using appropriate keys + ssh-agent)
- *round-robin allocation*: -n3 would be **2**x*gpgode-01*, **1**x*gpgnode-2*
	  - usually you want 1 (multi-threaded) process per host.
- HPC job launchers, e.g. SLURM, have their own mpi process management.

##### synchronous message passing
the sender and receiver *synchronise* on messages, similar to unbounded go channels.
- there is a **deadlock** if there is a send with no receive, or vice-versa.

this is based on process *ranks*.
- senders know who they are *sending to*; receivers know who they're *receiving from*.
###### message sending
```c
int MPI_Send(const void* buf,
	int count,
	MPI_Datatype datatype,
	int dest,
	int tag,
	MPI_Comm comm)
```
this *blocks* until `count` num of elements of message have been sent.
- a count, not a size, supports portability
- also note that the tags allow different message types if needed.
###### message receiving
```c
int MPI_Recv(void* buf,
	int count,
	MPI_Datatype datatype,
	int source,
	int tag,
	MPI_Comm comm,
	MPI_Status *status)
```
this *blocks* and **receives** *up to* `count` number of elements of `message` into `dest`.
- *only receives* from source if **they sent the right tag**
- status info: source, tag, error messages, actual counts, etc.

###### what is MPI_DATATYPE?
keywords of the form `MPI_...` are *language neutral* data size descriptors.
they *map to the usual C/fortran types*. (MPI_CHAR, MPI_DOUBLE, MPI_UNSIGNED, etc.)

**complex** data types *arent supported*.
- cant send a linked-list directly
- need serialised into primitive types
- most communication libraries are like this; they just hide that fact.

high-level language wrappers, e.g. Boost MPI for C++, can handle this for you

###### example
```c
...
MPI_Comm_size(MPI_COMM_WORLD, &nump);
MPI_Comm_rank(MPI_COMM_WORLD, &id);
unsigned* xs = malloc(sizeof(unsigned) * MSG_LEN);
if (id == 0) {
	for (unsigned i = 0; i < MSG_LEN; i++) {
		xs[i] = i;
	}
	MPI_Send(xs, MSG_LEN, MPI_UNSIGNED, 1, 1, MPI_COMM_WORLD);
	} else if (id == 1) {
		MPI_Status s;
		MPI_Recv(xs, MSG_LEN, MPI_UNSIGNED, 0, 1, MPI_COMM_WORLD, &s);
		for (unsigned i = 0; i < MSG_LEN; i++) {
			printf("%d, ", xs[i]);
		}
}
...
```

###### comparison with go channels
````col
```col-md
flexGrow=1
===
###### MPI
- implicit communication based on *rank*
- (usually) point-to-point (need to know **who** to receive from)
- specific low-level types
- distributed memory
- no selection mechanism (for synchronous)
```
```col-md
flexGrow=1
===
###### go
- *first class* channels (have handles)
- **multi-party** channels (recv any)
- any value/any datatype
- shared memory
- channel *select*
```
````

#### MPI constructs
###### non-blocking messages
```c
int MPI_Isend(const void *buf, int count, MPI_Datatype datatype,
	int dest, int tag, MPI_Comm comm, MPI_Request *request)
int MPI_Irecv(void *buf, int count, MPI_Datatype datatype,
	int source, int tag, MPI_Comm comm, MPI_Request *request)
```

MPI supports *asynchronous /non-blocking* **send/recv**
- lets u *request* communication to be done.
- you should check the other guy has MPI_Wait and MPI_Test.

this can be tricky to reason about; use with care.
##### collective operations
point-to-point communication can get you far,
but many applications need group-based operations e.g. *broadcast, scatter, gather, reduce*.
- there is MPI support for these through optimised routines.
###### broadcast
```c
int MPI_Bcast(void* buffer, int count, MPI_Datatype datatype, int root, MPI_Comm comm )
```
this sends *the same* buffer contents to all members of **comm**.
- useful for fully shared data. should check, does *every node* **actually** *need* **all** data?

note that **root** should be the same on all call sites.
- MPI determines if it is the sender or the receiver.
###### scatter
```c
int MPI_Scatter(void* sendbuf, int sendcount, MPI_Datatype sendtype,
	void* recvbuf, int recvcount, MPI_Datatype recvtype,
	int root, MPI_Comm comm)
```
this sends *parts* of sendbuf to each process (in comm).
- useful for chunking up large data arrays etc.
- each receives `sendcount` number of elements
- `sendbuf` *only matters at root*

random note: sendcount and recvcount are usually the same, unless sending/receiving different types e.g. sending one of `[[Int]]` v recv 5 of `[Int]`
###### gather
```c
int MPI_Gather(void* sendbuf, int sendcount, MPI_Datatype sendtype,
	void* recvbuf, int recvcount, MPI_Datatype recvtype,
	int root, MPI_Comm comm)
```
here `root` receives a message from each process (in comm)
- recvbuf needs to be *big enough* for **|comm|  \* sendcount**
- `recvbuf` *only matters at root*.
###### reduce
```c
int MPI_Reduce(const void *sendbuf, void *recvbuf, int count,
	MPI_Datatype datatype, MPI_Op op, int root, MPI_Comm comm)
```
works as you'd expect; take the elements from `sendbuf` *on each node* and combine via `op`
- like a gather, and then compute reduction. reduce; send; reduce again (if count > 1)
- the usual operations are available (MPI_SUM, MPI_MIN, etc.)
- user-defined operations are also allowed, but uncommon.
- `recvbuf` *only matters at root*.

![[Pasted image 20250508133424.png]]
- source: https://mpitutorial.com/tutorials/mpi-reduce-and-allreduce/
###### other features
MPI is a large specification witverse
h lots of features.
- point-to-point and collective ops gets you very far (and are simple to grasp)

but in addition also has advanced features like
- global barriers
- remote mem access (*direct mem write without recv*)
- File I/O (optimised for parallel FSes)

#### OpenMP + MPI
it's common to have 1 multi-threaded process per host.
MPI calls are thread-safe by default.
- mixing them can be hard
- MPI_Recv inside an omp parallel is OMP_NUM_THREADS receives (in any order)

```c
MPI_Init(&argc, &argv); // Start MPI

int nump, id;
MPI_Comm_size(MPI_COMM_WORLD, &nump);
MPI_Comm_rank(MPI_COMM_WORLD, &id);

unsigned* xs = malloc(sizeof(unsigned) * MSG_LEN);

if (id == 0) {
	for (unsigned i = 0; i < MSG_LEN; i++) {
		xs[i] = i;
	}
	
	MPI_Send(xs, MSG_LEN, MPI_UNSIGNED,
	1, 1, MPI_COMM_WORLD);
	
} else if (id == 1) {
	MPI_Status s;
	MPI_Recv(xs, MSG_LEN, MPI_UNSIGNED,
	0, 1, MPI_COMM_WORLD, &s);
	unsigned sum = 0;
	
	# pragma omp parallel for schedule(auto) shared(xs) reduction(+:sum)
	for (unsigned i = 0; i < MSG_LEN; i++) {
		sum += xs[i];
	}
	
	printf("Sum was: %d", sum);
...
```

