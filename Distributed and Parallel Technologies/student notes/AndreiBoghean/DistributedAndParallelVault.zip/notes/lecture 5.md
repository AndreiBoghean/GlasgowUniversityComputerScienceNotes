	###### preamble
the goal of parallelism is to speed up execution.
it does this by utilising *parallel hardware*.
concurrency does not (necessarily) share this goal.

some systems dont optimise for speed:
- **requests/sec** - while maintaining a QoS e.g. 105 texts/s with 99.9% success.
- **concurrent users**
- **dynamic scaling** - *add/remove* **compute resources** to *increase/reduce* **capacity**.
- **fault tolerance** - survives failures e.g. 5 9s reliability, 99.999% availability
- **surviving overload** - system keeps running and *recovers unsupervised*.

today we focus on *parallel scaling*.

### performance evaluation
###### how *runtime* should scale with cores
runtime should fall (things get faster) as we add processing elements (e.g. cores)
the **ideal** parallelisation runtime is a ==logarithmic decay==.
- r on 1 core, r/2 on 2 cores/ r/4 on 4 cores, etc.
![[Pasted image 20250508153743.png]]

###### strong scaling (*parallel* **speedup**)
for a *fixed workload*, **and** n processing elements, we can empirically calculate speedup = $\frac{t_{1}}{t_{n}}$
![[Pasted image 20250508155409.png]]
^ graphing this with varying processing elements looks like this

###### *absolute* and *relative* **speedups**
when calculating speedup as $\frac{t_{1}}{t_{n}}$, what do we choose for $t_{1}$?
there are 2 options: *absolute*, and *relative* speedup

in *==absolute== speedup*, it's runtime of a *fully sequential* program with **==no parallel coordination==**
- hard to have fully sequential program; MPI changes program shape.

in *==relative== speedup* it's runtime of a *parallel* program on ==**one core**==
- has parallel *coordination* but **no contention**.
- for large workloads, might be e.g. relative to 1x16 core machine.

###### parallel efficiency
````col
```col-md
flexGrow=1
===
efficiency is a measure of "how close to ideal speedups" are we?
it's a percentage; sometimes given; not much more useful than a speedup graph.

$\text{eff} = \frac{\text{actual speedup}}{\text{ideal speedup}}=\frac{t_{1}}{t_{n}} \div n =\frac{t_{1}}{t_{n}\cdot n}$
or..
$\text{eff} = \frac{\text{speedup}}{p}$
- where p is number of processors
```
```col-md
flexGrow=1
===
![[Pasted image 20250508160950.png]]
```
````
###### amdhal's law
````col
```col-md
flexGrow=1
===
in practice, scaling is almost never linear.

there are overheads of parallelism.
there are also *inherently sequential* parts.
- 0 <= p <= 1 parts are parallel; 1-p parts are sequential. (setup, etc.)
- con only ever speed up the parallel bit. (with more hardware)

$\text{speedup} = \frac{1}{(1-p)+\frac{\text{p}}{\text{n}}}$
```
```col-md
flexGrow=1
===
![[Pasted image 20250508164144.png]]
```
````

![[Pasted image 20250508164819.png]]

###### weak scaling and gustafen's law
john gustafen argued that *strong scaling is not a good use of parallelism*.

instead, we use parallelism to solve **larger problems**; *not smaller* problems faster.
e.g. weather simulations moving from 10km to 1km resolution

*weak scaling* uses this as a metric
- solve problem size 1P on 1 core, 2P on 2 cores, 4P on 4 cores
- ideally a *flat line*; i.e. the runtime for each problem size on each core is the same.

useful in HPC
- almost never have sequential runtimes (could be *weeks* slower than $10^5$ cores)

problem: how do you *exactly* double a workload?

###### performance evaluation summary
speedup measures *how well* **extra processing elements are utilised**.
for a **fixed** workload: ideally time on 2 cores  is 2x time on 1 core.
- note: *some problems dont have fixed workloads*.

speedups measure *parallel runtime* relative to **1 core**.
- *absolute* : 1 core is fully *sequential*
- *relative* : 1 core is *parallelised program*, but **running *sequentially*** (1 core)
	  - editor's note: so it's just the concurrent version?

weak-scaling measures performance as the workload is increased.
ahmdal's law: parallelism is *limited by* **the sequential component**
other metrics, e.g. throughput, might be needed depending on the system.

### developing parallel/distributed software
##### parallel performance monitoring
if we ever want to optimise, we need to *understand what threads/processes are **doing***
presenting this data in a useful form is still active research.

there are many (often propriety) tools
- OpenMP: scalasca, Intel VTune (popular)
- MPI: Vampir
- Haskell: Threadscope
- Perf also does per-thread logging


##### reasoning about parallel/distributed software
it's often possible (and easy) to introduce race conditions :)
- (especially with low-level pthreads)

it's hard for compilers etc. to detect these errors
- (although new techniques for ownership/sessions can mitigate some)

useful tools to analyse the memory access.

###### helgrind (valgrind)
valgrind is a suite of tools for *debugging systems programs*
- the **leak detector** is very popular for C programmers
- helgrind is one tool "which *finds data races* in multithreaded programs"

it essentially **rewrites the binary** to:
- track pthread calls
- track memory accesses (shadow memory)
- perform analysis

*slows down* execution (cuz u now have *additional management tooling that is profiling ur system*)
- hence only use it for **debugging**

###### thread sanitiser
GCC and CLang now come with "ThreadSanitiser"; a data race detector for C/C++
`gcc -fsanitize-thread`

there's also a compiler plugin (like OpenMP)
- remember *the resulting binary is augmented* with tracking information so will be slower

###### go race detector
`go build -race mycmd`
we've already seen the basic **deadlock checker** when we mess up channels.
it doesnt work for **livelock** tho :( detecting that is much harder.
- note: the race detector is based on the C/C++ ThreadSanitiser

###### profiling tool warning
obvs, ==these tools dont guarantee the absence of races==.
similar to Djikstra's note that testing only **reveals bugs**, *not the abscence of bugs*.

###### debugging *parallel* software
most debugging tools "support" parallel software.
```
(gdb) info threads
	3 process 35 thread 27 0x34e5 in sigpause ()
	2 process 35 thread 23 0x34e5 in sigpause ()
* 1 process 35 thread 13 main (argc=1, argv=0x7ffffff8) at threadtest.c:68

(gdb) thread 2
[Switching to process 35 thread 23]
```

###### debugging **distributed** software
some (often proprietary) specialised tools exist to debug distributed software
- DTT (Distributed Debugging Tool)

applications are *just* processes, so you can do something like
`mpiexec -n 4 exterm -e gdb mpi_app`
and enjoy 4 windows worth of debuggers :D
- specialised tools are usually wrappers over something like this; with one window.


**even with these tools...**
watching code can alter parallel behaviour.
- profiling slows it down, which *might prevent a specific path from appearing.*

you also only see bugs if they happen in a **particular run**.
- for uncommon (but potentially catastrophic behaviour) it's very hard to recreate.

profiling tools have limited controls for "recreating" specific behaviour, especially if they are race-y. "reversible debugging" is good for this apparently.

###### formal methods
concurrency is hard because *concurrent systems can be in a lot of different **possible states***,
and the *number of states grows much faster* than anyone is prepared for.

the extra states are a symptom of permutation moment instead of combinations.
- need to consider "**all method orderings**"

formal methods / model checking can help here.
- TLA+ is seeing a resurgence in distributed system design, including @ big companies

the idea for formal methods is to
1. **build an abstract model of the system** (what messages can be sent, etc.)
2. check (ideally automatically)
	   - for all possible ordering P is true
	   - e.g. for all possible orderings, all writes to X are visible before a read

problems with this:
- generally, checking a *design* is not an **implementation**. (but easier to fail early)
- not always *beginner friendly* (some models like bugraphs are very visual, which can help)

##### philosophicalness
###### side-stepping the need to reason (and parallelism)
the most user-friendly parallel system is not a parallel system.
- buy a better machine? is expected running time really *that* bad? 1m isnt bad maybe.

###### do you *need* a **distributed** system?
- some things are inherently distributed  (point-of-sale)
- if you arent a big tech company, dont copy them for the sake of it.
- see: CLI tools can be 235x faster than your hadoop cluster.

###### know how much faster u need to go
if it's just a little faster; kill the sequential "big eaters" (*amdhal's law*)

do we *need* **radically different coordination**? (new data structures; distributed systems)
- experiment early with your technology choice

###### accidental parallelism
highly optimised sequential code can sometimes call parallelised code
- use an *inherently non-parallel* data structure
- rely on *data consistency*
- remove easy to parallelise loops with **complex control structures**.

###### more development tips
determine appropriate technologies
- we've seen a bunch in the class; but there might be others. "*appropriate*" is *hard 2 quantify*

consider communication overheads
- often better to chunk; sometimes need very heavy (non-portable) tuning
  e.g. "do not spawn below this depth"

often *many* ways to do the same thing:
- divide and conquer vs loop iteration, etc.
- not always clear the best way without measuring. microbenchmarks can help.

### summary
- **parallel scaling** as a key metric
	- *how much faster* **compared to** *sequential (absolute)* **or** *n processing elements (relative)*
	- other metrics possible, e.g. throughput
- amdhal's law: sequential parts limit scalability
- gustafen's law: parallelism -> problem size increase (weak scaling)
- tools for design: memory/race detectors, profilers, debuggers, formal methods