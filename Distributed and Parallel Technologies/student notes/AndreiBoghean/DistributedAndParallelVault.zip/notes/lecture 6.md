###### erlang lore drop
erlanng is a distributed programming language, with high-level parallelism constructs
(asynchronous messages)
it is scalable (e.g. wahtsapp with 30Bn messages/day)
and used in practice (e.g. at meta, yahoo, amazon, motorola, ericsson)

a lot of erlang's ideas are replicated in other languages, e.g.
libraries: scala Akka/Java, CAF (C++), PARLEY (python)
languages: Cloud Haskell, Termite Scheme, Elixir (elrang sister language)

1980s: research and development at ericssons' telecons CS lab
- fast development; market advantage
- reliability: 99.999% telecomms uptime
- soft real-time

1991: roll out of erlang-based products
- half of the world's landline calls go through an erlang exchange

1998: open sourced

still very active; consultancies, conferences (code BEAM), etc.

### erlang basics
erlang runs in it's own virtual machine; BEAM.

###### modules and functions
erlang functions live in modules (not classes).
```erlang
-module(tutorial).
-export([square/1]).

%% Squares a number
square(X) -> X*X.
```
- square/1 is the *one-argument* square function
- no explicit return
- note the `.` after statements. this is prolog-style. you can think of it like `;`

we can compile *modules* within erl:
```
> c(tutorial).
{ok, tutorial}
> tutorial:square(20).
400
```

###### pattern matching/recursion
there are no for/while loops, instead you use pattern matching and recursion.
```erlang
factorial(1) ->
	1;
factorial(N) ->
	N * fac(N-1).
```
in this case we used the `;` since the second function is the "same"
(but on a different pattern match)

pattern matching is flexible, can include variables and names.
```erlang
hcf(X,0) -> X;
hcf(X,Y) -> hcf(Y, X rem Y).
```

###### variables vs atoms
*variables* are always uppercase.
*atoms* are (on-the-fly) defined names. similar to lisp. lowercase. 

```erlang
convert(C, inch) -> C / 2.54;
convert(I, centimeter) -> IN * 2.54.
```
- inch and centimeter are atoms, not variables. very useful for message tags.

###### strong typing
values are *strongly* (but *dynamically*) typed. explicit conversions are needed (just like go)
```erlang
> 5 + "1". % Error
> 5 + list_to_integer("1").
```

###### tuples
so `{inch, 3}` is a tuple (of length 2)
can have **n** elements; can *mix types*, e.g. atom and int (including **nesting tuples**)

they often appear in pattern matches:
```erlang
convert_len({centimeter, C}) -> {inch, X / 2.54};
convert_len({inch, I} -> {centimeter, I * 2.54}).
```

###### lists
```erlang
> [2,3,5,7,11]
> [atom1,atom2,atom3]
> [{test, {c, -10}}]
```

you can **deconstruct lists using pattern matches**.
```erlang
> [H|T] = [atom1, atom2, atom3].
> H.
atom1
> T.
[atom2, atom3]
```

you can also **==construct== lists using pattern patches**.
```erlang
> L1 = [2,3,4].
[2,3,4]
> [1|L1].
[1,2,3,4].
```

and pass accumulators as parameters.
```erlang
reverse(L) ->
	reverse(L,[]).

reverse([H|T], R) ->
	reverse(T, [H|R]);
reverse([], R) ->
	R.
```

the standard library `lists` module also has the usual functions:
- append, length, max, reverse, sum, etc.

```erlang
> [2,3,4,5] ++ [6,7,8]
[2,3,4,5,6,7,8]
> append([2,3,4,5],[6,7,8])
[2,3,4,5,6,7,8]
%% Pretty useful
> lists:seq(1,7)
[1,2,3,4,5,6,7]
```

###### IO
strings are represented as `[Char]`
`io:format/2` outputs to the terminal.
```erlang
> io:format("Hello World~n", []).
> io:format("Hello Term: ~w~n", [term]).
> io:format("Hello Nums: ~p,~p~n", [0, 50]).
```
format specifies include:
- ~f Float
- ~s String
- ~w Erlang Term (atoms etc)
- ~p Pretty-print ~w
- ~n Newline
- ~d Decimal In

###### variables
variables are single-assignment.
```
> X = 42.
42
> X = 64.
** exception error: no match of right hand side value 64
> X = X + 1.
** exception error: no match of right hand side value 64
```
since erlang is functional; X is not state, it's an expression.

###### conditionals
```erlang
something = if
	Condition/Guard 1 ->
		Body 1;
	Condition/Guard 2 ->
		Body 2;
		...
	Condition/Guard n ->
		Body n %%Note no ";" here
end
```

###### case statements
if statements only handle condition guards.
- cant call functions or do pattern matching.
- case statements *allow* function calls and pattern matches.

`````col
````col-md
flexGrow=1
===
**if statement**
```erlang
relprime(X,Y) ->
	V = hcf(X,Y),
	if
		V == 1 -> true;
		true -> false
	end.
```
````
````col-md
**case statement**
```erlang
flexGrow=1
===
relprime(X,Y) ->
	case hcf(X,Y) of
		1 -> true;
		_ -> false
end.
```
````
`````

###### standard libraries
some standard lib functions:
- trunc(5.6) = 5
- round(5.6) = 6
- length([a,b,c,d]) = 4
- float(5) = 5.0
- is_atom(worker) = true
- list_to_atom("worker") = worker
- integer_to_list(35) = "35

###### higher-order functions
functions are first-class so u can pass them around, return them, store them, etc.

you can make anonymous functions with fun(...)
- converts names to functions when required
- use end for inline functions
```erlang
> lists:map(fun tutorial:square/1, [2,3,4,5]).
[4,9,16,25]
> lists:map(fun(N) -> N + 1 end, [2,3,4,5]).
[3,4,5,6]
```

you can pass functions to HOFs like map, filter, foldl
```erlang
%% Odd numbers between 1 and 20
lists:filter(fun(I) -> I rem 2 =/= 0 end, lists:seq(1,20)).
```

```erlang
lists:foldl(fun(X,Acc) -> X + Acc end, 0, lists:seq(1,20)).
```