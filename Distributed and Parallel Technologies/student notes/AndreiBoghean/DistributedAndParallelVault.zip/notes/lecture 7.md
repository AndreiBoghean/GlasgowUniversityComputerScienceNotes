### preface: parallel erlang

##### the actor model
erlang supports *distributed* systems based on **actors**.
*actors* are **distributed independent processes** which communicate via **async messages**.
- independent => ownership of memory region
- asynchronous => some form of *mailbox* that can be ==checked==.

erlang actors have (unique) ==Pids==.
- *can send messages* to any actor we know the Pid of.
- can reside on **different physical machines**.
	  - the ==BEAM VM== takes care of ***routing***, etc.

###### concisely:
*Actors* are **units** of *computation*
*Messages* are **units** of *coordination*

after receiving a message, an actor might:
- *send* messages to other actors it knows about
- **dynamically** *create* new actors.
- tweak it's own future behaviour.

**there is no order** (in the case of concurrent sends to the same actor)

##### share nothing
in erlang, there are *no pointers*; **messages** are the **only interaction**. (but there is *copying*)
this enables distribution.

also some useful optimisations are possible as a result.
- localised garbage collection, reliability.

##### architecture of distributed erlang
![[Pasted image 20250514145710.png]]
contrast: "erlang nodes" euivaently in MPI would be the "processes"
- "erlang processes" are more like threads.

there are **many erlang processes per core**
- similar to go's green threads

##### actors
###### spawning actors
u can spawn stuff using `{erlang}spawn(Module, Function, [Args]).`

functions are defined inside modules like
```erlang
-module(dist1).
-export(printSquare/1).
printSquare(X) -> io:format("~p~n",[X*X]).
```

so combining these you'd do `{erlang}Pid = spawn(dist1,printSquare,[20])`
`Pid` then evaluates to something like `<0.223.0>`

###### terminating actors
actors terminate when the function ends.
- (assuming it does end. common to have *tail-recsursive functions* that *keep themselves alive*.)

also terminate on runtime error.
can also terminate on `exit(Reason)`.

there is no explicit "join" to wait for a process to exit.
- (you can however use constructs (linked processes) to do that)
- similar as in Go, due to the lack of goroutine handles.

###### self and node
actors can:
- get their own pid with self()
- *send themselves a **message*** (not possible in synchronous languages)
- *send their **pid*** inside a message. (useful 2 indicate return location)
- *discover the node* they're running on with node(). (note: erlang supports multi-node)

##### messages
every actor has a **mailbox**.
- all messages go here.

actors can then pattern match to access messages
- => heterogeneous messages.

this is a contrast with go channels.
- go has channels *per "type"* (all items are alike; e.g. all ints)
- go has dynamically created channels
- go removes messages "in-order" (the order they were enqueued)

###### recieving messages
```erlang
receive
	Pattern1 -> exp1;
	Pattern2 -> exp2;
	...
	PatternN -> expN %No ";"
end
```
receiving messages is essentially a case over the mailbox.
it's a **blocking** recieve (if no patterns match)
- similar to go "select" but here it's over a *single* **mailbox** (not *multiple* **channels**)
###### sending messages
```erlang
pid ! messages
```
you *must* know the pid of who is receiving the message.
- this actor could pass it on if needed, e.g. implementing a load balancer.
- this is similar to the *channels down channels* idea

###### messages example
```erlang
-module(dist2).
-export([printMsg/0]).

printMsg() ->
	receive
		{printMe, Msg} ->
			is:format("~p~n",[Msg]),
			%Tail recursive call
			printMessages();
		finished -> % Finished is just an atom
			%Just an atom
			% Remember: we need to return *something*
			done
	end.
```

```erlang
> Pid = spawn(dist2,printMsg,[]).
<0.232.0>
> Pid ! {printMe, "Hello"}.
> Pid ! {printMe, "World"}.
> Pid ! finished.
```

###### classic ping/pong example

something something `> pong ! {ping, self()}`

```erlang
-module(ping).
-export([start/0, ping/2, pong/0]).

ping(0, PongId) ->
	PongId ! done,
	io:format("ping done~n",[]);
ping(N, PongId) ->
	PongId ! {ping, self()},
	receive
		pong -> io:format("pong received~n",[])
	end,
	ping(N-1, PongId).
```

```erlang
pong() ->
	receive
		done -> io:format("pong done~n",[]);
		{ping, PingId} ->
			io:format("Received ping~n",[]),
			PingId ! pong,
			pong()
	end.

start() ->
	Pong = spawn(ping, pong, []),
	spawn(ping, ping, [3, Pong]).
```

##### service discovery
it's possible to associate a *name* with a **pid**.
- the mapping is tracked by the VM/runtime system.
```erlang
register(printer, spawn(dist2,printMsg,[])),
% Notice the lack of binding, I just happen to know the atom I want
printer ! {printMe, "Hello"},
printer ! {printMe, "World"},
% Can do in inverse lookup if needed
Pid = whereis(printer).
```

### distributed erlang
eralang processes (erl) use multiple cores on a single VM.
for *scale*, we need to move to multiple (physical) machines.
- this is possible via node **naming**.

```erl
gpgnode-02% erl -sname pong
gpgnode-03% erl -sname ping
```

==note: nodes are *dynamic* (can add/remove at **runtime**); this is really cool!==

##### security
to prevent unauthorised access: all VMs share a **cookie**.
- this is a special key; arbitrary, whatever u want.
- by default, in .erlang.cookie

##### spawning over nodes
we're aware of `{erlang}spawn/3` which is `{erlang}spawn(Module, Function, [Args])`
but there's also `{erlang}spawn/4` which is `{erlang}spawn(Node, Module, Function, [Args])`
- allows us to **select the node** to spawn on.

pids returned allow messages to other nodes (transparently)

###### registered actors
`register` associates a name with a pid on a specific node.
- `{elang}{name, node} ! message`. note this supports multiple node versions.

this removes some of the "transparency" of the model.
- you need to know *where* things are; **==locality slips into the model==**.


##### multi-node ping/pong
```erlang
-module(dping).
-export([start/2, ping/2, pong/0]).

ping(0, PongId) ->
	PongId ! done,
	io:format("ping done~n",[]);
ping(N, PongId) ->
	PongId ! {ping, self()},
	receive
	pong -> io:format("pong received~n",[])
	end,
	ping(N-1, PongId).
```

```erlang
pong() ->
	receive
		done -> io:format("pong done~n",[]);
		{ping, PingId} ->
			io:format("Received ping~n",[]),
		PingId ! pong,
		pong()
	end.

start(Host1, Host2) ->
	Pong = spawn(
		list_to_atom("ping_node@" ++ Host1),
		dping, pong, []),
	spawn(
		list_to_atom("pong_node@" ++ Host2),
		dping, ping, [3, Pong]).
```

#### failures
##### example distributed system failures
distributed systems experience failures often:
- hardware failure, power failure business logic errors, network down, message undelivered...

even if the probability that a single node fails is low..
the chances of one node in a large set (1000s of cores) failing is high.

##### recovery mechanisms
###### checkpointing
this is a classic recovery mechanism for **scientific codes**.
1. every *n* iterations, send data to disk.
2. when a node fails, stop everything, and restart from the checkpoint.
	   - failure could include a timeout, heartbeats, external monitoring

pros: easy to implement and reason about
cons: need to wait to **reschedule the computation**. *one failure takes down the whole system*.

**==however==**.. checkpointing doesnt work in all applications.
- telecomms: one broken call **shouldnt** *take down all calls in the switch*
- online shopping
- distributed data processing

replication can *help*
- multiple databases, load balancing, etc.

often these are *concurrent* (soft) real-time applications.

###### supervision and restarts (let it crash)
instead of checkpointing, you could exploit share-nothing actors.
- cannot have state mismatches, since there is no shared state.

on issues: **kill the actor**, and *restart in a known state*.
- **isolated** restarts; no other actor is affected. (i.e. the other phone calls stay alive)

so how to do it? well, you need to know ***when** to restart*.
erlang processes can *monitor* the status of "child processes"
- can have nested supervision, giving a tree.
- might be distributed.

the BEAM VM knows when processes have exited, raised errors, etc.
as usual, "killed" processes are the easiest to detect.
- deadlocks, livelocks, etc are much harder.

![[Pasted image 20250514132530.png]]

##### linking processes in erlang
link(pid)
- sets a bi-directional link between the calling processes and Pid
- signalled when either exits

spawning and linking is common enough to have a function:
`{erlang}Pid = spawn_link(Node, Fun, Args)`

###### link termination
when a process terminates.. **EXIT** is sent to all linked processes.
when *receiving* an **EXIT**..
- if it's an intended exit (end of function, etc.): you can ignore
- if it's abnormal, the receiving process **EXIT**s, *and* **signals**.
	  - this allows *chains* of crashes.
	  - some form of a "transactional" exit

```erlang
-module(linking).
-export([start/0, foo/0]).

foo() ->
	timer:sleep(3000),
	exit(abnormal). %abnormal exit

start() ->
	spawn_link(linking, foo, []),
	timer:sleep(5000),
	io:format("Finshed normally~n", []).
```
- `abnormal` is an atomic.

###### link termination recovery
sometimes u want to handle exits, e.g. by replacing a process.
`{erlang}process_flat(trap_exit, true)` does this.
- converts exit signals to **messages**.

```erlang
-module(recovery).
-export([start/0, foo/0]).
foo() ->
	timer:sleep(3000),
	exit(abnormal). %abnormal exit

start() ->
	process_flag(trap_exit, true),
	spawn_link(recovery, foo, []),
	timer:sleep(5000),
	receive
		{'EXIT', _PID, _Reason} ->
			io:format("Abnormal exit detected ~n", []),
			spawn(recovery, foo, []) % Unlinked version
	end,
	io:format("Finshed normally~n", []).
```

reinterpreted: any termination sends a `{erlang}{'EXIT', PID, Reason}`.
if you manually `{erlang}exit(Reason)`, you can set `{erlang}Reason` to an *atomic*.
your other guys subsequently pattern match, for either an agreed-upon *atomic*
or something that isnt the pre-agreed *atomic* which ==indicates the failure==.

###### monitors (weaker linking)
erlang monitors *get state changes* from processes, but *dont propagate* them/crash themselves.

##### failure handlers
###### Open Telecomms Platform (OTP)
erlang has many libraries to build reliable/scalable systems.
OTP *includes common patterns* such as *client-server* (`gen_server`), *supervision* (`supervisor`)

these different abstractions build on the notions of linking/monitoring.

###### DIY supervisor
a **supervisor** needs to:
1. *spawn, link, and register* a "supervised" *process*.
2. trap *exits*
3. *spawn, link, and register* **replacement** *processes*.

```erlang
supervise(Module, Fun, Args) ->
	process_flag(trap_exit, true),
	P = spawn_link(Module, Fun, Args),
	io:format("Supervising ~w", Fun),
	receive
		{'EXIT', _P, normal} ->
			% Process didn't crash
			ok;
		{'EXIT', _P, _} ->
			% Restart
			supervise(Module, Fun, Args);
		finished ->
			io:format("Supervision complete~n").
	end.
```

#### reliability testing
##### chaos monkey
how do we know our reliability mechanisms are any good?
the idea is to build tools that kill processes at random.
- needs to be "random enough", otherwise you're ***not** testing the full system*.
- ==outcomes of this tool are probabilistic; you get *confidence*, not **proof**==.

###### simple erlang chaos monkey
```erlang
workerChaos(NVictims,NWorkers) ->
	lists:map(
		fun( Num ) ->
			timer:sleep(500),
			WorkerNum = rand:uniform(NWorkers),
			io:format("workerChaos killing ~p~n",[workerName(WorkerNum)]),
			WorkerPid = whereis(workerName(WorkerNum)),
			if
				WorkerPid == undefined ->
					io:format("already dead: ~p~n", [workerName(WorkerNum)]);
				true ->
					exit(whereis(workerName(WorkerNum)),chaos)
		end
	end,
	lists:seq(1, NVictims)).
```

### lecture recap
actor model of computation
- asynchronous messages to **mailboxes**.
- share nothing.
- Pid based (or registered names)

distribution:
- spawn on node n.

reliability:
- checkpointing: classic, mainly scientific software
- supervision/linking: allow process failure to trigger events, e.g. *process restarts*
- chaos monkey: random process killing to check error robustness.

erlang has mechanisms for scalable/reliable systems.
but you still need to use these well.

**scalability** can be limited by:
- bottlenecks (e.g. one actor with large sequential work)
- node connectivity (distance between nodes, etc.)
- etc.

**reliability** can be impacted by:
- race conditions
- deadlocks/livelocks
- complex system interactions (cascading failures, etc.)

