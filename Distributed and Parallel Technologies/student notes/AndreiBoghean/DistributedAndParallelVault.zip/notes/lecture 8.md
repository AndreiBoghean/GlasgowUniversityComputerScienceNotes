modern architectures/setups have parallelism at *multiple levels*.
1. within a core (instruction-level parallelism; SIMD; hyper-threading)
2. multi-core
3. OS processes
4. OS threads
5. user-level/green threads

regardless of the level, the goal of modern computer architecture is to
**ensure the instruction pipeline is always full**.
- this uses things like *branch prediction*,
- also *out-of-order execution*.
	  - the order you write the code in is *not* the order it's executed in.
	  - values can essentially **travel "back" in time** (parallel read-after-write is hard)

### SIMD and data parallelism
#### software-level (with OpenMP)
we saw this with OpenMP.
```c
#pragma omp parallel for
for (unsigned i = 0; i < 100; i++) {
	xs[i] = ys[i] + 1;
}
```
- effectively, the single instruction (for loop) executes on multiple parts of the data.
- the work is chunked between `OMP_NUM_THREADS`

#### hardware-level
for some select instructions (arithmetic/logic/shuffles), modern hardware supports SIMD.
in *one* instruction cycle, you can do 64/128/256/512 bit operations.
this can give nice speedups. 512 bit operations are *effectively 8x faster*, on a 64 bit processor.
- 8x64 = 512

##### vector instruction sets
*SSE*: **S**treaming **S**IMD **E**xtensions
- 128 bit
- SSE, SSE2, SSE3, SSE4

*AVX*: **A**dvanced **V**ector e**X**tensions
- up to 265 bit
- AVX2

*AVX-512*: AVX but with 512 bit lol

###### compiling vector extensions

hi look at this dumd code
```c
#include <stdlib.h>
#include <stdio.h>

int main() {
	unsigned *xs, *ys;
	xs = malloc(sizeof(unsigned) * 128);
	ys = malloc(sizeof(unsigned) * 128);
	for (unsigned i = 0; i < 128; i++) { ys[i] = i; };
	for (unsigned i = 0; i < 128; i++) {
		xs[i] = ys[i] + 1;
	}
	for (unsigned i = 0; i < 128; i++) { printf("%d,",ys[i]); };
	printf("\n");
}
```

see this silly for? `{c} for (unsigned i = 0; i < 128; i++) { xs[i] = ys[i] + 1; }`
it compiles into..
```
mov ecx,DWORD PTR [rbx+rax*1]
lea edx,[rcx+0x1]
mov DWORD PTR [rbp+rax*1+0x0],edx
```
notice the + symbols? yea, that's inefficient code >:(
- (cause it loops over the index 1 item at a time)

if you compile with `-O2 -msse`
then it turns into something cool
```
mov ecx,0x1 -- Get the 1 value
xor edx,edx -- Zero out edx
movd xmm1,ecx -- 128 bit SSE register
pshufd xmm1,xmm1,0x0 -- Put 1s everywhere in the vector
movdqu xmm0,XMMWORD PTR [rax+rdx*1]
paddd xmm0,xmm1 -- Vector addition
movups XMMWORD PTR [r12+rdx*1],xmm0 -- Move the next set of data into xmm0 register
add rdx,0x10 -- Increase loop increment by *16* bytes since we
are processing 4*(4 byte) words at once
```
^ see this? gl reading it; but just know that it processes 4 x (4byte) words at once. cool.

compilers are pretty good at adding in vectorisation.
by default it's usually on for -O2 and -O3
*but* you might want to write them yourself.
- if you know something can be **bit-parallel**, e.g. a fast bit-set
- note some instructions etc are **only available** in *AVX form* (certain shuffles, etc.)

###### AVX moment
it makes ur code paths very hard to read.
```c
or (auto i = 0; i < maxIterations; i++) {
	__m256 z_im8sq = _mm256_mul_ps(z_im8, z_im8);
	__m256 z_re8sq = _mm256_mul_ps(z_re8, z_re8);
	__m256 new_im8 = _mm256_mul_ps(z_re8, z_im8);
	__m256 z_abs8sq = _mm256_add_ps(z_re8sq, z_im8sq);
	__m256 new_re8 = _mm256_sub_ps(z_re8sq, z_im8sq);
	__m256 mi8 = _mm256_cmp_ps(z_abs8sq, four8, _CMP_LT_OQ);
	z_im8 = _mm256_fmadd_ps(two8, new_im8, c_im8);
	z_re8 = _mm256_add_ps(new_re8, c_re8);
	int mask = _mm256_movemask_ps(mi8);
	__m256i masked1 = _mm256_and_si256(_mm256_castps_si256(mi8), one8);
	if (0 == mask) break;
	result = _mm256_add_epi32(result, masked1);
}
```

##### GPUs
GPUs are **accelerators** for large-scale compute.
historically for graphics, but now we have GPGPUs (general-purpose GPU)
- usable for graphics, image processing, physics simulations, machine learning, calculating hashes, and pretending it's real money...

these fit into the **heterogenous computing landscape** we need to deal with.

###### GPU architectures
high core-count (512-2000 cores)
lightweight cores (not full X86; limited caching; sometimes *multi-type* e.g. *CUDA, tensor, RT*)
*trade **cache** space for **compute** space*. still a bit of video memory (*historically for screen buffer*)
sometimes on the same chip as the CPU (they can share ram. useful.) common on phones.

###### programming GPUs
*CUDA*: **C**ompute **U**nified **D**evice **A**rchitecture.
- low-level
- specific to NVIDIA

*OpenCL*: **Open** **C**omputing **L**anguage
- standard for heterogenous platforms

*OpenMP*
- most of the newer spec is focused on accelerators

*OpenACC*: **Open** **Acc**elerator
- similar to OpenMP, before OpenMP added support.

there is a **challenge** with all of these:
the management of 1000s of threads (for 1000s of cores)
the solution is:
a **hierarchical hardware model**

### hierarchical hardware
![[Pasted image 20250513202336.png]]

##### preface: OpenCL
the goal for OpenCL is to specify "compute" that works on *many devices*.
- CPUs, GPUs, FPGAs, etc.

#### executing on hierarchical hardware
individual (lightweight) cores (processing elements) are grouped into logical blocks.
- these are called compute units (CUs)
- there is communication/synchronisation within a compute unit, but not outside.

different compute units can execute different *kernels*.
- kernels are "programs" for the accelerators.

execution model
- **work items** (threads) execute on specific *PEs* (processing elements)
- **work items** are grouped into *work groups* (that *the CUs run*)

the big idea behind this is to move from loops to **data updates in N-dimensional space**.
- you specify how each individual "point" is updated, e.g. pixels in an image.

and then let the OpenCL environment handle the scheduling.

##### a simple kernel
###### code example
dumb  code:
```c
void sumArrays(float* a,
				float* b,
				float* c,
				unsigned n) {
	for (unsigned i = 0; i < n; i++) {
		c[i] = a[i] + b[i];
	}
}
```
cool code:
```c
// No looping structure
// the work items are already divided
__kernel void sumArrays(__global int* a,
						__global int* b,
						__global int* c){
	int index = get_global_id(0);
	c[index] = a[index] + b[index];
}
```

###### multidimensional workloads
*you* get to decide the work-item domains.

addition was 1D {0..N}, but you can do up to **3 dimensions** (e.g. *manipulate over points x,y,z*)

###### setup and execution
a lot of code is needed to execute a kernel:
1. find and initialise the devices
2. compile the kernels (at runtime so it can optimise for specific devices)
3. initialise the memory on the device (and probably locally)
4. enqueue a kernel
5. enqueue a read black to host memory
6. release the memory on the device

###### work sizing
sizing the work is difficult. we're familiar with this already tho. (CHUNKSIZE in OpenMP).
note that you *can* **still do loops** etc. to avoid some overheads.

###### matrix multiplication
```c
__kernel void multiplyMatrices(__global int* a, __global int* b, __global int* c,
							const int M, const int N, const int K){
	int colIndex = get_global_id(0);
	int rowIndex = get_global_id(1);
	// Arrays are flattened, so we need to compute the right index
	int index = (rowIndex * N) + colIndex;
	
	int sum = 0;
	for(int k = 0; k < K; k++){
		sum += a[rowIndex*K + k] * b[k*N + colIndex];
	}
	c[index] = sum;
}
```

##### summary
OpenCL uses a multi-dimensional point-based model.
- kernels specify how to compute outputs for specific points.

work items = kernels to be executed.
- private memory

work groups = point-local workers; can be synchronised.
- local memory.

### OpenMP again 4 some reason
OpenMP has a *target* pragma to allow offloading.
```c
#pragma omp target
for (unsigned i = 0; i < 12; i++) {
	c[i] = A[i] + B[i]
}
```
this **executes the code on an accelerator**.
- note that there's **no parallelism here**. you need more words for that. see below.
- pragma *simply moves the computation*.

```c
#pragma omp target teams num_teams(3) distribute parallel for
for (unsigned i = 0; i < 12; i++) {
	c[i] = A[i] + B[i]
}
```
this is effectively 3 work-groups (teams)
- each is computing in their for loop sections (distribute) in parallel.

this can get much messier than the CPU-only versions.

note that there are other pragmas for specifying memory movements, etc.