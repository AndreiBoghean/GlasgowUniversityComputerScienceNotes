### haskell
#### generally speaking:
haskell is a *general-purpose*, **statically typed**, *purely functional* language
with **type inference** and *lazy evaluation*


the language is *functional*; not **imperative**
- *imperative* languages describe a **sequence of steps** to compute a result
- *functional* languages describe how to **reduce an expression** to a value

*functions* are **first-class** objects

#### details
##### expressions and statements
a **statement** is an *instruction / computation* step. it doesnt return anything.

an **expression** is a term in the language that *eventually reduces* to a **value**
- an expression can be contained within a statement

![[Pasted image 20250412142032.png|250]]


==in haskell, everything is an expression==
- statements, if conditions, etc.


###### types
![[Pasted image 20250412142351.png|350]]
haskell expressions have types, which classify values.
types rule out illogical expressions such as 5+True
- haskell can infer a type for most expressions, but good practice recommends type signatures for top-level functions

##### reduction
###### clasically..
an **imperative** language makes use of the *program counter*, *call stack*, and *state*
- the **current position** in the program's statements is recorded with the *PC* and *stack*
	  - the program's statements themselves can alter that position.
- variable assignments alter some **variable store**, the *state*

###### haskell-y..
complex values are reduced piece-wise to a single value.
![[Pasted image 20250412143722.png]]

*haskell reductions* are subject to the ==church-rosser== property:
- reductions can be performed in **any order**
- in the context of abstract rewriting systems, reduction is *confluent*
- useful for **equational reasoning** and functional **parallelism**