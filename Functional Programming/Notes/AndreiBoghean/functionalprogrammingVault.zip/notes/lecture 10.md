# important part:
a *monad* is a *monoid* in the **category of endo-functors**
a *monoid* is a **semigroup + $e$**
a *semigroup* is a **set S + associativity**
# More Monads (2)
## Introduction
We are going to start in a fairly abstract, mathematical mood today.
This is abstract algebra, probably more suited to a Maths course instead of Computing Science.
## Semigroups
###### prerequisite rule on a set S
Think about a **set of elements** $S$ with an **associative binary operation** $\bigoplus$.
- *associativity* on $\bigoplus$ **meaning** $(x \bigoplus y) \bigoplus z = x \bigoplus (y \bigoplus z)$.
- In Haskell-speak, $\bigoplus$ has type `{haskell}S->S->S`,
  i.e. it **takes** *two parameter values* in $S$
  and **returns** *a single result value* in $S$.
##### semigroup = (S, $\oplus$)
This abstract mathematical structure, $(S, \bigoplus)$ is known as a *semigroup*.
###### haskell implementation
There is a corresponding Haskell typeclass, called `{haskell}Data.Semigroup`,
with the characteristic function being the *infix operator* `{haskell}(<>) :: a -> a -> a`.
```haskell
class Semigroup m where
  (<>) :: m -> m -> m
```
- Note that Haskell is *not* expressive enough to specify the associativity constraint ...
  **we have to be aware of this** as programmers.
###### Examples of semigroups
* the set of positive integers with addition.
* the set of all finite strings over a fixed alphabet with string concatenation
* 2x2 square non-negative matrices with matrix multiplication

## Monoids
###### definition/classification
A *monoid* is a set $S$ with an associative binary operation $\bigoplus$ and an identity element $e$.
- effectively, **a semigroup with an identity element** $e$.

The identity element must satisfy the constraint that:
 $∀ a ∈ S. (e \bigoplus a = a) \land (a \bigoplus e = a)$ (i.e. it's commutative?)

the identity element is also *unique within the monoid*
- since the monoid is a set

###### Haskell **monoid typeclass** definition:
```haskell
class Semigroup m => Monoid m where
  mempty :: m

  -- defining mappend is unnecessary, it copies from Semigroup
  mappend :: m -> m -> m
  mappend = (<>)

  -- defining mconcat is optional, since it has the following default:
  mconcat :: [m] -> m
  mconcat = foldr mappend mempty
```

**implicitly**, All instances of Monoid must satisfy the following laws:
```haskell
-- left and right identity
x <> mempty == x
mempty <> x == x

-- Associativity
(x <> y) <> z == x <> (y <> z)
```
- Again, *we can't express these constraints in the typeclass* definition
  it's **up to the Haskell developer** to *ensure the laws are respected* by `{haskell}Monoid` instances.

### examples
#### List as a Monoid
The most straightforward example of a monoid instance is the list datatype.
```haskell
instance Semigroup [a] where
  (<>) = (++)

instance Monoid [a] where
  mempty = []
```
- the list concatenation operation is `{haskell}mappend`
- the empty list is the identity element.

we can construct lists using a new syntax now ...
`[1] <> [2] <> [3,4,5] <> mempty`
#### Sum as a Monoid
It's easy to see why lists are monoids
- the `{haskell}mempty` element and the `{haskell}mappend` operation are obvious.

How about integers?
If the `{haskell}mappend` operation is integer addition, then the `{haskell}mempty` element is $0$.

Let's express this in Haskell:
```haskell
newtype Sum n = Sum n

instance Num n => Semigroup (Sum n) where
  Sum x <> Sum y = Sum (x + y)

instance Num n => Monoid (Sum n) where
  mempty = Sum 0
```
- (Actually, there is a library `{haskell}Sum` datatype defined in `{haskell}Data.Semigroup` already.)

Now we can construct integer values using monoid syntax:
```haskell
Sum 0 <> Sum 1 <> Sum 100
```
#### Writers use Monoids
Do you remember, in the previous lecture, we introduced the `{haskell}Writer` typeclass?
We explained how a `{haskell}Writer` instance accumulates an append-only log of data.

Last time, the append-only log was a `{haskell}String`. However now we understand than any `{haskell}Monoid` instance would be suitable for an append-only log.

Let's revisit `{haskell}Writer` and build up a `{haskell}Sum` accumulator value in the log, counting how many operations we perform.
```haskell
-- our writer state accumulates the number of arithmetic operations performed
-- (i.e. subtractions and multiplications)

fact :: Integer -> Writer (Sum Integer) Integer
fact 0 = return 1
fact n = do
  let n' = n-1
  tell $ Sum 1
  m <- fact n'
  let r = n*m
  tell $ Sum 1
  return r
```
#### Foldables *use* Monoids
Earlier in the course, we saw the use of `{haskell}foldl` and `{haskell}foldr` to *reduce* lists of values to single summary values, for example consider `{haskell}foldr (+) 0 [1..10]`.

Now we know about monoids, we recognize that if we have an identity element `{haskell}mempty`, and an associative combining funtion `{haskell}mappend`, then we can easily fold over an arbitrary collection of monoid values.
- note that **the foldable itself is not a monoid** it simply abuses the monoidness of the type the foldable contains. e.g. a binary tree of Just 5 doesnt require the binary tree be a monad, just that it be foldable. similarly, Just 5 mustnt be foldable, simply a monoid.

If we `{haskell}import Data.Foldable`, then we can use
`{haskell}fold :: (Foldable t, Monoid m) => t m -> m` and
`{haskell}foldMap :: (Foldable t, Monoid m) => (a -> m) -> t a -> m`,
which, when given a Monoid `{haskell}m`, *these functions know how to aggregate values using **mappend***.
```haskell
fold [[1,2], [3,4], [5]]
-- evaluates to [1,2,3,4,5]

fold (Sum (Sum 3))
-- evaluates to (Sum 3)

foldMap Sum [1..5]
-- evaluates to 15

foldMap (\a -> [a]) [1..5]
-- evaluates to [1, 2, 3, 4, 5]
```

### Foldable Trees
Recall the binary `{haskell}Tree` container data structure we looked at earlier in the course.
We can make this type an **instance of the Foldable typeclass**, simply by *providing a definition* of the `{haskell}foldMap` function
- (or, alternatively and equivalently, a definition of the `foldr` function).

Notice that a `{haskell}Leaf` value will map onto an `{haskell}mempty`
value, and a non-empty `{haskell}Node` value is recursively
combined with `{haskell}mappend` operations.

```haskell
import Data.Semigroup
import Data.Foldable

data Tree a = Leaf
            | Node a (Tree a) (Tree a)
  deriving (Show,Eq)

instance Foldable Tree where
  foldMap :: Monoid m => (a -> m) -> Tree a -> m
  foldMap _ Leaf = mempty
  foldMap f (Node x left right) =
    f x <> foldMap f left <> foldMap f right
```