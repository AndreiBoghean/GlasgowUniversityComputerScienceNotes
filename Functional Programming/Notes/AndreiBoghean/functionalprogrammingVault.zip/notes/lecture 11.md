# Parser Combinators
## What is Parsing?
A *parser* is a program that recognizes sentences from a grammar.
Sometimes a parser may be **hand-written** but often it is synthesized from a higher-level grammar description by a parser generator tool (antlr, yacc, etc).

The parser is generally *table*-driven or *rules*-driven.

In Haskell, there is an alternative approach involving the use of *parser combinators*, whereby a parser can be **constructed incrementally** based on combining functions.

Informally, a *combinator* is a *higher-order function* that combines 'things' to create more complex 'things' of the same type.

For example, we have already looked at **list** *combinators* like `{haskell}map` and `{haskell}filter`.
A *parser combinator* is a higher-order function that combines two simpler parsers (sub-parsers) to create a **compound parser**.

## The Parsec Library
*parsec* is a Haskell **parser** *combinator* library. You can install it on your system with cabal:
- `{bash}cabal install --lib parsec`
or provision an interactive interpreter with stack:
- `{bash}stack ghci --package parsec`

You can verify that your parsec installation is working properly in ghci:
```haskell
ghci> import Text.Parsec
ghci> parse anyChar "input" "a"
Right 'a'
```
## My First Parser

This simplest of parsers recognizes (and accepts) String values containing the single character 'c'. `{haskell}firstParser = (char 'c') :: Parsec String st Char`

The three type parameters for the `{haskell}Parsec` type are, respectively:
* `{haskell}String` - type of the input data stream to be parsed
* `{haskell}st` - type for user state (unused in this trivial example)
* `{haskell}Char` - type of the value recognized by this parser

Let's see how this parser behaves:
```haskell
parseTest firstParser "c"
parseTest firstParser "cat"
parseTest firstParser "dog"
```

We notice that our `{haskell}firstParser` will accept any String that begins with the 'c' character.

There are several different ways to run a parser. Above we have shown the `{haskell}parseTest` function, which is fine for interactive input. In larger programs, we might use the `{haskell}parse` or `{haskell}runParser` functions.
```haskell
parse firstParser "foo" "hello"
runParser firstParser () "foo" "cat"
```

## Detour: the `{haskell}Either` datatype

Do you remember `{haskell}Maybe`? Of course you do! It's our favourite example type so far. `{haskell}Maybe` has a data constructor, i.e. `{haskell}Just` and a default 'empty' value, `{haskell}Nothing` which represents an error value.

Sometimes, we want the error value to contain richer information, perhaps specifying some detail about the problem. This is where the `{haskell}Either` datatype is useful. It has *two* data constructors: `{haskell}Right` (for correct output) and `{haskell}Left` (for error output). The definition of `{haskell}Either` is:

```haskell
data Either a b = Left a | Right b
```

We use `{haskell}Either` in parsing, where `{haskell}Left` values include
information about the parse error and its context.

As with Maybe, you can work with Either values in a monadic style.
## More Complex Parsing
We can recognize an entire String, as a sequence of characters.
- `{haskell}dogParser = string "dog" :: Parsec String st String`
This parser recognizes a string of characters
- (and returns the *entire String value*, unlike a simple sequencing of `{haskell}char` parser calls).

Now we can start *combining simpler sub-parsers* into more complex parsers using the *alternative* operator `{haskell}<|>`.
(Really, this is a monadic function allowing us to choose between alternative evaluations.)

```haskell
catParser = string "cat"
petParser = dogParser <|> catParser
parseTest petParser "dog"
parseTest petParser "cat"
parseTest petParser "cog"
```

## Parsers as Monads
Since **Parser values are monads**, we can sequence their
operation using monadic `{haskell}do` notation in Haskell. For example:
```haskell
animalParser :: Parsec String st String
animalParser = do
  animal <- dogParser
  char '/'
  country <- count 2 anyChar
  let bark =
        case country of
          "UK" -> "woof"
          "FR" -> "waouh"
          "GR" -> "gav"
  return bark
```
## Building a Parse Tree for Arithmetic Expressions
The main use for parsers is to process a sequence of tokens (**lexemes**) and build a parse tree data structure, representing *abstract syntactic structure* and *relationships*.

Let's consider a toy example.
Suppose we want to process *simple integer arithmetic expressions*, along with *bracketed sub-expressions*.
Sentences in our language would look like: `{haskell}(1+2) * 3`

We could define simple Haskell algebraic datatypes to encapsulate such expressions:
```haskell
data BinOp = Add | Sub | Mul | Div deriving (Show,Eq)

data ArithExpr =
      Compound ArithExpr BinOp ArithExpr
    | Value Int          
    deriving Show
```

and now we can construct a **series of miniature parsers** to process *different input character sequences* and construct the **appropriate** Haskell *in-memory data structures* to **represent** the abstract syntax.
```haskell
numberParser:: Parsec String st ArithExpr
numberParser = do
  digs <- many1 digit
  let num = read digs
  return $ Value num
```
- note that `{haskell}digit` is a *built-in primitive* matching any single digit character.
- also `{haskell}many1` is a *parser combinator* matches one or more of the subparser's accepted input, similar to the `{haskell}+` in Unix regular expressions.

The standard Prelude `{haskell}read` function converts the String value to an Integer. We `{haskell}return` an `{haskell}ArithExpr` which is constructed as a `{haskell}Value` value, storing the number we have parsed from the input.

```haskell
operatorParser:: Parsec String st BinOp
operatorParser = do
  op <- (oneOf "+-*/")
  return (selectOp op)
    where selectOp '+' = Add
          selectOp '-' = Sub
          selectOp '*' = Mul
          selectOp '/' = Div
```
Here we want to *parse a single operator character* and construct the appropriate `{haskell}BinOp` value.
The `{haskell}oneOf` parser will *match one character from a list* of characters.
- This is similar to the Unix square brackets `{haskell}[]` regex syntax.

```haskell
expressionParser:: Parsec String st ArithExpr
expressionParser = (between (char '(') (char ')') binaryExpressionParser) <|>
                   numberParser

binaryExpressionParser:: Parsec String st ArithExpr
binaryExpressionParser = do
  e1 <- expressionParser
  op <- operatorParser
  e2 <- expressionParser
  return (Compound e1 op e2)
```

Here we are building up compound expressions from their constituent elements, using the simpler parsers defined above.
- Note the `{haskell}between` parser combinator for parsing expressions enclosed in brackets, and the `{haskell}<|>` alternative combinator.

We can run this parser with code like this:
```haskell
parseTest expressionParser "(1+1)"
-- or
parse expressionParser "error" "(1+(2*3))"
```

Once we have a **parse tree style data structure**, we can *process this to evaluate the expression* or perhaps to *rewrite it in some way*.
## Alternative typeclass

Sometimes we want to try a computation, then if it fails, try something else.
The `Alternative` typeclass helps us here ...

in particular, the `{haskell}<|>` operator, which intuitively means: 'try the left hand action or, if it fails, try the right hand action'.
```haskell
class Applicative f => Alternative f where
  empty :: f a
  (<|>) :: f a -> f a -> f a
```

(Minor reassurance: don't worry about `{haskell}Applicative` for now ... pretend it says `{haskell}Monad` instead ... we will fill in the details later in the course.)