# Monads and Monad Laws
## Defining Custom Data Types
We can model a *student* with a name, address, and level in a few ways in Haskell.
* As a *tuple* - `{haskell}{haskell}type Student = (String, String, Int)`
* As a *data type* - `{haskell}{haskell}data Student = Student String String Int`
However neither of the above approaches is ideal.

It is difficult to know which `{haskell}String` is a name and which is an address. We need to *pattern match* to deconstruct and get a relevant field. *All fields must be specified when **updating*** the data structure instance.

In Haskell, *records* allow us to have *named fields*.
```haskell
data Student = MkStudent { name :: String, address :: String, level :: Int }
```

We can construct a record as normal, or by explicitly specifying fields:
```haskell
s =  MkStudent "jeremy" "glasgow" 1
s' = MkStudent { name = "simon", address = "glasgow", level = 6 }
```

We can project a record by using its field name, effectively the field name becomes a function:
```haskell
-- implicitly ... name :: Student -> String
putStrLn(name s)
```

We can also *update* a record without needing to specify all fields.
```haskell
let s2 = s { level = 2 }
```

###### the **n,ewtype** keyword
A `{haskell}newtype` declaration is a special form of a *data declaration* where there is *only one data constructor*. It can be used like a *type alias*, while ensuring that **types are treated separately** in the type system.
```haskell
newtype Variable = MkVariable String
```
We will encounter plenty of `{haskell}newtype`s as we look at the various monad instances.
## What is a Monad?
As we have already seen, `{haskell}Monad` is a type class in Haskell, which provides a systematic way of sequencing operations.

Monads enable values to be put into `{haskell}contexts`, enforced by the type system.
- We have considered contexts such as lists, `{haskell}Maybe`s, `{haskell}IO`, and `{haskell}Reader`/`Writer`.

Effectively, `{haskell}Monad` is a design pattern
- a recurring solution to a common problem in functional programming.

## Laws
What is a law? It's a principle that governs or constrains things.
- In theoretical computing terms, **laws constrain behaviours and relationships** between entities.

In a previous lecture, Simon introduced laws for the `{haskell}map` function:
* identity law
    * `{haskell}map id` == `{haskell}id`
* composition
    * `{haskell}(map f).(map g)` == `{haskell}map (f.g)`

And we also looked at three laws for the `{haskell}Monoid` typeclass:
* left identity law
    * `{haskell}mempty <> x` == `{haskell}x`
* right identity law
    * `{haskell}x <> mempty` == `{haskell}x`
* associativity law
    * `{haskell}(x <> y) <> z` == `{haskell}x <> (y <> z)`


Remember that we stressed the point that Haskell cannot enforce these laws in the language or type system directly.

Instead, developers have to manually ensure the laws are respected by their code ... or we might use a *theorem prover*.

## Monad Laws
There are three **monad laws**, which constrain the behaviour of monads.
#### First Monad Law (Left Identity)
```haskell
(return x) >>= f == (f x)
```

If we think about the types of
- `{haskell}return :: Monad m => a -> m a` and
- `{haskell}(>>=) :: Monad m => m a -> (a -> m b) -> m b`
and then fit in the types of `{haskell}x :: a` and `{haskell}f :: Monad m => a -> m b`
then **everything makes sense**.

In natural language terms, we put `{haskell}x` into the monad, then bind strips it out of the monad, feeds it to function `{haskell}f` and the result `{haskell}f x` is evaluated.

#### Second Monad Law (Right Identity)
```haskell
(y >>= return) == y
```

Here, `{haskell}y` is a monadic context containing a value `{haskell}x`, and the bind operation feeds value `{haskell}x` to `{haskell}return`, which *re-wraps* `{haskell}x` into the monadic context, to recover `{haskell}y`.

#### Third Monad Law (Associativity)
```haskell
(y >>= f) >>= g == y >>= (\x -> (f x >>= g))
```

On the *left hand* side:
- the **first bind** feeds `{haskell}y` to `{haskell}f` to get a monadic result
- then the **second bind** feeds this interim result to `{haskell}g` to get the final result.

On the *right hand* side:
- we do the **innermost bind** in the brackets **first** ... so we bind the result of `{haskell}f x` to g, where `{haskell}x` is the parameter from the intermediate lambda abstraction we have to construct to get the types correct.

In natural language: the third monad law says that when we have a **chain of monadic function applications** with >>=, it *doesn’t matter how they’re nested*.
## Monad Laws for `{haskell}Maybe`
Let's consider the monad laws and the `{haskell}Maybe` monad.

Suppose we defined `{haskell}return` for `{haskell}Maybe` as follows:
```haskell
return :: a -> Maybe a
return _ = Nothing
```

then would the two identity laws hold? **No**, of course they wouldn't!
Instead, we define it as:
```haskell
return :: a -> Maybe a
return x = Just x
```
Now both identity laws do hold.