# Error Handling
## What is an Error?
A *error* is a fault in the specification, implementation or operation of software, which causes an incorrect or unexpected result, leading to unanticipated behaviour.

Many of the errors we have encountered so far have been *static* errors, such as **type errors**.
- These are *highlighted by the GHC compiler* or interpreter when the code is **parsed**.

sometimes errors occur when the program executes.
- we refer to these errors as *runtime exceptions*.

Examples might include:
* arithmetic exceptions, such as integer division by zero
* taking `head` or `tail` of an empty list
* I/O exceptions when dealing with files or network access
* incomplete pattern matching in a function evaluation
## Immediate Termination
The simplest way to deal with a runtime error is to *terminate the program* immediately.
This is achieved in Haskell by calling the function:
```haskell
error :: String -> a
```
which has a **polymorphic return type** that *matches any expression* context.
The `error` function takes a `String` parameter that specifies the human-readable error message which gets printed to the standard error stream.
- This behaviour is equivalent to the `exit()` function in C or Python.

*When the program is interpreted* in GHCi, the *error is reported* and a stack trace is provided.
## Indicate Error Conditions with Wrapper Types
Software engineering principles like *defensive programming* and *graceful failure* can be followed in Haskell programming.
- This involves actively anticipating problems and handling errors within the program logic.

We have already encountered how to indicate error values using wrapper types like `Maybe` or `Either`.

The `Maybe` type uses `Nothing` to indicate the absence of a value
- i.e. a safe null value, and `Just x` for a normal value `x`.

One drawback of using the `Maybe` data type to deal with errors is that there is a *lack of error information* in `Nothing` – we have no specific details about what caused the error.

`Either` is a richer type which supports error information:
```haskell
data Either a b = Left a | Right b
```
- Here, `Left a` indicates an *error value*,  with the `a` value (often `String`) **holding error information**.
- `Right b` indicates a *proper value*, equivalent to `Just b` in the `Maybe` type.

In the same way that `Maybe` is monadic, so it can take part in a bind call sequence or a `do` block, so is `Either`.

When we looked at parsing, we noted that *parser error values are wrapped* as `Left` values, when we **invoke the parser** with the `runParser` function.
```haskell
runParser :: Parsec String st a -- our parser
              -> String     -- state (ignore)
              -> String     -- filename
              -> String     -- string to parse
              -> Either ParseError a  -- result

catParser = string "cat"
runParser animalParser "" "" "cat" --  result: Right "cat"
runParser animalParser "" "" "dog" -- result: Left ParseError
```
## Runtime Exception Handling
Like in Java, there are *different types of exceptions* that occur for *different sorts of problems*.
- There are specific circumstances in which each type of exception can be raised.

There are plenty of exception handling facilities (actually functions) in the Haskell `Control.Exception` module.

We look at two design patterns in particular:
1. the `catch` function, and
2. the `try` function.
#### Catching Exceptions
The `catch` function specifies what to do if an expression evaluation raises an error.
We provide a **handler** with a *type-compatible* **alternative expression** to evaluate.

Below are three examples:
```haskell
catch :: Exception e => IO a -> (e -> IO a) -> IO a

-- example 1
(randomIO :: IO Bool) >>= \x -> (if x then putStrLn "hello" else error "oops!") `catch` (\(e ::ErrorCall) -> putStrLn "exception")

-- example 2
((readFile "foo.txt") >>= putStrLn) `catch` (\e -> (putStrLn $ "unable to open file: " ++ (show (e::IOException))))

-- example 3
getContentFrom :: URL -> IO (Maybe String)
getContentFrom url =
   catch (do { str <- scrapeURL url scrapeBody; return $ str })
         (\err -> do {putStrLn $ show (err::HttpException); return Nothing})

-- full text for example 3 at:
-- https://gist.github.com/jeremysinger/cb387f12619b5320c7b8eefe7c96a4a9
```
- Note it is *necessary* to **annotate** the **exception names** with their *types explicitly*, to make ***type inference work properly***.
#### Try Clauses for Exceptions
The `try` function embeds the result in an `Either e b`
- where `Left e` is an Exception and `Right b` is a normal result.

Subsequently, we can *pattern-match* on this **Either value**.

Effectively this allows us to **wrap runtime errors neatly** as an `Either` result type.
```haskell
try :: Exception e => IO a -> IO (Either e a)

do
   x <- try ((readFile "foo.txt") >>= putStrLn)
   case x of
     Left e -> putStrLn $ "you've got problems: " ++ (show (e::IOException))
     Right r -> return r
```

Note that unlike in Java, Python and other mainstream languages, **exception handling is based purely on function calls** rather than *requiring built-in language keywords*.