# Monad Transformers
## What is a Monad?
Recall from earlier lectures that a *monad* is a typeclass in Haskell, representing a computational structure or context.

A monad combines computations into an ordered sequence with the *bind* operator (`{haskell}>>=`).
Monads enable containment of side-effects in the type system, i.e. the `{haskell}IO` monad.

## What is a Monad Transformer?
This is a technique for *composing* **two monads** into a **single combined monad** that has the joint behaviour of both individual monads.
- Monad transformers are a *monad composition technique*.

There is a Haskell typeclass `{haskell}MonadTrans` with a characteristic function `{haskell}lift`:
```haskell
class MonadTrans t where
    lift :: (Monad m) => m a -> t m a
```
- The `{haskell}lift` function promotes a base monad function into the combined monad.
## Motivating Example
Do you remember we had a pattern matching triangle, before we knew how to use the monadic bind operator `{haskell}(>>=)`?

We are going to see something similar here, when we try to use `{haskell}Maybe` values in the context of the `{haskell}IO` monad.

The library function we will use for this example is
```haskell
findExecutable :: String -> IO (Maybe FilePath)
```
- The `{haskell}findExecutable` function searches through the system `{haskell}PATH` to find an executable file matching the string parameter value.

```haskell
import System.Directory

findAllExes = do
  a <- findExecutable "git"
  case a of
    Nothing -> return Nothing
    Just pathA -> do
      b <- findExecutable "ghc"
      case b of
        Nothing -> return Nothing
        Just pathB -> do
          c <- findExecutable "clang"
          case c of
            Nothing -> return Nothing
            Just pathC -> return $ Just (pathA, pathB, pathC)
```
- The key problem is that we are trying to deal with `{haskell}Maybe` values while we are with the `{haskell}IO` monad.

The return type of `{haskell}findExecutable` is IO (Maybe FilePath), and strictly speaking **this isn't a monad in itself** - *it's a monad-within-a-monad*.
## Example with Transformers
Let's think about combining the `{haskell}IO` monad and the `{haskell}Maybe` monad.

We will let `{haskell}IO` be our *base* monad (this is generally the case in *monad transformer stacks*.)
- So we use the `MaybeT` **monad transformer**.
In this way, we provide the `{haskell}IO` **monad** *with* **the characteristics of the Maybe** monad.

Here is the example program, which looks for three executable files and returns a triple of their paths:
```haskell
import Control.Monad.Trans.Maybe
import System.Directory

findAllExes :: MaybeT IO (FilePath, FilePath, FilePath)
findAllExes = do
  a <- MaybeT $ findExecutable "git"
  b <- MaybeT $ findExecutable "ghc"
  c <- MaybeT $ findExecutable "clang"
  return (a, b, c)

runMaybeT findAllExes
```

- `findExecutable` must be in the `{haskell}IO` monad, because it is touching file storage, looking for exe files.
- The `{haskell}Maybe` is necessary in case a particular exe file is not found in the `{haskell}PATH`.
- If any exe is not found, we return `{haskell}Nothing`, otherwise we return a `{haskell}Just` triple value, which is simultaneously in the `{haskell}Maybe` monad *and* in the `{haskell}IO` monad.

- The  `{haskell}MaybeT` constructor puts an `{haskell}IO Maybe` value into the monad transformer, and the `{haskell}runMaybeT` function extracts the `{haskell}IO` value from the monad transformer.

- Similarly, the `{haskell}lift` function will `{haskell}run` an IO action in the `{haskell}MaybeT` context. See the example below for more details, where we use `{haskell}getLine` and `{haskell}putStrLn` inside the `{haskell}MaybeT IO` monad.

```haskell
import Control.Monad
import Control.Monad.Trans
import Control.Monad.Trans.Maybe

isValid :: String -> Bool
isValid v = '!' `{haskell}elem` v

maybeExcite :: MaybeT IO String
maybeExcite = do
  v <- lift getLine
  guard $ isValid v
  return v
  
doExcite :: MaybeT IO ()
doExcite = do
  lift $  putStrLn "say something exciting!"
  exciting <- maybeExcite
  lift $ putStrLn ("this is very exciting! " ++ exciting)
```
- Note the use of the `{haskell}guard` monadic function here.  If the condition fails, `{haskell}Nothing` is returned. See <https://learnyouahaskell.com/a-fistful-of-monads> for more details about this. The `{haskell}guard` call succeeds or fails, in the monadic context, based on the value of the input boolean.

## Revisiting a Lie
Do you remember when we looked at the `{haskell}Reader`, `{haskell}Writer` and `{haskell}State` *monads*?
I told you I was lying about the types. well, now we understand the reason for this.

Actually, `{haskell}Reader` is a `{haskell}ReaderT` monad transformer, with the `{haskell}Identity` monad at the base of the transformer stack. Similarly, `{haskell}Writer` is a `{haskell}WriterT` with an `{haskell}Identity`.
- See for example <https://hackage.haskell.org/package/transformers-0.6.1.2/docs/Control-Monad-Trans-Writer-Lazy.html#g:2> for documentation about this.

## Implementation of a Transformer
This is beyond the scope of our coverage for today, but you might like to look at <https://en.wikibooks.org/wiki/Haskell/Monad_transformers> to see how the `{haskell}MaybeT` monad transformer is implemented. 
