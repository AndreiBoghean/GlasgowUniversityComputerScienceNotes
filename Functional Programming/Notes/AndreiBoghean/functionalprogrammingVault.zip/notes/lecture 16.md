# Functors & Applicatives
## Back to `{haskell}map`
Do you remember the `{haskell}map` function? It was the first *higher-order* function we encountered.

The `{haskell}map` function takes a function `{haskell}f` and maps it over a list:
```haskell
map :: (a->b) -> [a] -> [b]
map f [] = []
map f (x:xs) = (f x) : (map f xs)
```
- `{haskell}map` preserves the *structure* of the list, but transforms each individual element in the list according to the `{haskell}f` function.

So, we realise that the *length of the mapped list will be the **same***,
and **each transformed element in the mapped list occupies the same position** as its untransformed element in the original list.
## Mapping `{haskell}Maybe` values
The `{haskell}map` function allows us to *operate on elements in a **list context***.

it would be nice to do the same to values in **other contexts**.
- For instance, if we have an increment function `{haskell}\x->x+1`, how could we apply this function to a value `{haskell}Just 41`?

Ideally, we would like to *lift* our **increment function** *into the `{haskell}Maybe` context*, as below.
![[Pasted image 20250418165619.png|400]]

In fact, there is a function to do this, it's called `{haskell}fmap`.
```haskell
fmap (\x->x+1) (Just 41)
-- > evaluates to (Just 42)
```

Note the `{haskell}fmap` can transform the type of the contained element, as well ...
```haskell
fmap (length) (Just "Glasgow University")
-- > evaluates to (Just 18)
```

The reason why we can map over `{haskell}Maybe` values is because
`{haskell}Maybe` is an **instance** of the `{haskell}Functor` typeclass in Haskell.
## What is a Functor?
The **Functor** typeclass is used for types that can be *mapped* over.
==A **functor** is a *container* or *context* (e.g., `{haskell}Maybe`) that allows us to apply a function to its contents.==
```haskell
class Functor f where
  fmap :: (a -> b) -> f a -> f b
```

Conventionally, Haskell syntax also allows us to use an infix operator for `{haskell}fmap`:
```haskell
  (<$>) :: (a -> b) -> f a -> f b
```

Here are some examples of `{haskell}fmap` in action:
```haskell
fmap (+1) (Just 3)
fmap (*2) [1,2,3]
fmap (fmap Data.Char.toUpper) getLine
```

all of which could be rewritten using the equivalent infix syntax:
```haskell
(+1) <$> (Just 3)
(*2) <$> [1,2,3]
(Data.Char.toUpper <$>) <$> getLine
```

To summarise, an instance of a `{haskell}Functor` is a `{haskell}map`-able type.
## Functor instances
We can make any container type into an instance of the `{haskell}Functor` typeclass by providing a `{haskell}fmap` definition.

For example, the Haskell Prelude defines:
```haskell
instance Functor Maybe where
  fmap f (Nothing) = Nothing
  fmap f (Just x) = Just (f x)
```

Consider our binary tree custom datatype used in the labs:
```haskell
data Tree a = Leaf | Node a (Tree a) (Tree a)
 deriving (Show,Eq)
```

We can provide an `{haskell}fmap` definition for `{haskell}Tree` as follows:
```haskell
instance Functor Tree where
  fmap f Leaf = Leaf
  fmap f (Node x t1 t2) =
    Node (f x) (fmap f t1) (fmap f t2)
```


## Functor Laws
The **Functor** *typeclass* is used for types that can be mapped over.
- The `{haskell}fmap` function modifies the *elements* in the structure, but **preserves the structure** itself.

To guarantee this property of functors, *instances* of the `{haskell}Functor` typeclass are **expected to follow these rules**:
1. *identity*: `{haskell}fmap id == id`
2. *composition*: fmap (f.g) == (fmap f).(fmap g)

Like the monad laws we saw in Lecture 12, *Haskell is unable to encode or check these laws directly*.
- It is the **responsibility of the developer** (or a *theorem prover*) to **check the laws** hold for a `{haskell}Functor` instance.

So, for example, here is an example of a *bad* functor that doesn't obey the laws:
```haskell
instance Functor [] where
  fmap f [] = []
  fmap f (x:xs) = (f x) : (f x) : (fmap f xs)
```
- You can see that the structure of the list is altered.
  *each element is duplicated*. Hence both the **identity law** and the **composition law** *will be broken* by this definition of `{haskell}fmap`.

## Motivation for Applicative Functors
Suppose we have a function (like `{haskell}(+1)`) wrapped up inside a context (like a `{haskell}Maybe`).
How do we apply this function to values inside other `{haskell}Maybe` contexts?

The answer is the `{haskell}Applicative` typeclass, particularly the `{haskell}<*>` or *apply over* function.
```haskell
(<*>) :: Applicative f => f (a->b) -> f a -> f b
```

Look at the following code fragments:
```haskell
(Just (+1)) <*> (Just 2)
-- > evaluates to (Just 3)

[(*3)] <*> [1..4]
-- > evaluates to [3,6,9,12]
```

## Applicative Functors
###### the typeclass
The `{haskell}Applicative` typeclass is defined as follows:
```haskell
class Functor f => Applicative f where
pure :: a -> f a
(<*>) :: f (a -> b) -> f a -> f b
```
Here `{haskell}pure` puts a value (often a function) into the applicative context and
`{haskell}(<*>)` applies a wrapped function to a wrapped value.

All `{haskell}Applicative` instances are also `{haskell}Functor` instances.
This is because `{haskell}fmap` may be defined directly in terms of `{haskell}pure` and `{haskell}(<*>)`, i.e.
```haskell
fmap f x = (pure f) <*> x
```

###### example
Consider this example:
```haskell
pure (+) <*> (Just 41) <*> (Just 1)
-- > evaluates to (Just 42)
```
- Note that `{haskell}pure` exactly corresponds with monadic `{haskell}return` function.
## `{haskell}Maybe` is an Applicative

The built-in definition of `{haskell}Applicative` for `{haskell}Maybe` is as follows:
```haskell
instance Applicative Maybe where
  pure = Just
  (<*>) Nothing _ = Nothing
  (<*>) _ Nothing = Nothing
  (<*>) (Just f) (Just x) = Just (f x)
```


It’s possible to ‘lift’ *two-operand* functions into **Applicative** structures
- e.g. using the utility `{haskell}liftA2` function.

try:
```haskell
import Control.Applicative
liftA2 (+) (Just 1) (Just 2)
liftA2 (+) [1,2,3] [4,5,6]
```
- Note that `{haskell}liftA2` can be defined in terms of pure and <\*> --- can you see how?

In summary, `{haskell}Applicative` functors take the **concept of regular functors** one step further, since `{haskell}Applicative` *enables function application* to occur *within* the **container context**.
## Applicative Laws
These are similar to the laws for functors and monads.
The definitions of the applicative laws are beyond the scope of this course, and therefore non-examinable.  maybe see <https://en.wikibooks.org/wiki/Haskell/Applicative_functors>

## Relationship between Functors, Applicatives and Monads

Look at the characteristic functions for these three typeclasses:
```haskell
(<$>) :: Functor x => (a->b) -> x a -> x b
(<*>) :: Applicative x => x (a->b) -> x a -> x b
(>>=) :: Monad x -> x a -> (a -> x b) -> x b
```

Can you observe the similarities between these three functions, in terms of how they apply functions on values in contexts?

Admittedly, to make it neater, we should probably consider the *reverse bind* function `{haskell}(=<<)` which flips the order of the parameters:

```haskell
(=<<) :: Monad x => (a -> x b) -> x a -> x b
```

- The `{haskell}fmap` function lifts a function into a context and applies it to elements in that context.
- The `{haskell}<$>` function applies a function in a context to a value in the same context.
- The *bind* function applies a function that expects a value outside the context but returns a result in the context, to a value *already* in the context.

*If you understand the above sentence, you are well on the way to Haskell enlightenment.*
If you don't understand it, think hard about why (Just (Just (Just (Just "foo"))))
is not the same as (Just "foo")