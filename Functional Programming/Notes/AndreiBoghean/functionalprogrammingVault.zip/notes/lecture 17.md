### referential transparency
###### what is referential transparency?
an expression is said to be *referentially transparent* if it **can be replaced** with it's *corresponding value* **without altering the program** *behaviour*

###### what **isnt** referential transparency?
e.g. C code with side-effects:
```c
int f(int x) {
	static int secret = 0;
	secret++;
	return x+secret;
}
```
or
```c
printf("%d\n", f(1) + f(1));
// compare with …
int tmp = f(1);
printf("%d\n", tmp + tmp);
```

###### referential transparency in haskell
```haskell
• let f x = x+1
• let tmp = (f 1) in print $ tmp + tmp
• cf
• print $ (f 1) + (f 1)
```
- these two are functionally equivalent.
- if we wanted to mimic the `static` behaviour from C above, we'd need the *state* monad

###### why is referential transparency good?
- good for reasoning about programs (manually/automated, informally/formally..)
- good for parallelism (no side-effects / inter-thread dependencies)
- evaluation is simply term rewriting. (it's just cf evaluation of lambda terms)
#### haskell state
```haskell
import Control.Monad.State
import Control.Monad.IO.Class (liftIO)

f :: Int -> StateT Int IO ()
f x = do
	secret <- get
	let result = x+secret+1
	liftIO $ putStrLn (show result)
	put (secret+1)
	
main :: IO()
main = do
	((), state') <- runStateT (f 1) 0
	((), state'') <- runStateT (f 1) state'
	return ()
```
- line 4 features a hidden preserved state across function calls using the *State transformer*, wrapping the IO monad as it's **base**.
- and **liftIO** in line 8 executes IO operations within the context of the state.

### lambda calculus
a theoretical model for computation invented by alonzo church in 1930s.
- universal computation can be represented in lambda calculus

equivalent to turing machines
- as per the chruch-turing thesis

is the basis of functional programming

evaluation involves term rewriting

###### components (terms) of lambda calculus
**variables** like *x*, *y*
**function abstraction** $\lambda x.M$ - like a function definition (where x is a bound *variable* in **M**)
**function application** M N - a function invocation

##### rewrite rules for lambda calculus
###### $\alpha$ conversion is the act of renaming bound variables (i.e. *variable* substituted with a **variable**)
$\lambda x.M \to^{\alpha}\lambda y.M[y/x]$ - **y** is a *fresh* variable name
$\lambda x.x\to^{\alpha}\lambda z.z$ - *identify function* is **the same**, *regardless* of it's **parameter name**.

###### $\beta$ reduction is function call evaluation (i.e. *variable* is substituted with a **value**)
$(\backslash x.M)A \to^{\beta}M[A/x]$ - **parameter** x is *replaced* by *lambda term* A (*the value* of the **argument**)
e.g. $(\lambda x.\lambda y.y\ x)(\lambda z.z)\to^\beta \lambda y.y(\lambda z.z)$ - uses of the *variable* **x** are *replaced* by *expression* $(\lambda z.z)$

#### computability
any computable function can be represented in lambda calculus.


##### church numerals - encoding of numbers
a church numeral is a function that takes two parameters $\backslash f \to \backslash x \to \dots$
and applies f to x N times.
```haskell
0: \f -> \x-> x
1: \f -> \x -> f x
2: \f -> \x -> f (f x)
n: \f -> \x -> fn x -- n applications of f
					-- (iterate f x) !! n
```

###### adding church numerals
let add be a function taking two church numerals M and N.

```haskell
add = \ M N f x -> N f (M f x)
-- when N=3 and M=2, this evaluates to..
f(f(f  (f(f(x)))  ))
-- ^ N*f  ^ M*f
```

###### decoding church numerals *in haskell*
```haskell
unchurch :: (a->a) -> a -> a -> Int
unchurch n = n (+1) 0
```
- lecture slides refuse to elaborate, but I suspect this is the application of (+1) to 0 n times, where (+1) is considered a "*successor function*"

#### lambda calculus usability note
lambda calculus is more of a theoretical representation rather than something practically used in the real world.

it shows the smallest "*programming language*" possible to represent **any** *computable function*.
- such a language only needs function **abstraction** and function **application**
- with such a restricted set of operations, corresponding programs are ***very verbose***

### equational reasoning
#### program properties
previously we used `QuickCheck` to carry out property-based testing.
- this was **dynamic testing** using random data to test that **==specified==** invariants held for a fixed number of tests.

alternative to this, we may instead want to use **static verification** to prove function properties of functions *generally* that hold for *all inputs*.
###### e.g.
given a function definition
```haskell
example :: Int -> Int -> Int -> Int
example x y z = x*(y+z)
```

we may want to prove that `{haskell}example a b c == example a c b`.
this can be shown by
```haskell
example a b c
= a * (b+c) -- { a function definition }
= a * (c + b) -- { symmetry of + }
= example a c b -- { example function def }
```
- this is using only the *function definition* and simple *properties of arithmetic*

##### proof by structural induction
given a property p(x) where x is a list..
**base case** - prove p(\[\])
- i.e. the property holds for the empty list
**inductive case** - prove that `{haskell}p(xs) -> p(x:xs)`
- i.e. if the property holds for a list **xs** of length **n**, we can show it holds for a list of *length **n**-1*.
then, by structural induction, p holds for arbitrary lists.

###### example 1
we want to prove that, for all lists xs and ys:
- `{haskell}length (xs ++ ys) = (length xs) + (length ys)`

**first, the base case, xs, for \[\]**
`{haskell}length ([]++ys)` = `{haskell}(length []) + (length ys)`
`{haskell}length (ys)` = `{haskell}0 + (length ys)`
`{haskell}length ys` = `{haskell}length ys`
true.

**second, the inductive case, for list xs of length n+1**
first, assume that `{haskell}length (xs ++ ys) = (length xs) + (length ys)` holds for **n**.

then, `{haskell}length (x:xs ++ ys) = (length x:xs) + (length ys)`
becomes `{haskell}1 + length (xs ++ ys) = (1 + length xs) + (length ys)`
using definition of length
and then `{haskell}1 + length (xs ++ ys) = 1 + (length xs) + (length ys)`
thanks to associativity of +
lastly, `{haskell}1 + (length xs) + (length ys) = 1 + (length xs) + (length ys)`
using the aforementioned assumption


**second, the inductive case, for list xs of length n+1**

then, `{haskell}length (x:xs ++ ys) = (length x:xs) + (length ys)`
becomes `{haskell}1 + length (xs ++ ys) = (1 + length xs) + (length ys)`
using definition of length
and then `{haskell}1 + length (xs ++ ys) = 1 + (length xs) + (length ys)`
thanks to associativity of +
lastly, `{haskell}1 + (length xs) + (length ys) = 1 + (length xs) + (length ys)`
using the aforementioned assumption

###### example 2
we want to prove that, for all lists xs, `{haskell}length xs >= 0`
- i.e. the length of an arbitrary list xs is non-negative.

base case for a list \[\]
length \[\] = 0 >= 0.

now assume `{haskell}length xs >= 0` holds for a particular xs.
inductive case for an arbitrary list x:xs gives
`{haskell}length x:xs >= 0` =
`{haskell}1+(length xs) >= 0` =
`{haskell}(length xs) >= -1`
and we know `{haskell}(length xs) >= 0` so by extension this holds.