##### tuples
###### description
a tuple is an ordered sequence of expressions with a known length
![[Pasted image 20250412144345.png|250]]
they're useful for returning multiple values from functions.

###### deconstruction
a pair of tuples can be deconstructed with the fst and snd functions
![[Pasted image 20250412144432.png|350]]
but can also be deconstructed with pattern matching
![[Pasted image 20250412144727.png|350]]

##### functions
###### description
a function *maps* a value to another value.

haskell functions are **first-class**,
alowing us to *let-bind* it, *return* it, *pass it as an argument*, etc.

###### anonymous functions
initiated with a blackslash. the backslash is supposed to be read as "lambda"
![[Pasted image 20250412145022.png|250]]

###### multi-paramter functions
there are multiple ways a function may take multiple parameters

1. **a tuple** `\(n1, n2) -> n1 + n2`
	   - slightly annoying, requiring the *construction* and *deconstruction* of a tuple.
2. **Currying** `\n1 -> \n2 -> n1 + n2`
	   - slightly more complex, but more usable.
	   - "give me an int, I give you a function that takes an int and returns an int"

##### equations
###### description
an equation gives meaning to a name
e.g. `favouriteNumber=42` or `add = \x -> \y -> x+y`

they can be used to define functions more concisely.

the *left-hand-side* **cant contain any computations**.
- but it **can** contain *pattern-matching* which is advanced logic in it's own right.

###### function equations
a function takes some arguments, performs some computation, and returns a result.
- haskell has many such functions in the ==prelude== which are all fairly useful.

a function equation is structured as follows:
![[Pasted image 20250412145825.png|400]]
a function equation may optionally have a **type signature**.

##### function application
###### functions in expressions
expressions can contain functions.
in haskell (and most functional languages) you dont need to parenthesise arguments to functions, meaning `min 1 2` is perfectly valid.

==function application binds tightest==, meaning `fx * 2` == `(f x) * 2`

###### partial application
an advantage of **currying** is *partial application*.
````col
```col-md
flexGrow=1
===
this here code produces an addFive function that takes a single argument x, and passes it to add 5 x, incrementing it by 5.
```
```col-md
flexGrow=1
===
![[Pasted image 20250412150323.png|250]]
```
````
this allows us to **specialise** a function without needing to rewrite or duplicate it's logic.
- i.e. function generators are ez.

###### function composition
we can also **compose** functions, using the function composition operator.
![[Pasted image 20250412150702.png]]
this operator enables programming in **==point-free==** style, which tries to avoid introducing variable names where possible.

##### parentheses
parentheses avoid ambiguity. they're particularly necessary for negative numbers to avoid subtraction, but may generally be avoided in favour of style.

##### equations and assignments
in an imperative langauge, you may write `x := x + 1` or `x++`.
- this **modifies** the value of *x*.

in haskell, `x = x + 1` is **not** the same.
- it tries to define x as the successor of x.
- haskell will still try to calculate it, and fail. in fact, enter an infinite loop.
	  - try `import Debug.Trace` `x=5` `x = trace "hi" x+1` and see it loop.

haskell doesnt permit reassignment; **it doesnt make sense for x to be both** 5 and 6.
- *never destroy old values, just compute new ones*.

##### parametric polymorphism
![[Pasted image 20250412152418.png|500]]
- same function; many different types.

**polymorphic functions** have *type variables* to stand for types.
- see x, y, x above.
and can also have type variables within types, e.g. a *list of type a*.


##### lists & sequences
a list is an **ordered** sequence of values of the *same type*.
haskell supports list sugar like `[1..10]`, `['a'..'z']`, or even `[1..]`
- unbounded lists are allowed because these constructs are constructed **lazily**.
###### list comprehensions
list comprehension notation mimics set builder notation.
![[Pasted image 20250412152914.png]]
you can have **multiple generators** and **multiple conditions**.

###### accessing lists
`head` gives the *first* element. `tail` gives everything **except** the *first* element
`init` gives everything **except** the *last* element. `last` gives the *last* element.

![[Pasted image 20250412153115.png|400]]

these are all ==potentially undefined==, if the list is empty.
- use pattern matching instead unless you're sure.

###### zipping lists
**with a tuple**
`zip :: [a] -> [b] -> [(a, b)]`
![[Pasted image 20250412154357.png]]
the resulting list is only as long as **the shortest input**.

**with arbitrary logic**
`zipWith :: (a -> b -> c) -> [a] -> [b] -> [c]`
![[Pasted image 20250412154544.png]]

##### writing programs
###### in python..
![[Pasted image 20250412155200.png|500]]
###### in haskell.. (using *let bindings*)
![[Pasted image 20250412155253.png|500]]
**equivalently..** using *inline let bindings*
![[Pasted image 20250412155308.png|500]]
- note that each *let* needs a **continuation**, because ==let is not a statement==
- *let* is an ==expression== that ***produces a value***.

**also equivalently..** you can use where bindings
![[Pasted image 20250412155507.png|500]]
- these are equivalent to let bindings, but *these go after the function body*.

==where is **not an** *expression*==.

##### conditionals (and pattern matching)
###### guards (plain conditionals)
![[Pasted image 20250412160051.png|300]]

these guards are usually used as a clean alternative to cluttered if statements
````col
```col-md
flexGrow=1
===
**if statements**
![[Pasted image 20250412160249.png|300]]
```
```col-md
flexGrow=1
===
**guards**
![[Pasted image 20250412160101.png|300]]
```
````
###### case expressions (full pattern matching)
![[Pasted image 20250412155957.png]]
- the idea with these is to allow pattern matching **within** a definition