##### recursion
###### how are lists defined?
we've so far considered lists to be primitive data types,
but in fact they are **inductively defined data structures**.
![[Pasted image 20250412161802.png|350]]
so `[1,2,3]` is actually syntactic sugar for `1 : (2 : (3 : []))`
- this allows us to write **recursive functions** over *lists*

###### recursion vs iteration
**imperative** languages typically use *iteration* when working with collections of values.
- this is because we often **perform statements** using *data in the collections*
**functional** languages on the other hand use *recursion*.
- this is because we often **construct a new result expression** using *data in the collections*

###### designing recursive functions

````col
```col-md
flexGrow=1
===
first think about the *structure* you are defining recursion on (integers? lists?) and then..

1. have a **base case** with *no further calls*.
2. have a **recursive/inductive case** which *calls itself*.
```
```col-md
flexGrow=1
===
![[Pasted image 20250412162252.png]]
```
````

###### examples
**factorial example**
![[Pasted image 20250412162359.png|500]]

**fibonacci example**
![[Pasted image 20250412162425.png|500]]

***better* fibonacci example**
![[Pasted image 20250412162444.png|500]]

###### tail recursion
![[Pasted image 20250412162732.png|400]]
haskell uses **tail call optimisation** which we can take advantage of to avoid *stack overflow*.
- all **tail calls** (where a call is the last part of an expression) cam be implemented using ***constant stack space***
- note: regular fibonacci above *isnt* tail recursive, but **better** fibonacci **is**.
###### mutual recursion
![[Pasted image 20250412162747.png|400]]
sometimes, we want to write **mutually recursive** functions, which call each other.
haskell permits this easily, since *all other definitions are in scope*.
- other languages may require you to mark these explicitly before you may be able to.

##### algebraic datatypes
###### how to define them
**==sum== type**
![[Pasted image 20250412165601.png]]
- this is a ***sum*** type, with alternative values.
- all of these types individually have type Season.

**==product== type**
![[Pasted image 20250412165937.png]]
- this is a ***product*** type, with a combination of values.
- if we wanted to, we could restrict this to legal grades by:
	  - enumerating allowed letters ['a'..'h']
	  - adding validation functions

###### richer data types with content
![[Pasted image 20250412170146.png]]
- each data constructor can also have some **associated data**
- good for modelling, but need some behaviours

###### pattern matching on ADTs
![[Pasted image 20250412170419.png]]
when working with a data type, we often need to *pattern match* to see **which data constructor was used** to create the value
- you need to use *brackets* when trying to match on **compound values**.

pattern matching may be done using equations (as here) or through a case expression.

###### recursive data types - binary trees
![[Pasted image 20250412170811.png]]
this is how you define a data type that uses itself.
- recursive data types are a.k.a. *inductively defined* data types

###### parameterised data types - binary trees
![[Pasted image 20250412170906.png]]
we can *parameterise* a data type by putting a type variable on the left-hand-side of the data definition.
- the list type `[a]` is already an example of this.

###### the maybe type
![[Pasted image 20250412171143.png]]
- this is useful for *potentially failing* **computations**
- **pattern matching must be used** on Just a / Nothing to determine the outcome.