##### higher-order functions
a higher-order function is a *function* which **takes another function** as an *argument*.
- we've already seen several; map, filter, twice
- it's good practice to use HOFs where applicable rather than hand-roll recursive functions yourself.

###### map
![[Pasted image 20250412172458.png|450]]
a **map** applies a function to every element in a list.
it's *defined recursively* by **building up a new list** with the *function applied to each element*.
sidenote: you can fuse map like `map f (map g xs) <-> map (f . g) xs`

the **implementation** looks like
![[Pasted image 20250412172828.png|450]]
alternatively, ==using a **list comprehension**== `[ f x | x <- xs ]`

###### filter
![[Pasted image 20250412172715.png|450]]
**filter** retains every element which satisfies a *predicate*.
*only prepend* the element if the *predicate* evaluates to **true**.

the **implementation** looks like
![[Pasted image 20250412172838.png|450]]
alternatively, ==using a **list comprehension**== `[ x | x <- xs, p x ]`

###### list comprehensions in terms of filter and map
since they both corespond pretty directly to list comprehensions, the reverse can be performed i.e. specifying simple list comprehensions **using** *filter and map*.

**doubling every even number** is fairly achievable
![[Pasted image 20250412173822.png|450]]

but anything with multiple generators isnt possibe, e.g. pythagorean triples
![[Pasted image 20250412173910.png|450]]
that's because this would require some form of *flattening* intermediate lists

##### folds
a **fold** is a way of reducing a list into a single value.

*the idea* is that we have a function which takes
an element of the list, and an **accumulator** value,
and then *produces* a *new* **accumulator** value.


there are two types of fold, depending on the desired **associativity**.
- `foldl :: (b -> a -> b) -> b -> [a] -> b`
- `foldr :: (a -> b -> b) -> b -> [a] -> b`

the fold operation pops from the side of the array dictated by the associativity
- i.e. foldl consumes from the left of the array, and vice-versa.
the **accumulator** then goes on the other side.

###### left fold
the left fold is **left-associative**, so it consumes items from the ***left*** of the array,
and combines into the accumulator on the ***right***
![[Pasted image 20250412180611.png|300]]

###### right fold
the right fold is right-associative, so it consumes items from the ***right*** of the array,
and combines into the accumulator on the ***left***.
![[Pasted image 20250412180654.png|300]]

###### foldl foldr differences
![[Pasted image 20250412180855.png]]
- the recursive call is **outermost** in *left* fold
- the recursive call is **innermost** in *right* fold

##### property-based testing
suppose you have a program.
property based-testing suggests you specify some *properties* that should hold true for it
- set up as boolean predicates
these *properties* can then be tested using a tool such as quickcheck in haskell.
- the tool generates many random (but type-correct) input arguments and checks that the properties hold true for those arguments.

###### list length example
in english.. "a list containing n elements has length n"
in haskell.. `let prop_len = \n -> (length [1..n] == n)`

to execute, simply `quickCheck prop_len` (after `import Test.QuickCheck`)

**problem**: this property is incorrect.
we should instead say
"a list containing n elements has length n for non-negative integer values n"
and implement this as
`let prop_len = \n -> (if n>=0 then length [1..n] == n else True)`

with this new property, we can check again. we may use verboseCheck to actually see the test cases.
- note: quickCheck stops at the simplest case it can find that violates a property.
- a lot of research in poerty-based testing concentrates on shrinking counterexamples into a minimal case (editor's note: ...whatever that means)

###### list sort example
the function we want to test is the following:
![[Pasted image 20250412181645.png|500]]

some properties we can check on this are..
"any sublist of the natural numbers beginning at 1 should be ascending"
- `prop_asc1 = \n -> isAscending (take n [1..])`
"Lists containing repeats of a single value are not ascending"
- `prop_asc2 = \n -> if n < 2 then True else not (isAscending (take n (repeat 1)) )`
"Adding the length as an element to the end of an ascending list makes it not ascending"
- `prop_asc3 = \n -> if n<=0 then True else not (isAscending ([1..n]++[n]))`

*these properties fail*, because **our original isAscending implementation is wrong**!
it should actually look like..
![[Pasted image 20250412181942.png|500]]

###### different kinds of testing
unit testing - specify a scenario with **precise data** and *make assertions* on the results
fuzz testing - generate **randomized data** for an *opaque* system
property-based testing - generate **random inputs** for *specified properites*