#### evaluation strategies
expressions are evaluated as a program runs.
the *order* of expression evaluation depends on both the **language semantics**, *and* the **implementation pragmatics**.
you may have
- ***eager*** evaluation (a.k.a. *strict* evaluation, or call by *value*)
- ***lazy*** evaluation (a.k.a. *non-strict* evaluation, or call by *need*)

##### lazy evaluation
note: lazy evaluation is demonstrated in C operators && and ||
###### benefits
- can compute with **large data structures**, even using *potentially infinite lists*
- can compute with **expensive functions**, whose cost is only ever paid when *the function is actually used*
- can compute with dangerous values, e.g. undefined or bottom, which only cause problems if evaluated
	  - **undefined** raises a *runtime exception* when evaluated, but has a **generic type** so *can be used in any expression context*
	  - **let botttom = bottom** is an *infinite* **recursively defined** type whose evaluation will *loop for ever* (it similarly has a **generic type**)

###### drawbacks
- difficult to combine with **exception handling**, since *the order of evaluation is unclear*.
- sometimes **harder to predict**, e.g. in the case of *lazy IO*
- accumulates **memory pressure** as an evaluation graph builds up with *un-evaluated expressions* ("**thunks**")
	  - a symptom of evaluation only triggering when it is "needed"

###### aside: interesting infinite lists with lazy evaluation
- `[1..]` - the list of all non-negative integers
- `let ones = 1:ones` - an infinite list of 1 values
- `` primes = sieve [2 .. ] where sieve (x:xs) = x:(sieve [x'| x' <- xs, x' `mod` x /= 0] )`` - the infinite list of primes (via sieve of Eratosthenes)

==also: some useful functions for infinite lists==
![[Pasted image 20250413113811.png]]

#### polymorphism (in more depth)
here are 2 kinds of polymorphism:
**parametric** - functions operate on the *shape* of the arguments, rather than with the data, so they can operate on many types.
- uses **==type variables==**
**ad-hoc** - like method overriding in java. same function name but different implementations for different types.
- uses **==typeclasses==**

##### parametric polymorphism (in more depth)
in a function using parametric polymorphism, it uses e.g. a and b which are *type* **variables**.
- when called on *concrete* **values**, the function's type variables are ***==specialised==*** to the corresponding *concrete* **types**.
- a parametrically polymorphic function does not depend in any way of the types of it's arguments, e.g. map does not actually do anything to the array elements, it simply executes the function.

examples of such functions are id, const, map, filter, etc.

###### how many functions have type `a -> b -> a`?
only one function.
![[Pasted image 20250413122851.png|200]]
- this is because any function implementing this type can not possibly make any assumptions about the underlying types, so can not reasonably modify them in any way, so the only possible implementation is the one which simply returns.

###### polymorphic functions
````col
```col-md
flexGrow=1
===
![[Pasted image 20250413123311.png]]
```
```col-md
flexGrow=1
===
![[Pasted image 20250413123320.png]]
```
````
- note that both only *manipulate* (rather than **use**) the variables.

###### polymorphic data types
![[Pasted image 20250413123518.png|400]]
in this case, tree can contain values of any type within it
- note that, once it's *specialised*, the type becomes **fixed and concrete**

###### polymorphic functions on polymorphic data types
![[Pasted image 20250413123821.png|450]]
note: this is an instance of a **functor**.

##### ad-hoc polymorphism (via typeclasses)
method or operator overloading in java is a form of *ad-hoc polymorphism*.
- ad-hoc since, *unlike parametric polymorphism*, ad-hoc is not a *core* part of the **type system**
![[Pasted image 20250413124145.png|450]]
- ad hoc polymorphism is useful for defining versatile operations like add on both integers and strings.

###### typeclasses
a *typeclass* specifies a **list of operations** to be defined for a type
- in a sense, typeclasses bring **parametric** and **ad-hoc** polymorphism *closer together*.
	  - it allows us to say "we dont care what a particular type a is, only that it supports these features"

to **define a typeclass**, do this
![[Pasted image 20250413130712.png|400]]
- for a type to be part of the *show* **typeclass**, it must *implement* a function **show**.

to **demand something uses the typeclass**, do this
![[Pasted image 20250413131904.png|450]]
- in the *kind* of the **signature**, you can specify that type a *is part of the Show typeclass*.

to **implement a typeclass**, you can either:
1. use the *==deriving clause==*
   ![[Pasted image 20250413133418.png|450]]
	   - this is possible because show and eq can **abuse** the *data constructors*.
	   - if the constructors use **associated data**, *they themselves also need to support* show/eq
2. use *==instance declarations==*
   ![[Pasted image 20250413133321.png|450]]


you should **derive** when:
- you want "default" behaviour
- the behaviour is already specified for all associated data
- the typeclass supports deriving
you should **instance** when:
- the typeclass *doesnt* support deriving (e.g. a custom **typeclass**)
- you want behaviour different from the default (e.g. printing a tree)

###### typeclass leggy example
**some ADTs**:
````col
```col-md
flexGrow=1
===
![[Pasted image 20250413142728.png]]
```
```col-md
flexGrow=1
===
![[Pasted image 20250413135715.png]]
```
````

````col
```col-md
flexGrow=1
===
**the typeclass**:
![[Pasted image 20250413135756.png]]
```
```col-md
flexGrow=1
===
**the function** *using the typeclass*:
![[Pasted image 20250413135915.png]]
```
````
- note that this *could* have the type *Insect -> String*, but then it wouldnt work on Mammal.

**the implementations**:
````col
```col-md
flexGrow=1
===
![[Pasted image 20250413135835.png]]
```
```col-md
flexGrow=1
===
![[Pasted image 20250413135846.png]]
```
````
