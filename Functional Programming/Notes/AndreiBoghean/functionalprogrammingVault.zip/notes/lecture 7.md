### purity
what is *functional purity*?
- **stateless** - the function always evaluates to the *same result* given the *same arguments*
- **side-effect** free - the function does nothing apart from *simple expression evaluation*
	  - *no interaction* with the "outside world"
- **total** (ideally) - defined for *all inputs*

#### problem with purity
our code needs to do I/O. (get input, send output, read/write files, etc.)
but IO operations are *externally visible*, i.e. they're not side-effect free.

#### the solution
##### naive purity workaround
what if you could simply *do* inpure actions in haskell?
![[Pasted image 20250413151138.png]]
- **church-rosser** is lost :(
	  - the property allowing **reductions** to be performed in *any order*
- we also loose **referential transparency**
	  - the property allowing us to *replace a piece of code* with **the value it produces**
- lastly, **lazy evaluation** is broken.
	  - this nail in the coffin removes all of our reasoning power

##### dedicated IO type
the key idea behind this is to **mark** side-effecting operations with a *type constructor*; IO
![[Pasted image 20250413151920.png|500]]

##### mixing pure functions and IO computations
###### why it's hard
when using the IO type, one does not simply "use" the result.
- you can not `reverse getLine` because **getLine -> IO String** and *reverse :: string -> string*

a *string* is **data**
an *IO string* is a **computation** that ***produces*** a *string*.

such side-effecting computations are **always** marked in their types.

###### the proper way to do it
to **create** a side-effecting IO computation, you use the **do** notation.
![[Pasted image 20250413153942.png|500]]

to **create** a side-effecting IO computation that ***returns a value***..
![[Pasted image 20250413154550.png|500]]

regardless of the logic of your computation, there must be a *top-level way to evaluate it* and extract the inner result. this is the ***main*** function.
![[Pasted image 20250413162108.png|330]]
- evaluated when the program is run

GHCI runs everything as an IO computation, allowing us to e.g. print things out,
but it's still good practice to keep as much of the program as pure as possible.

###### escaping an IO computation?
there is technically a way to carry out IO computations outwith the IO constructor.
- `unsafePerformIO` from `System.IO.Unsafe`
but it's bad practice.

instead, think of IO as though you are *using do-notation to build a bigger computation* by stringing together smaller IO computations, with **main as your entrypoint**.

###### IO for trace debugging
![[Pasted image 20250413163154.png]]
- uses unsafePerformIO in implementation; should **only** be used for debugging.
###### IO beyond the console
**IO encompasses a large number** of *impure operations* beyond just console I/O operations.
- *getting time* with `getCurrentTime :: IO UTCTime`
- *file opereations* with `readFile :: FilePath -> IO String` or `writeFile :: FilePath -> String -> IO ()`
- sockets, graphics, printing, spwaning processes, etc.

##### pseudo random number generation
PRNGs might *seem* to require an impure operation, since conventionally they re-use the same PRNG object and produce new values with the same function call,
but in fact they *are* **pure** because they produce a ***new*** prng.
- only *seeding* the prng is ***impure***

##### reference cells
with IO, we can make use of *mutable reference cells* that **store some data** and have **modifiable contents**.
![[Pasted image 20250413164056.png]]