## monads
### prerequisite setup
#### monad motivation - using maybes
###### maybe refresher
![[Pasted image 20250413165327.png|350]]
- `Maybe a` is like a type-safe null that can be used to define *potentially failing computations*
- e.g. `Just 5` and `Nothing` are both valid `Maybe` types.
- whenever we want to extract the `a` from `Maybe a` we need to pattern-match to evaluate whether it has a `Just` or a `Nothing`
###### naively chaining maybes
suppose we have a safeiv that returns Nothing for a division by 0.
![[Pasted image 20250413165547.png|400]]

**now suppose we want to use that function twice**. *how*?
we can pattern match on the firs result, and conditionally chain the next division.
![[Pasted image 20250413165641.png|400]]

==but this is horrible== because it's full of boilerplate and leads to deeply-nested case statements.
###### improving maybe chain with pattern-matched HOFs
we could *remove some of the boilerplate* by using **HOFs** to do our ***pattern matching***
![[Pasted image 20250413165812.png|500]]

now, rewriting our previous code looks like this
![[Pasted image 20250413165925.png|400]]

````col
```col-md
flexGrow=1
===
***using referential transparency a bit to demonstrate execution looks like this..***
![[Pasted image 20250413170053.png]]
```
```col-md
flexGrow=1
===
***or alternatively like this in the event of a failure***
![[Pasted image 20250413170122.png]]
```
````
#### nondeterministic computations
sometimes we may want to have a computation that **returns multiple possible results**.
- i.e. a *nondeterministic computation*
e.g. a coin toss that can be either heads or tails.

hypothetically: what if we wanted to build a list of
*all possible combinations of* **2 coin tosses**, given the **2** *possible results*?

we would want to
1. *draw* the *first* element from the first list and then the *first* element from the second
2. *draw* the *first* element from the first list and then the *second* element from the second
3. *draw* the *second* element from the first list and then the *first* element from the second
4. *draw* the *second* element from the first list and then the *second* element from the second
giving `[(Heads,Heads), (Heads,Tails), (Tails,Heads), (Tails,Tails)]`

###### using a HOF approach
you may build a function like either of these (they are equivalent)
````col
```col-md
flexGrow=1
===
![[Pasted image 20250413171326.png]]
```
```col-md
flexGrow=1
===
![[Pasted image 20250413171616.png]]
```
````
- given a *list* and an *action that generates a list*, **apply that function** to **each element** of the list and **combine all the results** into a *flat list*.

then create a *function* that, given an **item** and a **list**, will *concatenate item with each list member*.
- in pythonic pseudocode you effectively have  `[for item in list: [item, a]]`
this function, then, could be *applied to each item of the list*, giving a double loop.
- in pythonic pseudocode: `[for a in list: [for b in list: [a, b]]]`

![[Pasted image 20250413172202.png|500]]

###### using a list comprehension
![[Pasted image 20250413172238.png|500]]
- note: this requires **multiple generators**, which *cant be expressed* with **just** *map and filter*
- note: list comprehensions are **syntactic sugar**, implemented with a *withEach equivalent*

#### revisiting IO
recall that IO do notation builds up a computation.
- effectively, it 1. runs a **single** *IO computation* and 2. **uses it** in the *rest of the computation*

if we wanted to do this without the DO notation, we'd first need a withIOresult
![[Pasted image 20250413173911.png|550]]
which we could then use to chain IO operations.
![[Pasted image 20250413173937.png|350]]

the *implementation* of withIOresult *maps to a primitive* that is handled by the *runtime system*.
it **runs** the IO computation, **pattern matches** the value, and **applies the function**.
it can then be chained, allowing us to write this **getAndPrintReverse** *without do notation*.

#### the pattern
in all of these withX functions, there is a clear pattern.
![[Pasted image 20250413174311.png]]
in each case, there is
1. a compuation producing a *result* (potentially failing, non-deterministic, side-effecting)
2. a function that builds a *bigger computation* from the result
3. the *overall result* **being** the *bigger computation*
### actually monads
monads are a generalisation of the pattern we saw earlier.
technically, they're just a data type that
*implements the monad typeclass* and *satisfies the monad laws*.
###### monad requirements
to be a monad, a data type needs two things:
1. a way of *constructing a trivial computation* (**initialisation**)
2. a way of *building a larger computation* from the results of a previous one (**composition**)
in addition, the monad must also satisfy the ***==monad laws==*** (see later notes)
AND it must also be an ***==applicative functor==*** (see later notes)


###### monad typeclass implementation
![[Pasted image 20250413175234.png]]


#### monad examples
##### maybe monad
###### definition
![[Pasted image 20250413175404.png|250]]
###### chaining
![[Pasted image 20250413175456.png|350]]
- here, the **bind** operator (>>=) is used to chain the flow of logic in the event of success.
- also, **return** is used to take a value and **wrap it** into the *monadic context*.
- if *any sub-computation fails*, then **the whole result will be Nothing**


##### IO
since IO is also a monad, we can use monadic notation to ***circumvent do notation***
![[Pasted image 20250413175740.png]]


#### do notation is just monad syntax
![[Pasted image 20250413175811.png]]
- while do notation is widely used and very useful, sometimes the monadic notation may be preffered.

#### do notation for other monads (besides IO)
since do notation == monadic syntax, logically do notation works for any monad.
![[Pasted image 20250413175942.png]]

#### monad typeclass hierarchy
recently, the **monad typeclass changed** so that *each monad* must **also be an instance** of *two other typeclasses* - **functor** and **applicative**. (see l8r notes for these)

there is another proposal to remove `return` from the monad typeclass, and rely exclusively on `pure :: (Applicative f) => a -> f a` from **Applicative**.
- this makes sense mathematically, but not pedagogically