# More Monads
## Introduction
So, let's revisit the `{haskell}Monad` **typeclass**.

Recall it has *two characteristic methods*, i.e. `{haskell}return` and bind `{haskell}(>>=)`.
- The `{haskell}return` function "puts something into" the monad
	  - i.e. boxes it up in the structure.
- The `{haskell}(>>=)` function injects a monad value into arbitrary function `{haskell}f` as a parameter, with the constraint that `{haskell}f` **returns** *a value in the same monad*
	- i.e. `{haskell}(>>=)` wangles the types so functions can take monadic values as parameters.

## Maybe Monad
We will motivate these (somewhat abstract) concepts with the now-familiar `{haskell}Maybe` datatype, which is **monadic**.

Consider a function `{haskell}allButLast :: [Char] -> Maybe [Char]`.
- it *returns the first (n-1) chars of a string* with (n) characters, wrapped up as a `{haskell}Just` value.
- If the **input string is empty**, then the function evaluates to `{haskell}Nothing`.

```haskell
allButLast [] = Nothing
allButLast [x] = Just []
allButLast (x:xs) =
  let rest = allButLast xs
  in case rest of
    Nothing -> Just [x]
    (Just xs') -> Just (x:xs') 
```

what happens when we repeatedly apply this function to a string input value?
eventually we will run out of characters, so we will bottom out at the `{haskell}Nothing` value
- `{haskell}take 10 $ iterate (\x -> x >>= allButLast) (Just "abcdef")`

what happens when we try to *bind* a function with a `{haskell}Nothing` value?
- The result (thanks to the definition of `{haskell}(>>=)`) is always `Nothing`.
## Identity Monad
Next we will look at the `{haskell}Identity` monad, which might seem a little pointless but it's a useful base case.

We need to `{haskell}import Control.Monad.Identity`, which might require some library configuration in ghci ... perhaps `{haskell}:set -package mtl` on the interactive prompt.

We can put something into the `{haskell}Identity` monad with the `{haskell}return` function
- `{haskell}(return 42) :: Identity Int`

and we can apply a function to `{haskell}Identity` monadic values with `{haskell}(>>=)`:
- `{haskell}((return 42) :: Identity Int) >>= (\x -> return (x+1))`

We can extract a value out of an `{haskell}Identity` computation by *running* the monad using the `{haskell}runIdentity :: Identity a -> a` function.
- `{haskell}runIdentity $ ((return 42) :: Identity Int) >>= (\x -> return (x+1))`

the equivalent case of *running* the IO monad is the invocation of the `{haskell}main` function at top-level in Haskell.
## List monad
We can think of using a monad as being like putting a value into a structure,  *elevating* or *lifting* the value into the monad.

What structures do we already know in Haskell?
Well, the list is probably the simplest ... and guess what? Yes, list is a monad.

List `{haskell}return` simply puts value into a singleton list
(i.e. syntactically, just put square brackets around it).
```haskell
listreturn :: a -> [a]
listreturn x = [x]
```

List **bind**
1. takes each element out of the list,
2. applies a function to that element, giving a list result,
3. then concatenates all the results into a single, new results list.

The **key point** (which confuses some people) is that *all the results are glued together into a **single** list*, rather than being separate sublists ... as they might be with a `{haskell}map` function call.
```haskell
listbind :: [a] -> (a->[b]) -> [b]
listbind xs f = concat $ map f xs
```

Here is a simple example of list bind:
```haskell
ghci> let f x = [x,x]
ghci> f 2
[2,2]
ghci> [1,2,3] >>= f
[1,1,2,2,3,3]
```

Here is another example:
```haskell
ghci> let f = \x -> (show x) ++ " mississippi... "
ghci> [1,2,3] >>= f
"1 mississippi... 2 mississippi... 3 mississippi... "
```

So we see that list bind is reminiscent of a `{haskell}join` in Python, or a `{haskell}flatMap` in Java/Scala.
## Reader, Writer and State Monads
So far we have looked at fairly straightforward monads, many of which you have seen before.

We are going to look at three useful library Monads.
For each one, we will look at their API and a typical use case.
These examples *might* be helpful for your coursework, coming up in a few weeks.

These three monads involve an *environment*, which we pass around, threading it from function context to function context.

Typical use cases for each monad are as follows:
* `{haskell}Reader` - shared environmental configuration
* `{haskell}Writer` - logging operations
* `{haskell}State` - computing a large value recursively
### Reader

The `{haskell}Reader` monad is also known as the *environment* monad.
It's useful for reading fixed values from a shared state environment,
and for passing this shared state between multiple function calls in a sequence.

Here is a trivial example:
```haskell
import Control.Monad.Reader
--  ^^^ may need some GHCi hackery ...

hi = do
  name <- ask
  return ("hello " ++ name)

bye = do
  name <- ask
  return ("goodbye " ++ name)

conversation = do
  start <- hi
  end <- bye
  return (start ++ " ... " ++ end)

main = do
  putStrLn $ runReader conversation "jeremy"

```
The Reader structure has two parameters:
- the environment (here a string)
- the result of the computation.

So the Reader datatype is parameterized on two type variables:
`{haskell}Reader environment result`

The `{haskell}runReader :: Reader r a -> r -> a` function takes
- a *Reader expression* to execute
- an *initial environment*
it runs the computation, and extracts the final value from it.
### Writer
The `{haskell}Writer` monad builds up a growing sequence of state
- (think about logging a sequence of operations).

Officially, this state is a *monoid*, but we will only consider `{haskell}String` values for today.

The `{haskell}tell` function appends something to the log.
```haskell
import Control.Monad.Writer

addOne :: Int -> Writer String Int
addOne x = do
  tell ("incremented " ++ (show x) ++ ",")
  return (x+1)

double :: Int -> Writer String Int
double x = do
  tell ("doubled " ++ (show x) ++ ",")
  return (x*2)

compute =
  tell ("starting with 0,") >> addOne 0 >>= double >>= double >>= addOne

main = do
  print $ runWriter (compute)

```
### State

Finally, the `{haskell}State` monad.
This is very similar to the `{haskell}Reader` and `{haskell}Writer` monads, in that it allows us to pass around a shared state, but also to update it.

We can `{haskell}get` the current state, or `{haskell}put` a new value into the state.

Let's do this with the fibonacci function ...
```haskell
import Control.Monad.State

fibState :: State (Integer, Integer, Integer) Integer
fibState = do
  (x1,x2,n) <- get
  if n == 0
  then return x1
  else do
    put (x2, x1 + x2, n - 1)
    fibState

main = do
  print $ runState fibState (0,1,100)
```