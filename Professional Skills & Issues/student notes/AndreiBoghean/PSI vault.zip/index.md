![[lecture 3]]

![[lecture 5]]

![[lecture 6]]

![[lecture 7]]

![[lecture 8]]

![[lecture 9]]

![[lecture 10]]