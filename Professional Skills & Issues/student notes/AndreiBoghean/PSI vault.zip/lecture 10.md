# lecture 10 - IPR

**intellectual property rights** (*IPR*) are rights that give you a *legally protected* ability to control ownership.
- provides protection for **intangible** but *valuable* things
	   - writings, inventions, music, drawings, software.
	   - things that can be duplicated easily.
- protected by **copyright law** *and* **patent law**
- **allows** creators to *benefit* from their ideas but *avoid monopoly*

## copyright
enforces the need for permission to perform restricted acts
- **copying**
- **publishing**
- **adapting** (*includes translation* into other (computer) languages)

key statutes:
- *copyright, design patents act* 1988
- *the copyright (computer programs) regulations* 1992

###### what other works does copyright protect?
- *original works* (i.e. created by author)
	   - literary, dramatic, music, and artistic works.
	   - sound recordings, films, broadcasts
	   - typographical arrangements of published editions (layouts, fonts)
	   - software, software design materials, and databases.

is **not** meant to protect ideas themselves
- but includes detailed plot of story as well as words

*easy* to get *copyright*, but **hard** to get **patent**
- copyright is control without monopoly, patent is control WITH monopoly.

###### who owns the copyright?
copyright is granted by the creation of the work
- no special action is necessary.
- the copyright symbol merely asserts a claim, but is not necessary.

**ownership**
- usually goes to the *author* of the work
- a work *created during employment* is *owned by the employer*, not the author
	  - **unless agreed otherwise**

**duration**
- 70 years after *author's death* for *written* works
- 70 years after *creation/release* for *film/sound*
- varies for other types of work
- thanks disney


###### idea versus expression
copyright **doesnt** *protect* ideas, procedures, methods of operation, or mathematical concepts
- patents can do this, however.

copyright protects the ***expression***  of an idea
- something has to be *formulated and written down* or recorded

judges have spent long hours discerning between idea and expression,
- idea : an attractive spy saves the world
- expression: skyfall, spectre


###### CPDA sect 28 - 76 permitted acts
- **fair dealing**
	  - non-commercial research, review, or criticism
	  - photocopies of work for students
	  - studying a program to see what it does
- **time-shifting** \[private/domestic use\]
- taking **back-up copies** of *computer programs*
- decompiling parts of code if there's NO other way to obtain the information needed to interface with a program.
	  - mustnt be used to create a similar program

###### extracting ideas and principles
- it is NOT an infringement of copyright for a *lawful user* of a **copy of a computer program** to
	  - *observe, study, or test* the **functioning** of the program.
	  - determine the ideas and principles with underlie any element of the program
if they do so while performing any of the acts of *loading*, *displaying*, *running*, *transmitting*, or *storing* the program, which they are entitled to do.

## patents

###### what is a patent?
a **monopoly right to stop others** from making, using, or selling an invention.
- even if the others *independently arrive on the idea themeslves*.

lasts for up to **20 years**.
- passes into *public domain* afterwards.

the right can be **sold or licensed** to others
- i.e. the right can have *value* attributed.

*obtaining a patent* **requires** that the invention is *publicly disclosed*

###### patent law
**uk statutes**
- patents act 2004
- patents act 1977
- copyright, designs, and patents act 1988
- patents designs and marks act 1986

**regulations / statutory instruments**
- patents rules (various years)

significant case law interpreting laws.

###### what sort of inventions apply?
- *products* or *processes* with **new** *functional* or *technical* aspects
	  - patents describe how things work, what they do, how they do it, what they are made of, or how they are made.
- invention must be **new/trivial**
- must involve an *inventive* step
- must be *capable* of **industrial application**
- must not be *excluded* (editor's note: ?)


###### UK patent exclusions
patents **cant** apply to
- a *discovery*, *scientific theory*, or *mathematical method*
- a literary, dramatic, musical, artistic, work or any other **aesthetic creation** whatsoever
- a scheme, rule, or method for performing a mental act, playing a game, or doing business
	  - this extends to ==computer programs==
- the *presentation* of information

these exclusions apply both in UK law (patents act 1977) and in EU law (EU patent convention article 52)
these exclusions prevent these things from being treated as an invention **only to the extent that** a patent *relates to that thing as such*
	- editor's note: i.e. if you can pretend it's something else, you can trick it?

## law of confidence
a *civil* **tort** based on *common law*, (statute law).
- imposes a **duty of confidentiality**

can be used to protect new ideas before
- a contract is written
- they are expressed in copyrightable form
- a patent is granted

only applies to *confidential information*
- if information is published legitimately, the duty of confidentiality disappears.

### what does confidentiality protect?
any information that is **not**
- *trivial* or *gossip*
- *easily available* by other means

needs to be completely secret
- *others can still know*, but with the **understanding that it is confidential**.

**wider scope than patent or copyright**
- covers *trade secrets*, *client lists*, *personal information*, *algorithms*, *intentions*, and *plans*.

### breach of confidence
information **necessarily** has the quality of *confidence*.
- i.e. the ***information is worth keeping secret***

information was *shared in circumstances* giving an **obligation of confidence**
- **specific conditions** are *stated* (sometimes in a contract)
- confidence must be obvious to a ==reasonable person==

there must be an *unauthorised use* or *disclosure* of the information with *a risk of damage* to the **originator of the information**.

see: coco v an clark \[engineers\] ltd (1969)

## public interest defence
is where *disclosure is of significant benefit to society*
- does **not pertain to what the public is interested in**, but rather what is *objectively significantly beneficial to the public*
- extremely rare.

**public interest disclosure act** 1998
- protects *workers revealing information*
	   - about past, present, or future ***malpractice in workplace***
	   - of the right type (a "**qualifying disclosure**") (**excluding** *official secrets* or *disclosure to a lawyer*)
	   - to the *right person* in the *right way* ("**protected disclosure**")

## employees & confidentiality
an **employee cannot disclose** employer's confidential information
- has **obligations** of *confidence* and *good faith*

after leaving employment..
- can **disclose** and **use** the *general skill and knowledge* they've **acquired**.
- **cannot disclose** *highly confidential* information learnt while employed.

contract of employment
- can *enforce confidentiality* **during employment**
- can prevent an ex-employee **soliciting customers** and *working in a competing business*
	  - USA non-compete clause moment.
	  - may be subject to reasonableness; courts can strike out

###### faccenda chicken v fowler \[1985\]
**identifying trade secrets**
- has the information been given to only a *limited number of employees*
- has the *employer impressed* on the employee the **confidentiality of the information**
- can the *confidential information be easily separated* from **other information acquired** by the employee *during the course of employment*

ex-employees have fewer constraints than employees.

without **express terms**, *implied terms* **cover only** *highly confidential* information such as trade secrets

**express terms** would only be enforced if *reasonably needed to protect trade secrets* or to **prevent customers being enticed away** by *abuse of personal influence*
- an employee must not deliberately copy a list of his employers; customers for use when he left

**judgement**
- ex-employee could set up a rival chicken delivery business; knowledge of customer & price lists dit not breach confidentiality.

###### does confidentiality benefit society?
what are the advantages?
- prevent ideas from being stolen, and *protects them before other protections*.
- **balanced protection** for employees/employers

what are the disadvantages?
- unethical decisions may be hidden
	  - (but protection with the public interest disclosure act 1998)
- no time limit, so society cant benefit from improvements
	  - can compare with copyright/patent

on (financial?) balance: confidentiality is useful.

## software licenses

different types of software license:
- **proprietary licenses** - *source code* considered a *trade secret* and **IPR** held by *publisher*
- **FOSS** (also public domain) - **free** to *use, change, copy, study*.
- **permissive licenses** - FOSS with *minimal restrictions*, usually related to *modification/distribution*
- copyleft - FOSS *allowing derivative work* but **require** it to be *also FOSS*