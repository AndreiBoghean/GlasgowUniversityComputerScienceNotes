# lecture 3 crime & cybersecurity

## essential elements of a crime
2 core components needed to convict of a crime:
1. an illegal action or omission (**Actus Reus**)
   \- excludes thoughts, but not words (e.g. perjury)
2. intention (**Mens Rea**)
  \- voluntary or deliberate act

some offences have **strict liability**, i.e. they *dont have to prove intention*
- simply performing the act is to offend.
- often utilised in regulations
- can be convicted without criminal intention or even criminal negligence

## cyber-dependent crimes
cyber crimes broadly fall into *2 categories*:
1. **illicit access** into computer *networks or data* (hacking)
2. **disruption** of computer network & functionality ((D)DOS attacks)
### common contexts for cyber crimes:
- highly skilled entities who aim to *commit crimes*
- highly skilled entities who want to protest (*hacktivism*)
- lowly skilled entities using cyber tools developed by others (*script kiddies*)
- *organised criminal groups*
- *cyber-terrorists* intending to cause maximum disruption and impact.
- *states* and state-sponsored groups launching *international cyber attacks*
- *insiders* or employees with *privileged access* to computers and networks

### computer misuse act 1990
the act is comprised of 3 sections, where the 3rd section is itself split into 3.
1. *unauthorised access* to computer material
   - to persecute, actor must *understand they're crossing a line*, and there must be **Mens Rea**
2. *unauthorised access* **with intent** to *commit further offences*
   - as section 1, but extended with *intention to commit a further serious offence* (e.g. blackmail)
3. *unauthorised acts* with **intent to impair**, or *recklessness* leading to computer **impairment**
   - impair operation of any computer, prevent or hinder access to program or data (e.g. (D)DOS attack)
   - impair operation of program or reliability of data

**penalties**:
- fine
- up to 2 years (s1)
- 5 years (s2&s3A)
- 10 years (s3)
- life in prison (s3ZA)

#### **s3A** *CMA* - making, supplying, or obtaining articles for use in offence under section 1, 3, or 3ZA
it's an **offence** to *make, possess, or supply* articles for computer misuse.
- but **prosecutors** need to be aware of the *legitimate* **pentesting industry** which generates "articles" for computer auditing and reliability testing
- imperative to prove *criminal intent* (**Mens Rea**)

- was the article **developed** primarily and *deliberately for wrongdoing*?
- is it *available* on a **wide scale commercial basis** and *sold legitimately*?
- is it *widely used* for **legitimate** purposes?
- does it have a *substantial* **installation base**?
- what was the context in which the article was used, compared to the original purpose?
##### case example R v Paul McLoughlin
- McLoughlin, a student, wanted free gaming. he obfuscated Istealer (password-stealer), inside several menial software programs to be downloaded, which relayed logins back to McLoughlin.
- a US resident **complained** to the Uni that *passwords to their online accs were compromised*
- police, working with McAfree and the uni, *identified encrypted details of FPT server embedded in the malware*, which **incriminated McLoughlin**.
- he was charged with making, supplying, or obtaining articles for use in offence
  - under section 1 or 3. given 8 months suspended for 12 months.
  - first conviction for s3A offence
#### **S3ZA** unauthorised acts causing or creating risk of *serious damage*
specifically - **serious damage** to *human welfare*, *environment*, *economy*, or *national security*.

- designed to cater for computer misuse, where the **impact is to cause damage** to (e.g.) *critical national infrastructure* where a *higher penalty should be given*.
  - "*critical national infrastructure*" could be taken as an **asset or system** which is **essential** for the *maintenance* of **vital societal functions**, health, safety, security, economic, or social well-being of people
    e.g. power plants, transport networks, or government networks, and the disruption or destruction of which would have a significant impact.

#### CMA prosecution **factors**
- does the institution, company, or other body have in place robust and up to date contracts, terms, and conditions or acceptable use policies?
- are employees, students, customers, and others made aware of the CMA and what is lawful and unlawful?
- do employees, students, customers, or others have to sign a declaration that they do not intend to contravene the CMA?

## data protection act 2018 (DPA)
DPA 2018 creates a number of offences in relation to the control and access to data
1. **section 144** - it's an offence for a person to *intentionally* or *recklessly* make a *false statement* in **response to an information notice**.
2. **section 170** - it's an offence to
   - *obtain or disclose personal data* **without the consent** of the ==data controller==
   - *intercept* the **disclosure** of personal data to another person *without the consent* of the controller
   - *after obtaining personal data*, **retain it without the consent** of the previous controller of the personal data when it was obtained.
###### case example:
**kim boyle** working for RAC prosecuted under CMA for accessing & passing on personal data about individuals who had accidents

## ethics of hacking
- hacking is "*conducting technical activities with the intent of exploiting vulnerabilities within a computer system, network, or firewall to obtain unauthorised access*"
- **black-hat hackers** - unauthorised, malicious hackers for personal gain
- **grey-hat hackers** - **exploit** security vulnerabilities to *spread public awareness of the vulnerability*
- **white-hat hackers** authorised, ethical hackers. *generally hired to test systems* for weaknesses. they have a **code of ethics** *prohibiting* them from **sharing their breaching methods** with *anyone unrelated* to the org's security team or related.

## DPA/UK GDPR & cybersecurity
- the **DPA/UK GDPR** requires that *personal data* must be **processed securely** using *appropriate technical and organisational measures*.
- **doesnt mandate specific cyber security techniques**, but *expects due diligence*
- effectively means *identifying and managing risk*. what ur org needs to do **depends on circumstances**, as well as **the data being processed** an therefore *the risks posed*.

### cybersecurity accountability
- DPA & GDPR focus on *explicit accountability* for data protection, **directly holding companies accountable** for the *security of their customers* and *complying with the principles of the regulation*.
- companies must **commit to mandatory activities** e.g. *staff training*, *internal data audits*, *maintaining detailed documentation*, if they dont want to break DPA & GDPR

#### IMPORTANT PART HERE
personal data breaches **must** be *reported* to the ==information commissioner's office== **without undue delay** (if it meets the *threshold* for reporting) and *within* **72 hours**.

## national cyber security centre
- basically a cyber security advisory thingy
launched in 2016, NCSC proides a service for public and private sector orgs in relation to cyber sec.
- it's a knowledge hub providing *practical guidance to the public*
- **responds to cyber security incidents** and works with organisations and the government to *reduce harm caused*
- uses industry and academic expertise to improve the UK's cyber security capability
- reduces risks to the UK by securing public and private sector networks