# lecture 5 values & virtue
## what are ethics?
ethics is concerned with *what is good* for **individuals and society**
- *moral decisions* - what is good and bad?
- our **responsibilities** and **rights**
- how to live a good life
- a *branch* of moral *philosophy*

**ethical behaviour** is *not* necessarily **dictated** by the *law*, the *majority*, or the *authority*.

## how do we make ethical decisions?
are ethics based on eternal truths or human convention?
- moral **realism** states moral principles have an *objective* foundation, and are not based on *subjective* human convention
- moral **subjectivism** states moral judgements reflect personal preference or opinion
- moral **relativism** states moral standards are *grounded in social approval*. social approval evolves so moral would therefore vary not just **by entity** but **over time** as well
	  - *individually* (individuals make their own decisions)
	  - *socially* (societies make their own decisions)


## ethical approaches
### consequentialism
of *all the things a person might do* at any time, the **morally right** action is the one with the ***best overall consequences***
- whether an act is right or wrong depends only on *the results of that act*
- the *more* "**good**" consequences an act produces, the better or *more* morally right that act.

when faced with a moral dilemma, consequentialism states:
- a person should choose the action that *maximises good consequences*
this generalises into the following live advice:
- people should **live** so as to *maximise good consequences*

#### consequentialism types
**utilitarianism** - people should maximise human *welfare* or *well-being* (known as "utility")
	- cite: Bentham & John Stuart Mill
**ethical altruism** - people should maximise the *welfare* of **others**
**hedonsim** - an early form that prioritises maximising *pleasure/contentment*
	^ editor's note: utilitarianism is arguably an extension of hedonism, because wellfare/well-being are closely tied to pleasure/contentment.

note: the differnt "types" are kinda like different loss functions.
and act/rule consequentialism determines what data you use to calculate the loss.

#### consequentialism is foolish
it's difficult to assess the ethical consequences of every single act
- life is a game of hearthstone, and your default policy is dumb

i.e. *humans arent omniscient, so you need some other way to ascertain whether an act is bad*.
##### act consequentialism

*pure* consequentialism is known as "*act*" consequentialism, and produces this conclusion:
- no type of act is **inherently** wrong, not even murder.
##### rule consequentialism
we can *infer* **ethical rules** by *considering the general consequences* of **acts** we've *already observed*.
- we saw someone die, noticed their doughnut shop is now closed, so we understand their death was bad.
- more realistically - murder is wrong because it deprives individuals of their life and produces other bad consequences.
	  ^ editor's note: why is depriving someone of life neccessarily bad?

hence, **rule consequentialism forbids murder** *not explicitly*, but **learns** that it is bad *from previous scenarios*.

these leanings form "**moral rules**" that are chosen solely on the *basis of their consequences*.
- specifically, they take the form that produces the best results if adopted by *most* people
- i.e. moral rules are an **abstract** *generalisation* of **learned outcomes** for the *general populus*
	  - also see: religion.

### duty-based ethics - deontology

deontological ethics are concerned with what people do, **not** with the *consequences* of their actions.
- do the right thing
- do it because it's the right thing
- dont do wrong things
- avoid wrong things because they are wrong.

deontology **removes the fault** of choosing the ***wrong*** *ethical rules* to apply, and considers plainly the intention. it's a "simpler" (dumber?) ethical approach.
- it places the most emphasis on being a human that has the "right" loss function.

*demonstrating* that an action produces *good consequences* **means nothing** in deontology
- because it is a *non-consequentialist* **approach**
some types of actions are inherently right/wrong, regardless of consequences.

sidenote: "deontological" from greek "deon" meaning duty

#### moral rules of deontologists
deontologists live in a universe of moral rules such as
- it is wrong to kill people
- it is wrong to steal
- it is wrong to tell lies
- it is right to keep promises
^ note: rules can b more complex.

someone following *duty-based* ethics should *do the right thing*, **even if it produces more harm**.
- this stems from the belief that people have a *duty* to **do the right thing**

#### kant's categorical imperative
a categorical imperative is a rule that is true in all circumstances.
- a fundamental truth.

these form the **basis** of all other rules. they are the *fundamental building blocks* of rules.

2 ways to express a categorical imperative:
1. always act in such a way that **you would be willing** for it to become a *general law* that *everyone else should do the same* in the same situation
2. act so that you treat humanity, both yourself and others, *always as an end* and **never** as a *means to an end*.

### virtue ethics
states that a **right act** is the *action* a **virtuous** person would do in the *same circumstances*.
- person-based rather than action-based.
- focusing more on moral character.
- virtue is an excellent character trait that is **whole-heartedly understood** by *those possessing it*.
- *virtue is acquired* **through practice**. by honing virtuous habits, people will subsequently make *better choices* **next time** they face ethical challenges.

basically, virtues are abstract definitions that you learn through experience.
editor's notes:
	- virtues are much like rule consequentialism, except that the rules are learned by the person rather than explicitly defined and passed down.

#### example virtues

**justice**
- requires us to treat human beings equally and impartially
**fidelity**
- fidelity requires that we treat people close to us with special care
**self-care**
- we have a unique responsibility to care for ourselves mentally, physically, & spiritually
**prudence**
- the prudent person does all the above and looks for opportunities to acquire more virtue in them.

### relativism
moral relativism states that there are no **objective** moral truths out there.
- there are no objective moral facts. therefore "killing people is wrong" cant be objectively true.
- many forms of relativism go further and say that moral statements *describe how the* **speaker** *feels* about a particular ethical issue.
	  - "lying is wrong" only tells you that I disapprove of telling lies.

#### different relativist positions
there are many.
**descriptive** positions describe different *perspectives*
- some can *describe* **cultures**, partially accounting for how moral stances vary over time.
- some can *describe* **individuals**, accounting for people's different moral views *according to beliefs*

**normative** *moral relativists*
- state that morality has no objective factual basis, therefore it is not possible to say that one moral stance is "right"m and another is "wrong"


## ethics and values

**ethics**
- looks at **moral** *principles* and *guidelines* that help people think about what is right and wrong. ethics seeks to answer questions about how one **should** *act/decide/interact*.
**values**
- reflect beliefs about what **individuals** consider important/desirable/meaningful.
- values serve as **motivators** that influence *attitudes/behavours/choices*.

i.e. values dictate that a person wants to do, and ethics dictate what they can do.

### scwartz on values
schwartz, a psychologist, developed a *theory of values* based on *many* **empirical studies** across **different cultures** over years

they found 10 basic human values which form a circular continuum, *defined* **according to** the *motivation* that underlies each of them.
- the values refer to desirable goals that motivate action
- values guide the selection of actions/policies/people/events
- the *relative importance* of **multiple values** *guides* action.

#### scwartz's 10 basic values

| Value        | Defining goal                                                                                                            |
| ------------ | ------------------------------------------------------------------------------------------------------------------------ |
| self-direct  | independent though and action, expressed in choosing, creating and exploring                                             |
| stiulation   | excitement, novelty, and challenge in life                                                                               |
| hedonism     | pleasure or sensuous gratification for oneself                                                                           |
| achievement  | personal success through demonstrating competence according to social standards                                          |
| power        | control or dominance over people and resources                                                                           |
| security     | safety, harmony, and stability of society, of relationships, and of self                                                 |
| conformity   | restraint of actions, inclinations, and impulses likely to upset or harm others and violate social expectations or norms |
| tradition    | respect, commitment, and acceptance of the customs and ideas that one's culture or religion provides                     |
| benevolence  | preserving and enhancing the welfare of those with whom one is in request personal contact (the 'in-group')              |
| universalism | understanding, appreciation, tolerance, and protection for the welfare of all people and for nature                      |
````col
```col-md
![[Pasted image 20241207174045.png]]
```
```col-md
![[Pasted image 20241207174055.png]]
```
````