# lecture 6 - risk & responsibility

## legislating for online experience
the *rise* of **harmful and illegal** content *online* had led to concern.

through social media, users now interact with each other more and are more open to harmful encounters purely as a result of statistics
- trolling, abuse, exposure to offensive / illegal material.
leads to **concerns** for *children and young people* also **being exposed** to such harm.

some believe the *internet should be regulated* because of this,
some do not and cite **free speech** as an important tenet that **should be protected**.

### online safety act 2023
- aims to protect children and adults online
- outlines a set of **duties** for *social media companies* and search services, **making them responsible** for their *users' safety* on their platforms
- gives providers **duties** to implement systems and processes to **reduce risks** that their *services get used for illegal activity*. also requires they moderate and *take down illegal content*
- most restrictive portions focus on children.
  platforms *required* to *prevent* *children* from *accessing* **harmful age-inappropriate content**
  platforms required to provide parents with ***clear*** and ***accessible*** ways to *report problems*.
- also protects adults, requiring major platforms to be **transparent** about which kinds of **potentially harmful content they allow**, and *give people control* over the *types of content* they want to see.

### OSA 2023
#### criminal offences introduced
introduced criminal offences which cover:
- encouraging or assisting serious self-harm
- sending false information intended to cause non-trivial harm
- threatening communications
- intimate image abuse
- epilepsy trolling
the criminal offence introduced by the act came into effect on 31st january 2024.

#### protections introduced
OSA 2023 requires online services to:
- take robust action against illegal content and activity
	  - e.g. child sexual abuse, controlling or coercive behaviour, extreme sexual violence, fraud, racially or religiously aggravated public order offences
- take robust action against content that is harmful to children
	  - e.g. pornography, content that promotes self harm, eating disorders, suicide
- enforce age limits consistently and protect child users
- offer adult users tools to regulate what they see themselves.
- rapidly remove suicide and self-harm content

#### motivation / inspiration

- molly russell, 14, took her own life in november 2017 after viewing extensive content, particularly on instangram+pinterest, related to suicide, depression, self-harm, and anxiety
- the inquest concluded that social media contributed to her death, stating that she "died from an act of self-harm while suffering form depression and then egative affects of online content"
- inquest comments fed into decisions about OSA provisions

#### OSA regulator
**OFCOM** is the independent regulator for the OSA.
- it sets out *steps* providers can take to **fulfil** their **safety duties** in codes of *practice and advice*.
- yields a **broad range of powers** to *assess* and *enforce* providers' *compliance* with the framework, from running **audits** to **fining** companies.
- providers's *safety duties* are **proportionate** to **factors** including the *risk of harm* to individuals, and the *size and capacity of each provider*.
	  - ensures that, while **safety measures need to be put in place** across the board, *smaller services* that *dont have the "scale"* to **observe the small statistic** of wrongdoers, *arent required to look out for them* **as much** (since they're unlikely to appear)
- **ofcom** is *required to take users' rights into account* when **outlining steps** for providers.
  providers also have duties to *take regard of users' rights* when **fulfilling their safety duty**.

#### curret codes of practice for OSA
companies need to work with ofcom to comply.
providers of online user-to-user services are asked to
- take **proportional steps** to *prevent users encountering illegal content*
	  - i.e. perpetrating fraud, sharing child sexual abuse material
- **manage** the *risk of offences* taking place through the service
- be able to do **age verification** *if necessary*
- undertake a **risk assessment** and *manage risks identified*
- **remove illegal content** *when aware* of it
- **protect children** from *harmful content*

#### benefits of the OSA
**child protection** - enforces *age checking* to prevent children from accessing age-inappropriate content on social media platforms.
**content removal** - requires tech companies to *promptly* remove illegal content like child sexual abuse material, gate speech, and content promoting self-harm.
**user control** - allows user to *filter out unwanted content*, like online abuse, and customise their online experience
**transparency and risk assessment** - forces large platforms to *publish risk assessments* outlining potential dangers to users *particularly children*.
**accountability for platforms** - holds tech companies responsible for *enforcing their own terms of service* and taking action against harmful content.
**improved reporting mechanisms** - provides *clear pathways* for users to *report* **harmful content** and *concerns*.
**enforcement by ofcom** - grants power to the communications regulator ofcom to *investigate and sanction companies* that fail to comply with online safety rules.

#### criticisms of the OSA
**over-reach on content moderation** - could force platforms to *remove too much content*, potentially *impacting legitimate discussions and viewpoints* due to a broad definition of "harmful content"
- ^ also equally the inverse of this, with under-moderation.
**privacy concerns** - requirements for platforms to *scan private messages* for detection of illegal content can prompt *fears of government survaillence*
**free speech implications** - could *stifle free speech* by causing platforms to err on the side of caution and remove content that may be ***controversial but not necessarily illegal***
**enforcement challenges**- how effectively the act can be enforced, particularly with regards to *identifying and removing harmful content* across a ***wide range of platforms***
**potential for abuse** - could be used to *target specific groups or viewpoints*, leading to ***censorship***.
**lack of focus on system design** - some provisions in the act are vaguely defined, which may lead to *inconsistent application and interpretation*

### human rights

#### freedom of expression
FoE is protected by article 10 of the UK human rights act of 1998
- "everyone has the right to freedom of expression... to hold opinions and to receive and inpart information and ideas with interference by public authority..."

restrictions include
**protecting others** - rights and reputations of others or *preventing disorder* of crime
**preventing hate speech** - including *incitement to racial or religious hatred*, or terrorism
**protecting confidential information** - disclosure of information *received in confidence*
**maintaining judicial impartiality** - the *authority and impartiality* of the judiciary
**religious freedom** - can be limited to *protect the rights and freedoms of others*
**anti-protest legislation** - anti-protest legislation *had been passed*, but *it's legality is in question*

#### defamation
defamation is
- (a) - to *lower a person in the estimation of right-thinking members* of society generally
- (b) - to *expose a person to hatred*, ridicule, or contempt
- (c) - to *disparage a person in their office*, profession, calling, trade, or business

- protecting reputation is important because it's *a civil right of the same standing* as any other, e.g. right to enjoyment of life.
- hence it is covered by the defamation act of 2013.
- **defamation** is a *civil wrong*, or "tort". claims generally have to be issued in the high court, only sometimes in the county court.

##### libel and slander
in UK law, libel and slander are types of defamation which protect a person or organisation's reputation from false statements.
**libel** - defamatory statements that are *written or broadcast* e.g. in articles, blogs, social media, or other written content.
**slander** - defamatory statements that are *not published* but instead are *transient* e.e.g conversation, impressions, other not-stored transient media

##### what is defamatory
three tests to determine:
- the statement is potentially and *actually defamatory*.
- the statement is clearly *about the claimant*
- the statement was *published/communicated*

**serious harm** - claimants must prove that the publication of a statement caused or is likely to cause serious harm *to their reputation*.
- for companies **trading for profit**, the harm must also cause or be likely to cause *serious financial loss*.
- ***cant defame a government body***.

##### defence against defamation
**defences**: the act outlines defences for defamation
- **truth** - a statement *can be fully defended against* defamation if *it is substantially true*
- **honest opinion** - a statement can be defended if it is an opinion *based on accurate, referenced facts*.
- **public interest** - a statement can be protected if it's on *a matter of public interest* and the defended *reasonably believed publication was necessary*
- **operators of websites** - if *complied with procedures* and remove posts when a complaint is received.
- **peer-reviewed statements in academic papers**
- **reports protected by privilege**  - i.e. court reports