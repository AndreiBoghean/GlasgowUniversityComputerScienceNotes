# lecture 7 - professionalism in practice

computing is not strictly a "profession" such as medicine/law/engineering,
but it still has professional societies (BCS, ACM, IEEE) that try to encourage professionalism in practice.
this is because computing is a powerful tool that needs to be developed with care.

## defining professionalism

professionals require *mastery* of a body of knowledge
- usually through higher education.
professionals often have some amount of *autonomy* in their work
professionals usually have a *professional organisation*
- often acknowledged by government that *controls admission* and sets *guidelines for practice*
professionals fulfil an important *social function*
- i.e. doctors, lawyers

## are computer professionals professional?
need to posses:
- **mastery** of a body of knowledge (maybe higher education)
- a **degree of autonomy**
  - possible if self-employed, but some *merely implement the designs of others*.

and while there exists professional computing bodies, **there is no** "*legal body in charge of admissions or standards*"

computing is crucial to society, but **is not considered a "good" in and of itself** like health and justice are considered.
it supports activities in society, but the particular activities supported are *very varied*.

## professionalism
it could be argued that professionals function in a special context (Johnsson 1985)
- typically includes *relationships* with **employers**, **clients**, **colleague** **professionals**, and the **public**.
- *operate under legal, political, and economic constraints*
- have skills enabling them to affect the world.
	   - usually use their skills to produce products or provide services that are *widely used*, usually involving *cooperation with others*.
	   - by extension bear a responsibility to *not harm individuals or the public*

## what's the purpose of a code?

a professional code of ethics serves several functions:
- **symbolises** the *professionalism* of the group
- **defines** and **promotes** a *standard for external relations* with clients and employers
- **protects** the group's *interests*
- **codifies** members' *rights*
- **expresses** *ideals* to aspire to
- **offers guidelines** in "*gray areas*"

### examples of codes of ethics

- british computer society code of ethics & conduct
- ACM code of ethics and professional conduct
- IEEE ethics and member conduct

#### BCS code of conduct

- applies to all members of BCS
- covers 4 main areas:
	  - the *public interest*
	  - professional *competence and integrity*
	  - duty to *relevant authority*
	  - duty to the *profession*

##### BCS 1 - public interest
- have **regard** for *public health*, *privacy*, *security*, and *wellbeing* of **others** and the **environment**.
- have **regard** for the *legitimate interests* of third parties
- **dont discriminate** against others in any of your dealings
- **promote equal access** to IT and *generally support inclusion*

##### BCS 2 -  professional competence & integrity
- only undertake work **within your competence**
- *dont claim level of competence you do not possess*
- keep professional **knowledge up-to-date**
- know *relevant legislation*
- respect the **viewpoints of others**
- avoid *injuring others, property, reputation, employment*
- *reject bribery*

##### BCS 3 - duty to relevant authority
- carry out work with *due care* and *diligence*
- **avoid situations** which may result in a *conflict of interest* between you and your relevant authority (company, client, etc.)
- *accept professional responsibility* for **your work** and the work of colleagues that **you supervise**
- dont **disclose** or **use for personal gain** *confidential information relating to your work*, **except** with **permission** or if **legally required**
- dont *misrepresent* or *withhold information* about the **performance** of products

##### BCS 4 - duty to the profession
- accept **personal duty** to *uphold reputation* of the **profession**
- **improve** *professional standards* by **taking part** in their *development, use, and enforcement*
- **uphold** the *reputation* of the **BCS**
- **act** with *integrity and respect* in your relationships with others
- **encourage and support** members in *their professional development*

#### ACM
##### code of ethics
1. *contribute to society and to human well-being*, **acknowledging** that ==all people are stakeholders in computing==
2. ***avoid harm***
3. be *honest* and **trustworthy**
4. be *fair* and take action **not to discriminate**
5. **respect** the *work required to produce new* ideas, inventions, creative works, and computing artifacts.
6. **respect** *privacy*
7. **honour** *confidentiality*

##### professional responsibilities
- **strive** to *achieve high quality work*
- **maintain** *high standards* of **competence, conduct, and ethics**.
- *know and respect rules* (laws + policies) pertaining to your work
- *accept* and **provide** appropriate *professional review*
- give **comprehensive** *evaluations* of computer systems ***including risks***
- only perform work in **areas of competence**
- **foster** *public awareness* and *understanding* of computing
- *only access* computing resources **when authorised**
- **design and implement** systems *that are secure*

##### professional leadership principles
- **ensure** the *public good* is the **central concern**
- *encourage* the **fulfilment** of *social responsibilities* by all colleagues
- ***manage people and resources to enhance quality of working life***
- **support policies** that *reflect* this code of conduct
- **create opportunities** for others to *grow as professionals*
- **use care** when *modifying* or *retiring* **systems**
- **recognise and take care** with *systems* that are ***integrated into the infrastructure of society***

### characteristics of codes

- they are **not** *simple ethical algorithms* that generate ethical decisions
- sometimes *elements of the code* may be in **tension with each other** or *other sources*.
	  - requires the IT professional to use ***ethical judgement*** to act in the ***spirit*** of the code of ethics
- a **good** code of ethics/conduct will *outline* ***fundamental principles*** that require **thought**, rather than *blind allegiance*.

### problems with codes
- they **dont cover every case** (nor should they)
- can a list of rules define a behaviour that everyone considers right?
- *little penalty* for non-compliance
- realistically, *compliance* requires a **personal** code of ethics that is *broadly in line* with the **professional** code

### how do you apply codes?
- **consider** the *ethical dilemma* you are facing
- **decide** ***which*** *principles* and *rules* are at stake
- **decide** if there are *any conflicts* between principles in this case
- make a **decision** based on *prioritisation* of principles

## equality, diversity, and inclusion
- related to professionalism, and relevant for the IT workplace AND IT systems that we develop as software engineers
- compelling *reasons for considering this* in SE development
	   - **legal** issues i.e. not to discriminate ... equality act 2010
	   - **professional** issues ... it's mentioned in the codes of conduct
	   - **ethical** issues ... fairness and justice
	   - **social** issues ... ensuring that IT systems represent and can be useful to the whole of society

equality act 2010 - 9 *protected characteristics*
- age, disability, gender reassignment, marriage or civil partnership, pregnancy and maternity, race, religion or belief, sex, sexual orientation