# lecture 8 - data & decisions

## history of data protection law
- 1984: the **data protection act** (*DPA*) first passed to protect *personal data* (*PD*) in paper-based filing systems and on computers
- 1998: *DPA* was updated in 1998 in response to new EU law and advances in tech. more detailed, with *concerns on how PD was processed*.
- 2002: *DPA* was supplemented with EU *PECR*, which focused on *email marketing* and *website consent* for *cookies* - known as **cookie law**
- 2018: EU enacted **General Data Protection Regulation** (*GDPR*), with some sections *open to interpretation*.
- 2020: UK left EU, keeping GDPR with small changes under the title of *UK GDPR*.
  changes such as child consent of 13 (UK) v 16 (EU), change to how **PD about criminals** is handled, and how **PD** is used for *automated decision making*.

now, organisations have to comply with both *UK GDPR* and *DPA* if working in the UK,
and additionally *EU GDPR* if **processing EU PD**.

## UK data protection laws
**Data protection** (*DP*) legislation sets out rules for the **handling** ("*processing*") of **information** ("*personal data*") about **living identifiable individuals** ("*data subjects*") by **organisations** ("*data controllers*")

- *applies* to **organisations** in public and private sectors.
- *applies* to **electronic** and **most paper** records.
- *doesnt apply* to **anonymous information** or to information about the **deceased**.

note: since 1st january 2021, the principal legislation has been both:
1. the UK GDPR
2. the 2018 DPA (which supplements the UK GDPR)

## personal data (*PD*)
describes information that relates to an identified or identifiable living individual
- includes anything about a person : name, address, phone no., email address, bank acc no., NI no., student ID, library card, etc.
- if it can be used together with other data to identify a person, then it's considered PD.
	  - e.g. IP address, website username, wifif logs indicating physical presence, fingerprints, CCTV footage, GPS location, etc.

## identifying individuals
if it *apears* you cannot **directly identify** an individual from that information, then you **still need to scrutinise whether that is the case**.
- when considering whether information "relates to" an individual, you need to consider a range of factors including the content, purpose for processing, and the likely impact or effect of that processing on the individual.
this is because *information which had identifiers removed or replaced for pseudoanonimisation is still personal data for the purpose of GDPR*
- information must be **truly anonymous** *to be free of GDPR* regulation

if information *seems* to relate to a particular individual and is **inaccurate**, it's *still personal data* because *it relates to the individual* **to some degree still**.

## sensitive personal data
there exists *stronger protections* for **types** of data that *might be used to discriminate*.
- known as ***sensitive personal data*** or ***special category data***

to keep this data, you need *explicit permission* OR *a very good reason* (protecting public heath)
- **race**
- **ethnic background**
- **sexual orientation** & **sex life**
- **religious beliefs**
- **political opinions**
- **trade union membership**
- **health data med history**, *including data by fitness apps*
- **biometric data** if used for ID - face recognition, iris scans, retina scans, ears, etc.
- **genetic information**

## 7 data protection principles
1. *processed lawfully, fairly, and transparently*
   - only if "legal basis" i.e. consent, contract, legal obligation, vital interests (i.e. GP), public interest (only public orgs), legitimate reason
2. *processed only for specified, explicit and legitimate purposes*
   - **tell people what you will do**, even if sharing or selling data with others
3. *adequate, relevant, and limited to only what is necessary*
   - must store the minimum amount of data
4. *accurate and, where necessary, up-to-date*
5. *not kept longer than neessary*
   - **DC** must establish time limits for keeping **PD**
6. *Must be kept securely - preserving confidentiality, integrity, and availability*
   - means keeping PD **encrypted if stored**. employees also need to know this.
7. *data controllers must be accountable*
   - must **keep detailed records** as *evidence of policies being followed*, with **third parties also following these principles**.

there may be full/partial exemptions in specific contexts e.g. for academic research, policing, etc.

## data controllers 
the UK GDPR defines a data controller (DC) as:
- "*the natural or legal person, public authority, agency, or other body which, alone or jointly with others, determines the purposes and means of the processing of personal data*"

- data controllers make decisions about processing activities
- they control PD processing and are **responsible** for it.
- can be a company or other legal entity (i.e. public authority), or an individual (i.e. sole trade, or self-employed professional)
- ***individuals processing PD for household activity are NOT subject to DP law***

## data processors
the UK GDPR defines a data processor (DP) as:
- "*means a natural or legal person, public authority, agency, or other body which processes personal data on behalf of the controller*"

- **acts on behalf of a DC** and *under the DC's authority*.
  - they serve the controller's interests, **not their own**.
- may make **day-to-day** decisions, but *should only process PD in line with controller's instructions*
- **acting without DC's instructions** henceforth *makes them a controller* for that activity, and they *adopt the same liability as a DC*.

## information commissioner's office (ICO)
the ICO is the UK's independent regulator for data protection and freedom of information.
their role is to:
- **uphold** the *UK GDPR* and *DPA*
- **uphold** the *freedom of information act*
- **uphold** *information rights* of individuals and organisations
- **monitor** and *investigate* breaches
- take **enforcement** *action*
- **promote** *good practice*
- **support** *organisations*

## data access rights
the data owner has the rights:
- to be **informed** of how personal data is being used - "*privacy notices*"
- of **access** to their personal data - known as making a "*subject access request*"
- to **rectify** inaccurate personal data.
- to **erase** personal data where appropriate - the ***right to be forgotten***
- to **restrict processing** of personal data, pending it's verification or correction
- to **data portability** - the ability to recieve copies of their personal data in an open and machine-readable format.
	  - and *also within a timely format*. if data **cannot reasonably be gathered within this period**, the data owner must be informed and *kept in the loop* with when their data actually arrives to them.
- to **not be subjected to automated decision making** - profiling, direct marketing, for research (if not in public interest)
- to **object** to the way their personal data is being used.

response to a rights request normally *should be sent within one month*, but **nearly all rights are qualified in various ways** and *there are exemptions*


## privacy notices
- an important aspect of complying with data protection law legislation is being **open and transparent** with individuals about *how* their personal data will be **used**
- the **supply** of this information - through documents variously known as "*privacy notices*", "*data protection statements*", "*data collection notices*", "*privacy policies*" is **essential**
- these notices take place in **numerous targeted ways**, depending on the *context of the interaction* with the individual
- is the responsibility of the **data controller** to provide these notices

## subject data access requests
when exercising the right to access personal data,
- can ask in **writing** *or* in ... ?
- must be **provided in a month**, *free of charge*
- *easy* to **access** and **understand**
- if complex, can be **allowed up to 3 months** with a *small processing free*
	  - **request** must still be *acknowledged* within a month and *justify the delay*.

## data portability
individuals have rights:
- to **recieve a copy** of your personal data in a *structured*, **commonly-used** *computer-readable* format so *you can pass it on*.
- to ask a data controller to **transmit** your PD *directly to another data controller*
	  - means they must provide electronic data in an open format CSV, XML, JSON, etc.
	  - only **RAW PD** must be transmitted; *inferred data* such as your **personal preferences or dislikes** based on activities **does not need to be** passed.

## automated decision-making or profiling
automated decision making is increasingly common

you have the right **not to be subject** to *purely automated decisioning*
- automated decisioning **requires** *explicit consent* or **legal authorisation**.

if using sensitive data, explicit consent is **EXPLICITLY** required *unless for a public interest*.

is **good practice** for the DC to tell you *details of any profiling or automated decisioning* they do, *including where data comes from*.

the DC **MUST** *explain* how you can **access data used to create your profile**,
and *simple ways to request human intervention* or to **challenge an automated decision**.

## data security breaches & penalties
any DC who falls foul of DP rules is to be held accountable.
**breaches** leading to *disclosure*, *loss*, *destruction*, or *alteration* of PD that presents a serious risk to anyone's rights and freedoms...
- **must** be *reported to ICO* within 72 hours.
- **must** have all victims *notified as soon as possible*

consequences for non-compliance
1. warning, temporary or permanent ban on data processing
2. if very serious, fine up to *17.5M* or **4% of annual turnover** in UK.
	- e.g. 2019 british airways fined 183M after hackers gained access to customers' details, including bank details.