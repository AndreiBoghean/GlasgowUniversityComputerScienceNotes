# lecture 9 - society & surveillance


## universal declaration of human rights (*UDHR*)
the **united nations** (*UN*) were created in 1945 by representatives of 50 countries - a response to the end of WW2.

the *commission on human rights* was set up by the **UN** to draft the **universal declaration of human rights** (*UDHR*).
- comprised of 18 members from *various political, cultural, and religious backgrounds*.
	  (chaired by Eleanor Roosevelt, widow of american president franklin D. roosevelt)

the UHDR was...
- intended to be *a roadmap to guarantee the rights of every individual everywhere*
- adopted by the UN general assembly on the 10th of december 1948, with 8 nations abstaining but none dissenting.
it marked a historical turning point, as a text promoting peace and diplomacy.

it listed 30 basic human rights
````col
```col-md
1. have and respect human rights
2. life
3. freedom from torture
4. freedom from slavery
5. liberty and security
6. seen as a person
7. equality
8. remedy in law
9. freedom from arbitrary arrest
10. fair trial
```
```col-md
11. innocent until proven guilty
12. privacy & family life
13. freedom of movement
14. freedom from persection
15. a nationality
16. to marry
17. own property
18. freedom of thought, conscience, religion
19. freedom of opinion & expression
20. freedom of association
```
```col-md
21. take part in government and vote
22. human dignity
23. to work & receive fair pay
24. to rest & leisure
25. adequate standard of living
26. education
27. participate in cultural activities
28. to have rights realised internationally
29. duty to community
30. not to have any rights removed.
```
````

## european convention on human right: ECHR
- **protects the human rights** of people in *countries that belong to the council of europe*, including the UK.
- the **council of europe** was founded after WW2 to *protect human rights + the rule of law*, and to *promote democracy*.
- the convention was based on the **universal declaration of human rights**
- *judgements finding violations* are **binding on the states** concerned and they are *obliged to carry them out*
- post-brexit, some UK politicians want to leave the ECHR

## human rights act 1998
- the human rights act is a UK act which received royal assent in 1998 and came into force on the 2nd of october, 2000.
- it's aim is to **give further effect** in UK law to *the rights containted* in the *ECHR*
	  - specifically - it gives UK courts **a remedy** for *breach of a convention right*, **without the need** to go to the *european court of human rights* in strasbourg.
- some additions to UDHR are also made (which were already in ECHR)
	   - protocol 1, article 1 : right to peaceful enjoyment of your property
	   - protocol 1, article 3 : right to participate in free elections
	   - protocol 13, article 1 : abolition of the death penalty

## example ECHR vs UK cases
- **rights of journalists not to reveal their sources** (Goodwin v UK, 1996)
- police *cant keep innocent people's DNA* forever (S & Marper v UK, 2008)(*right to a private life*)
- **phone hacking is a crime** (Halford v UK, 1997)
	  - resulting in the regulation of *investigatory powers act* 2000 (*right to effective remedy*)
- **human trafficking and domestic slavery are illegal** (C.N. v UK, 2012)
	  - leading to the *modern slavery act* 2015 (*freedom from slavery*)

## surveillance technologies
- *closed circuit television systems* (CCTV)
- **automatic number plate recognition** (ANPR)
- *body worn video* (BWV)
- unmanned aerial vehicles (**UAVs**, a.k.a. drones)
- *facial recognition* technology (FRT) and *surveillance*
- commercial products such as **smart doorbells** and **surveillance in vehicles**
- *workplace monitoring*, **live streaming**, and ...
	   - other *commercially available surveillance systems* that have the potential to process personal data

## GDPR & DPA for surveillance systems
- DCs must implement appropriate **technical and organisational measures** & *identify lawful basis*
- if a surveillance system processes PD, it *must notify and pay a data protection fee* to ICO
  (**unless exempt**)
- must have appropriate *measures and records* in place to be able to ***demonstrate compliance***
- maintain a record of the processing activities (article 30) including **purpose**(s), *data sharing agreements*, **retention periods**.
- adopt *data protection by design and default*, and perform a **data protection impact assessment** (*DPIA*) for processing **likely to result in a high risk to individuals** e.g.
	  - processing special category data
	  - monitoring publicly accessible places on a large scale
	  - monitoring individuals at a workplace
- must assess whether *surveillance is appropriate*, considering the **reasonable expectations** of the individuals affected and the *potential impact* on their **rights and freedoms**.
- must **record considerations** in a *DPIA* prior to deployment. *if high risks cannot be mitigated*, **prior consultation with the ICO is required**.

### facial recognition technology (*FRT*)
- FRT identifies a person from a **digital facial image**, and analyses facial features to produce a *biometric template*.
- depending on the use, FRT involves processing *PD*, **biometric data**, and often *special personal data*
- under UK GDPR, processing biometric data to uniquely identify an individual is **prohibited** *unless* **there exists a lawful basis under article 6**
	   - *consent, contract, legal obligation, vital interests, public interest, legitimate reason*
- ^ AND ***a condition in article 9 can be satisfied*** (see below)

#### article 9 conditions for processing special personal data
1. explicit consent
2. employment, social security, and social protection law
3. vital interests
4. not-for-profit bodies
5. made public by the data subject
6. legal claims and judicial assets
7. substantial public interest conditions
8. health or social care
9. public health
10. archiving, research, and statistics.

#### FRT in public spaces
- FRT in *public spaces* is where data is scanned and checked against a "***watch list***". **if a match is found**, *human decision is usually required before action*.
- if a system is *completely automated*, **higher standards are demanded**
- if the company is **private**, *consent* and *opt-out* is **important**.
- to be accountable when using FRT, you must be able to explain
	  - the *lawful basis* you're relying on
	  - why **FRT is necessary** in the circumstances or in the public interest
	  - why *less intrusive options* are **ruled out**
	  - assessment of the likelihood that objectives of FRT will be met
	  - how *effectiveness* has been **measured**

#### FRT checklist
- Conducted a **Data Protection Impact Assessment** (*DPIA*) ==addressing need to FRT==, **lawful basis** for its use and *explores the impacts on the rights and freedoms* of individuals whose personal data are captured for every deployment
- ***Document our justification for FRT***, and the decision-making behind justifications
- A **sufficient volume** and *variety of training data* has been included to ***assist accurate performance***
- Chosen an *appropriate resolution* for the cameras we use and **tested equipment**
- Positioned cameras in areas with **sufficient lighting**, to *ensure good quality images* are taken
- Can *clearly identify false matches*, and *true matches*
- Can **record false positive** or **false negative rates** where appropriate.
- Can *amend to correct false positive or false negative rates* that are **too high**
- *any watchlists used* are **constructed in a way compliant** with data protection law
- *Considered* if **Equalities Impact Assessment** (*EIA*) **is required** to meet Equalities Act 2010
- Complied with the **Surveillance Camera code** of practice where required


#### surveillance case examples
##### surveilance case example 1
both fixed and mobile cameras should be focused and individuals should not be unintentionally made the subject of surveillance.
____
a cafe installs a surveilance system capturing the entrance to improve security, as there have been reports of break-ins in the local area.

when reviewing the system, the owner realises the camera's FOV also captures the inside of a nearby private flat.

the owner adjusts the FOV so the focus of the recording is only on the entrance, to avoud any unnecessary privacy intrusion to nearby residents
##### surveilance case example 2

an education authority is considering FRT to verify pupils' identities at the cash register during lunch to facilitate cashless catering.

FRT involves processing **biometric data**, which presents risks to rights and freedoms, especially bias & discrimination.

the first action must be **data protection impact assessment** (*DPIA*)
**must evidence** that FRT is *necessary & proportionate*
will rely on *consent*, which must be freely given, specific, informed, and unambiguous.


if a pupil/parent refuses, they must be given a **genuine** alternative
- swipe card, pin number, cash, etc.

also, must apply **protection of freedoms act** 2021 *regarding parental consent*.

## technology in society

- digital technology has a double role as a utility, and as entertainment.
  it is part of the social fabric of our lives.
- *technology pervades* our workplaces, education, homes, and environmental infrastructure.
- **no one knows** the social, psychological, and intellectual **implications** of *such a reliance on technology*.
- predictions are abound that it will enhance intelligence and performance, and change behaviour. others say it diminishes some skills & attributes.
- beliefs about the value/perils of technology are not new.
- since the beginning of industrialisation, technology has been both valued & feared as a force for change.