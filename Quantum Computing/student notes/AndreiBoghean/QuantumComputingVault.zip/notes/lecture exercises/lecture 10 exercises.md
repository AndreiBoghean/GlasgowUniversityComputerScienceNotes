###### check relationships $Z=P^2$, $X=HZH$, $Y=PXP^3$
![[lecture 10 exercises 2025-04-15 17.05.12.excalidraw]]

###### check x AND y cannot be expressed as $ax+by+c$ but $CNOT(x, y) = (x, x+y) (\mod 2)$
![[lecture 10 exercises 2025-04-15 17.20.44.excalidraw]]

.. rest of this uncomplete cuz that's not showing up in exam

###### check toffoli is not affine
uncomplete cuz that's not showing up in exam

###### read the article and follow up on anything not understood
no.