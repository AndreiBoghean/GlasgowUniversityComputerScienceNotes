###### check that $\frac{\sqrt{ 3 }}{2}\ket{0}+\frac{1}{2}\ket{1}$ and $-\frac{1}{2}\ket{0}+\frac{\sqrt{ 3 }}{2}\ket{1}$ form an orthonormal basis
![[lecture 11 exercises 2025-04-15 18.07.33.excalidraw]]

###### check the other scalar products
basically done this already up above.. no need to do again.

###### check mapping of bell basis to standard basis
![[lecture 11 exercises 2025-04-15 18.35.55.excalidraw]]