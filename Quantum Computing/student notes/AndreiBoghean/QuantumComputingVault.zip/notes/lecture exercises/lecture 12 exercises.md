###### quantum secret sharing runthrough
![[lecture 12 exercises 2025-04-15 18.46.58.excalidraw]]

IMPORTANT: to measure in a basis, convert to that basis.