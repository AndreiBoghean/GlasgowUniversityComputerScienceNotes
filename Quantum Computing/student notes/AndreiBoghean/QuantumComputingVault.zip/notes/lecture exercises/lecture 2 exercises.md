###### check that $\sigma_{y}\sigma_{z}=i\sigma_{x}$
![[lecture 2 exercises 2025-04-14 12.46.18.excalidraw]]

###### what happens when we apply Z to a qbit in state $a\ket{0}+b\ket{1}$
![[lecture 2 exercises 2025-04-14 13.14.42.excalidraw]]

###### what is the result of applying H to $\ket{+}$ and to $\ket{-}$
![[lecture 2 exercises 2025-04-14 13.39.23.excalidraw]]

###### what are the possible results and probabilities when measuring $\frac{\sqrt{ 3 }}{2}\ket{0}-\frac{1}{2}\ket{1}$?
75% chance of 0; 25% chance of 1.

###### when writing a quantum state as $a\ket{0}+b\ket{1}$, why do we require $|a|^2+|b|^2=1$?
because probabilities must sum to 1.

###### check the effect on each basis state, by explicit multiplication.
![[lecture 2 exercises 2025-04-14 15.45.33.excalidraw]]

###### entanglement
![[lecture 2 exercises 2025-04-14 15.59.55.excalidraw]]

###### how transform bell states into the others?
![[lecture 2 exercises 2025-04-14 16.04.09.excalidraw]]

###### check the building of GHZ state
![[lecture 2 exercises 2025-04-14 16.27.09.excalidraw]]