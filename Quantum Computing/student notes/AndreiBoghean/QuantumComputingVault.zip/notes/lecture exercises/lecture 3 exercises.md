###### what happens if we calculate $F\ket{-}\ket{-}$ instead of $F\ket{+}\ket{-}$?
![[lecture 3 exercises 2025-04-14 16.57.51.excalidraw]]

###### what if apply Z then X in teleportation?
![[lecture 3 exercises 2025-04-14 17.41.53.excalidraw]]

###### why isnt teleportation faster than light?
because you need to physically move the classical bits necessary.