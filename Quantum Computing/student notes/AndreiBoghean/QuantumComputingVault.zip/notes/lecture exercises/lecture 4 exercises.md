###### what aspects of the teleportation protocol are not shown in this diagram?
the physical transfer of classical values from qbit measurement.

###### superdense coding exercise
![[lecture 4 exercises 2025-04-15 07.39.33.excalidraw]]

###### superdense coding diagram
![[lecture 4 exercises 2025-04-15 08.07.03.excalidraw]]

###### repeat calculation with $\bra{0}(\ket{\phi}\bra{\psi})$
![[lecture 4 exercises 2025-04-15 08.17.12.excalidraw]]