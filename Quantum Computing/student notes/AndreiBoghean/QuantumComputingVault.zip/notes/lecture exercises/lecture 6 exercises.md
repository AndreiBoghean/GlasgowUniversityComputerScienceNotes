###### why is U a unitary operator in general?
because it must be applied repeatedly so it must be specified as a unity operator to allow this without mutation of the underlying shape.

###### is $\frac{1}{2}$ correct here?
yes. 1/2 squared = 1/4 which means 25% chance for any given state, which is appropriate since there are 4 states.

###### check the grover diffusion operator for n=2
![[lecture 6 exercises 2025-04-15 08.52.55.excalidraw]]

###### have we seen $U=\begin{pmatrix}1 & 0 \\ 0 & -1\end{pmatrix}$ before?
yes. it is the phase operator Z.

###### have we seen $U=\begin{pmatrix}0 & 1 \\ 1 & 0\end{pmatrix}$ before?
yes. it is operator X.

###### why does more iterations in grover's algorithm not help?
because grover abuses rotation and more rotation just ends up taking us further from the desired value, eventually circling back.

###### what happens in the 2nd grover iteration for 2 bits?
![[lecture 6 exercises 2025-04-15 09.22.09.excalidraw]]

###### why isnt the answer exctractable from state $\frac{1}{2\sqrt{ 2 }}\begin{pmatrix}-1 \\ 1 \\ 1 \\ 1 \\ 1 \\ 1 \\ 1 \\ 1\end{pmatrix}$?
because each state has equal probability. we cant force the measurement to take a particular state, nor would we know the distribution even if we could.

###### understand geometric view of grover's algorithm
![[lecture 6 exercises 2025-04-15 09.34.31.excalidraw]]
TODO figure this out.