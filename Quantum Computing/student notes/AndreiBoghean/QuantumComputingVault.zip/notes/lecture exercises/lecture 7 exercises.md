###### in the Caesar cipher, what is the shared key?
it's the one-time-pad.

###### how to decrypt with one-time-pad?
XOR again with the key.

###### is the caesar cipher reciprocal?
only if n=13

###### how many bits does RSA use, and shor support?
2048 bits for RSA.
shor's has been used for 15 bits.