###### check that $\frac{1}{\sqrt{ 2 }}(\ket{00}+\ket{11})=\frac{1}{\sqrt{ 2 }}(\ket{++}+\ket{--})$
![[lecture 8 solutions 2025-04-15 11.50.53.excalidraw]]

###### measure the second qbit in $\ket{a}$ $\ket{b}$ basis with entanglement.
if we measure the second qbit and observe $\ket{a}$, then we're left with $\frac{\sqrt{ 3 }}{2\sqrt{ 2 }}\ket{0a}+\frac{1}{2\sqrt{ 2 }}\ket{1a}$
alternatively if we observe $\ket{b}$ we get $-\frac{1}{2\sqrt{ 2 }}\ket{0b}+\frac{\sqrt{ 3 }}{2\sqrt{ 2 }}\ket{1b}$

###### check the eigenvectors
![[lecture 8 solutions 2025-04-15 14.48.39.excalidraw]]

###### check working for $\braket{ A_{0} | B_{0} }$ in state $\ket{\psi}$ is $\bra{\psi}A_{0} \otimes A_{1}\ket{\psi}$
![[lecture 8 solutions 2025-04-15 15.37.21.excalidraw]]