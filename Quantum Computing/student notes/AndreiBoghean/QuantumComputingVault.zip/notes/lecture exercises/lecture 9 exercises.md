###### for sending a qbit, why cant we use simple classical repitition?
because of the no-cloning theorem.

###### check that this circuit implements the encoding
done.

###### bit flip error correction example
![[lecture 9 solutions 2025-04-15 16.24.47.excalidraw]]

###### fill in Rb of the bit flip decoder
![[lecture 9 solutions 2025-04-15 16.33.25.excalidraw]]

###### phase flip error correction example
![[lecture 9 solutions 2025-04-15 16.37.34.excalidraw]]