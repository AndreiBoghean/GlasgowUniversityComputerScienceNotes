# universal quantum computation
what do we need to achieve the "full power of quantum computation"?
well, what is the "full power of quantum computation"?
- the algorithmic advantages of QC are about *complexity*; not **computability**
- any quantum computation can be **simulated classically** to *arbitrary precision*
- a universal QC model *needs* enough **control constructs** to give *turing-complete* classical computation
- we're also interested in *which quantum states we need* to take advantage of **superposition**, **entanglement**, **interference**.

there are several formal QC models which are used to study complexity and computability
e.g. **quantum turing machines**, and *uniform families of quantum circuits*

we may also consider more high-level programming languages
e.g. **classical languages** with *APIs for quantum state* (quantum data, classical control)
or languages that allow *superpositions of programs*

##### gates
we will focus on which quantum operations (gates) are needed to **implement** *arbitrary unitary operators*, or **construct** *arbitrary quantum states* (starting from $|0\rangle$ states)

###### single-qbit gates (X, Y, Z, H)
if we only have single-qbit gates $X=\begin{pmatrix}0 & 1 \\ 1 & 0\end{pmatrix}$,  $Y=\begin{pmatrix}0 & -i \\ i & 0\end{pmatrix}$,  $Z=\begin{pmatrix}1 & 0 \\ 0 & -1\end{pmatrix}$. and **H**

we **can**
- create *superpositions* like $\frac{1}{\sqrt{2}}(0\rangle+|1\rangle)=H|0\rangle$
- generate random numbers by measuring $\frac{1}{\sqrt{2}}(|0\rangle+|1\rangle)$
- run the BB84 protocol for quantum key distribution

we **cant**
- create *entanglement*
- represent classical boolean circuits

###### 2-qbit gates (X, Y, Z, H, P, **CNOT**)
with **CNOT** and **H**, we can get the *Bell states* $\frac{1}{\sqrt{2}}(|00\rangle+|11\rangle)$, which gives us some **entanglement**
also note we still have the *aforementioned 1-qbit gates*, and also the **phase** gate $P=\begin{pmatrix}1 & 0 \\ 0 & i\end{pmatrix}$

this might seem like a good set of gates?
these gates are fairly versatile, **however** *we can only ever get* $0, \pm1, \pm i$
**when we apply them to** $|0\rangle$ or $|1\rangle$
- (permitting *normalising factors*)

###### one-qbit states with (X, Y, Z, H, **P**)
starting from $|0\rangle$ and using these gates, only six 1-qbit states can possibly be constructed.
$|0\rangle, |1\rangle, \frac{1}{\sqrt{2}}(|0\rangle\pm|1\rangle), \frac{1}{\sqrt{2}}(|0\rangle\pm i|1\rangle)$

this can be easy to check if you *reduce the set of gates* to H and P using these relationships
- $Z=P^2$  
- $X=HZH$
- Y=$PXP^3$

###### two-qbit states with (X, Y, Z, H, P, **CNOT**)
(..or equivalently CNOT, H, P)

we can now produce **entanglement**, but still only a finite amount of states.
these are known as *stabiliser states*, which have their own related topic of **stabiliser codes**

the tern *stabiliser* comes from a **representation** of these states that allows **quantum computation** to be *simulated* by an **efficient** *classical algorithm*.

##### stabiliser states
Stabilizer quantum mechanics extends to any number of qubits.
the number of n-qbit stabiliser states is $2^n\Pi^n_{j=1}(2^j+1)$

with *one* **qbit** there are 6 stabiliser states.

with *two* **qbits** there are 60 stabliser states.
- 6\*6=36 states that are tensor products of 1-qbit stabiliser states.
- the 4 bell states
- the 4 bell states with a phase of i $\frac{1}{\sqrt{2}}(|00\rangle\pm i|11\rangle)$, and $\frac{1}{\sqrt{ 2 }} |01\rangle \pm i|10\rangle)$
- 4 states of the form $\frac{1}{2}(|00\rangle+\alpha|01\rangle+\beta|10\rangle+\gamma|11\rangle)$
	- with $\alpha,\beta,\gamma=\pm 1$ and $\alpha\beta\gamma=-1$
- 12 states of the form $\frac{1}{2}(|00\rangle+\alpha|01\rangle+\beta|10\rangle+\gamma|11\rangle)$
	- with $\alpha,\beta,\gamma=\pm 1 \text{ or } \pm i$ and $\alpha\beta\gamma=1$

with *three* **qbits** there are 1080 stabiliser states.
###### what can we do with stabiliser states?
**YES:**
- the deutch-josza algorithm
- teleportation
- superdense coding
- the bit-flip, phase-flip, and shor error-correcting codes
- key distribution (BB84, BBM92, BB92, *not* E91)
- some other cryptographic protocols e.g. secret sharing
**NO:**
- grover's search algorithm
- shor's factorisation algorithm

###### CNOT
recall that NAND is the fundamental gate for classical boolean functions.

we have a 2-qbit gate CNOT, but it is **not** universal for classical boolean functions.
- since CNOT is an *affine* function mod 2, but **AND** and **OR** are not affine.
- (an *affine* function is of the form $ax+by+c$ for constants a, b, c)

###### the Toffoli gate
this is a *three-qbit* gate which is *like* **CNOT**, but with 2 control inputs.
the third qbit is inverted if *both* of the controls are 1.
````col
```col-md
flexGrow=1
===
**circuit**
![[Pasted image 20250210113854.png]]
```
```col-md
flexGrow=3
===
**logic table**
![[Pasted image 20250227195512.png]]
```
````
the Toffoli gate **is** *universal* for **classical boolean functions**, since the *third qbit* of the output is the ***NAND*** of the *first 2 qbits* of the input
- we are still representing 0 and 1 by $|0\rangle$ and $1\rangle$

- note that, unlike CNOT, Toffoli is ***NOT*** an *affine* function
###### universal gate sets
a set of gates S is *universal* if, **by composing gates from S**, then
*any* **unitary operator** on *any number of qbits* can be **approximated** to *any desired degree of precision*.

if S is *finite*, then approximation can *not* be given to an *arbitrary degree* of **precision**.

considering the set $\{CNOT, H, P\}$, it turns out that replacing H with *almost* **any other 1-qbit gate**, then *gives a universal set*.
one specific and simple gate that works is $R_{\frac{\pi}{8}}=\begin{pmatrix}\cos \frac{\pi}{8} & -\sin \frac{\pi}{8} \\ \sin \frac{\pi}{8} & \cos \frac{\pi}{8}\end{pmatrix}$
### universal gate sets
in general, $R_{\theta}=\begin{pmatrix}\cos \theta & -\sin\theta \\ \sin \theta & \cos \theta\end{pmatrix}$, which is a rotation.
$H=R_{\frac{\pi}{4}}$.

to get a *universal gate set*, we have to *replace* **H** by a *smaller* **rotation**.
the problem with H is that $\cos \frac{\pi}{r}=\sin \frac{\pi}{4}$, so we dont get enough different coefficients in our superpositions.
- editor's note: why? how?

another universal gate set is $\{Toffoli, H, P\}$

if we picked a 2-qbit gate uniformly at random,
the probability that it's universal is 100%.
**the problems come from the remaining 0% of gates**.

###### the Solavay-Kitaev Theorem
this theorem says that if S is a universal gate set that is closed under inverses
- i.e. if gate G is in S then it's inverse $G^{-1}$ is also in S
then we can approximate any unitary operator on n qbits to within precision $\epsilon$ using $O(4^n\text{ polylog}(\frac{1}{\epsilon}))$ gates.

if we treat n as fixed (e.g. if we are trying to approximate gates from one universal set using gates from a different universal set), then the number of gates required grows as some power of $\frac{1}{\epsilon}$

furthermore, the approximating gate sequences can be found by a reasonably efficient algorithm.

### what actually is the full power of quantum computing?
algorithmically, it's unclear. we don't know a polynomial-time quantum algorithm for an NP-complete problem.

quantum computing is being used for combinatorial optimisation problems, using the *quantum annealing* approach.
this is a **heuristic** technique, in some ways a kind of *analogue computing*, that seems to do well on some problem instances *but not all*.

the **quantum supremacy** demonstrations by google (2019 and subsequently) show that a quantum computer can efficiently solve the problem of sampling from a probability distribution generated by a random quantum circuit.

richard feynman suggested that quantum computers could be used to simulate the quantum behaviour of e.g. molecules.
the idea is that a quantum computer would be a configurable analogue simulation of naturally-occurring quantum systems of interest.
this might turn out to be more significant than algorithmic quantum computing.

### idk
![[lecture 10 2025-02-24 10.21.04.excalidraw|350]]

![[lecture 10 2025-02-24 10.48.42.excalidraw|350]]