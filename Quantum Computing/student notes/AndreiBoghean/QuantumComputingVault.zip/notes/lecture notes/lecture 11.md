### working with different bases
generally, we use the **standard** basis, writing a qbit state as a *linear combination* of $|0\rangle$, $|1\rangle$

however, we've also seen the **diagonal** basis $|+\rangle$ and $|-\rangle$.
it's even possible to express *any* qbit state as a *linear combination* of $|+\rangle$ and $|-\rangle$

````col
```col-md
flexGrow=1
===
one way to work this out is via
$$
\begin{align}
& \alpha|0\rangle+\beta|1\rangle \\
= & \frac{\alpha}{\sqrt{ 2 }}(|+\rangle+|-\rangle)+\frac{\beta}{\sqrt{ 2 }}(|+\rangle-|-\rangle)
\\ =& \frac{\alpha}{\sqrt{ 2 }}|+\rangle+\frac{\alpha}{\sqrt{ 2 }}|-\rangle+\frac{\beta}{\sqrt{ 2 }}|+\rangle-\frac{\beta}{\sqrt{ 2 }}|-\rangle
\\ =& \frac{\alpha}{\sqrt{ 2 }}|+\rangle+\frac{\beta}{\sqrt{ 2 }}|+\rangle+\frac{\alpha}{\sqrt{ 2 }}|-\rangle-\frac{\beta}{\sqrt{ 2 }}|-\rangle
\\ =& \frac{\alpha+\beta}{\sqrt{ 2 }}|+\rangle+\frac{\alpha-\beta}{\sqrt{ 2 }}|-\rangle
\end{align}
$$
```
```col-md
flexGrow=1
===
and then some column vector algebra gives..
$$
\begin{align}
\frac{\alpha+\beta}{\sqrt{ 2 }}|+\rangle+\frac{\alpha-\beta}{\sqrt{ 2 }}|-\rangle= &
\begin{pmatrix} \frac{\alpha+\beta}{\sqrt{ 2 }} \\ \frac{\alpha-\beta}{\sqrt{ 2 }} \end{pmatrix}_{d}
\\ =& \frac{1}{\sqrt{ 2 }}\begin{pmatrix}1 & 1 \\ 1 & -1\end{pmatrix} \begin{pmatrix}\alpha \\ \beta\end{pmatrix}_{s}
\\ =& H\begin{pmatrix}\alpha \\ \beta\end{pmatrix}_{s}
\end{align}
$$
```
````

where H is the matrix that *converts* between **standard** and **diagonal** basis.. i.e. *hadamard*.
in laymans terms.. applying hadamard to the standard basis gives the diagonal?

````col
```col-md
flexGrow=1
===
note that the reverse is also true..
i.e. applying hadamard to the diagonal gives the standard.
- note **in this case** this *simplification* works since $H=H^{-1}$
```
```col-md
flexGrow=1
===
$$
\begin{align}
\begin{pmatrix} \frac{\alpha+\beta}{\sqrt{ 2 }} \\ \frac{\alpha-\beta}{\sqrt{ 2 }} \end{pmatrix}_{d}
 &= H\begin{pmatrix}\alpha \\ \beta\end{pmatrix}_{s}
\\ 
H^{-1}\begin{pmatrix} \frac{\alpha+\beta}{\sqrt{ 2 }} \\ \frac{\alpha-\beta}{\sqrt{ 2 }} \end{pmatrix}_{d}
 &= H^{-1} H\begin{pmatrix}\alpha \\ \beta\end{pmatrix}_{s}
\\ 
H\begin{pmatrix} \frac{\alpha+\beta}{\sqrt{ 2 }} \\ \frac{\alpha-\beta}{\sqrt{ 2 }} \end{pmatrix}_{d}
 &= \begin{pmatrix}\alpha \\ \beta\end{pmatrix}_{s}
\end{align}
$$
```
````

###### basis whose matrix is not it's self-inverse
$\frac{\sqrt{ 3 }}{2}|0\rangle+\frac{1}{2}|1\rangle$ and $-\frac{1}{2}|0\rangle+\frac{\sqrt{ 3 }}{2}|1\rangle$ is a rotation of the standard basis by 30* anticlockwise.
the rotation matrix is $M = \begin{pmatrix} \frac{\sqrt{ 3 }}{2} & -\frac{1}{2} \\ \frac{1}{2} & \frac{\sqrt{ 3 }}{2} \end{pmatrix}$
we can now see that M, which moves the standard basis to the new basis $M|0\rangle=\frac{\sqrt{ 3 }}{2}|0\rangle+\frac{1}{2}|1\rangle$,
converts a column vector in the new basis to a column vector in the standard basis.
i.e. $\begin{pmatrix} \frac{\sqrt{ 3 }}{2} \\ \frac{1}{2}\end{pmatrix}_{s} = M \begin{pmatrix}  1 \\ 0\end{pmatrix}_{n}$

### orthogonal and orthonormal bases
in the theory of vector spaces, if we have an **n-dimensional vector space**, then **any** *set* of **n linearly independent vectors** then *form a basis* for the space.

this means that **any vector** can be *written as* a **linear combination** of *basis vectors*.

###### orthogonal basis
when considering quantum measurement with respect to a *particular* **basis**,
usually we *want* the basis vectors to be **orthogonal**.
- meaning that for any two basis vectors *u* and *v*, $u \cdot v=0$. alternatively, $\langle u|v\rangle=0$

###### orthonormal basis
since we always work with normalised states (length=1), we also have $\langle u|u\rangle=1$
for *each* **basis** state *u*.
this is called an **othonormal** basis
h
###### orthonormal checking
we can check that the *diagonal* basis is *orthonormal*, first knowing (or checking) that the **standard** basis is **orthonormal**.
- i.e. $\langle 0|1\rangle=0$, $\langle 0 | 0 \rangle = 1$, $\langle 1 | 1 \rangle = 1$
^ assuming we know this, we can then simply do
$$
\begin{align}
\langle + | - \rangle&= \frac{1}{\sqrt{ 2 }}(\langle 0|+\langle 1|) \frac{1}{\sqrt{ 2 }}(|0\rangle- |1\rangle)
\\ &= \frac{1}{2}(\langle 0|0\rangle - \langle 0|1\rangle+\langle 1|0\rangle-\langle 1|1\rangle)
\\ &= \frac{1}{2}(1-0+0-1)
\\ &= 0
\end{align}
$$
### another way of calculating basis changes
if we have a state $|a\rangle$, and we want to express it in basis $\{|u\rangle, |v\rangle\}$
then the coefficients are the scalar products $\braket{ u | a }$ and $\braket{ v | a }$
in general, $\ket{a}=\braket{ u | a }\ket{u}+\braket{ v | a }\ket{v}$
- requires $\{|u\rangle, |v\rangle\}$ be **orthonormal**.
- also, *this assumes a 2d space* (1 qbit), but **the same idea applies to higher dimensions**.

if $\ket{a}=x\ket{u}+y\ket{v}$, and we want to find x, then take
the inner product with $\bra{u}$ like $\braket{ u | a } = x \braket{ u | u } +y\braket{ u | v } = 1x+0y$
- ***this is a very important reason for why we like ortholinear-ness***

e.g. let's express $\frac{1}{\sqrt{ 2 }}(\ket{0}+\ket{1})$ in the basis $\{\frac{\sqrt{ 3 }}{2}\ket{0}+\frac{1}{2}\ket{1}, -\frac{1}{2}\ket{0}+\frac{\sqrt{ 3 }}{2}\ket{1}\}$
the inner products are $\begin{pmatrix} \frac{1}{\sqrt{ 2 }} & \frac{1}{\sqrt{ 2 }}\end{pmatrix} \begin{pmatrix} \frac{\sqrt{ 3 }}{2} \\ \frac{1}{2}\end{pmatrix}$ and $\begin{pmatrix} \frac{1}{\sqrt{ 2 }} & \frac{1}{\sqrt{ 2 }}\end{pmatrix} \begin{pmatrix} -\frac{1}{2} \\ \frac{\sqrt{ 3 }}{2}\end{pmatrix}$
- that is, $\frac{\sqrt{ 3 }+1}{2\sqrt{ 2 }}$ and $\frac{\sqrt{ 3 }-1}{2\sqrt{ 2 }}$

so $\frac{1}{\sqrt{ 2 }}(\ket{0}+\ket{1}) = \frac{\sqrt{ 3 }+1}{2\sqrt{ 2 }}(\frac{\sqrt{ 3 }}{2}\ket{0}+\frac{1}{2}\ket{1})+\frac{\sqrt{ 3 }-1}{2\sqrt{ 2 }}(-\frac{1}{2}\ket{0}+\frac{\sqrt{ 3 }}{2}\ket{1})$

### measuring in a different basis
we've been considering the standard basis as fundamental.
when we measure, it's in the standard basis.

but we can measure in *any basis*, and we need a way of doing the calculations for that.

if we have a specific state, we can express it in any basis we want,
and then see what the measurement probabilities are.

###### measuring $\frac{\sqrt{ 3 }}{2}\ket{0}+\frac{1}{2}\ket{1}$ in diagonal basis
the state is $\begin{pmatrix} \frac{\sqrt{ 3 }}{2} \\ \frac{1}{2}\end{pmatrix}$, which we convert to the diagonal basis by calculating
$H \begin{pmatrix} \frac{\sqrt{ 3 }}{2} \\ \frac{1}{2}\end{pmatrix}_{s} = \frac{1}{\sqrt{ 2 }} \begin{pmatrix}1 & 1 \\ 1 & -1\end{pmatrix} \begin{pmatrix} \frac{\sqrt{ 3 }}{2} \\ \frac{1}{2}\end{pmatrix}_{s} = \begin{pmatrix} \frac{\sqrt{ 3 }+1}{2\sqrt{ 2 }} \\  \frac{\sqrt{ 3 }-1}{2\sqrt{ 2 }}\end{pmatrix}_{d}$

now we can see that the probabilities are
- $( \frac{\sqrt{ 3 }+1}{2\sqrt{ 2 }})^2$ for $\ket{+}$
- $( \frac{\sqrt{ 3 }-1}{2\sqrt{ 2 }})^2$ for $\ket{-}$


in general, suppose we want to measure a state $\ket{a}$ in the basis $\{\ket{u}, \ket{v}\}$
we know that $\ket{a}=\braket{ u | a }\ket{u}+\braket{ v | a }\ket{v}$
which tells us that if we measure in the $\{\ket{u}, \ket{v}\}$ basis, the possible results are
- $|u\rangle$ with probability $|\braket{ u | a }|^2$
- $\ket{v}$ with probability $|\braket{ v | a }|^2$

###### a qbraid-friendly view of measuring in an alternative basis
note: what makes this "qbraid-friendly" is the use of a *primitive operation* for a **standard basis** *measurement*.

think of a standard basis measurement as telling us whether we have $0\rangle$ or $|1\rangle$,
and think of a diagonal basis measurement as telling us whether we have $\ket{+}$ or $\ket{-}$

if we want to distinguish between $\ket{+}$ and $\ket{-}$, but *the only primitive operation we have*
distinguishes between $\ket{0}$ and $\ket{1}$, then we can

*first* **apply** an *operator* that maps $\ket{+}\rightarrow \ket{0}$ and $\ket{-} \rightarrow \ket{1}$
- this is the H operator as we know.
*second*, we can simply execute a **standard** basis measurement
- e.g. with the earlier $\frac{\sqrt{ 3 }}{2}\ket{0}+\frac{1}{2}\ket{1}$, when we apply H and do a standard basis measurement
*then* we get the same result as the calculation from earlier.

###### relating to an arbitrary matrix M..
if we want to measure in the basis represented by the aforementioned matrix M,
we can first apply $M^{-1}$, and then measure in the standard basis.

#### bell basis
for 2-qbit states we have been using the standard basis $\{\ket{00}, \ket{01}, \ket{10}, \ket{11}\}$

another interesting basis is the *bell* basis, consisting of the 4 bell states
1. $\ket{\psi_{+}}=\frac{1}{\sqrt{ 2 }}(\ket{00}+\ket{11})$
2. $\ket{\psi_{-}}=\frac{1}{\sqrt{ 2 }}(\ket{00}-\ket{11})$
3. $\ket{\phi_{+}}=\frac{1}{\sqrt{ 2 }}(\ket{01}+\ket{10})$
4. $\ket{\phi_{-}}=\frac{1}{\sqrt{ 2 }}(\ket{01}-\ket{10})$

some protocols require measurement in the bell states.
- editor's note: why?

it's fairly easy to see that the bell states are linearly independent
i.e. we **cant find** a *linear combination* of them that **resolves to 0**.

###### they are orthonormal
we can also check that the states form an *orthonormal* basis, using the fact that
$(\bra{s}\otimes \bra{t})(\ket{u}\otimes \ket{v})=\braket{ s | u }\braket{ t | v }$
e.g.
$$
\begin{align}
\braket{ \psi_{+} | \psi_{+} } &= \frac{1}{\sqrt{ 2 }}(\bra{00} +\bra{11} ) \frac{1}{\sqrt{ 2 }}(\ket{00} +\ket{11} )
\\ &= \frac{1}{2}(\braket{ 00 | 00 } + \braket{ 00 | 11 } + \braket{ 11 | 00 } + \braket{ 11 | 11 } )
\\ &= \frac{1}{2}(\braket{ 0 | 0 }\braket{ 0 | 0 } + \braket{ 0 | 1 }\braket{ 0 | 1 } + \braket{ 1 | 0 }\braket{ 1 | 0 } + \braket{ 1 | 1 }\braket{ 1 | 1 } )
\\ &= \frac{1}{2}(1+0+0+1)
\\ &= 1
\end{align}
$$
###### measuring in the bell basis
**to implement protocols** that require measurement in the bell basis,
we need to *know how to convert* the **bell basis** into the **standard basis** for *2 qbits*.

if we start with $\ket{00}$ and apply **H** to the *first* qbit, then **CNOT** with the *first* qbit as control,
we get $\psi_{+}=\frac{1}{\sqrt{ 2 }}(\ket{00}+\ket{11})$
it's trivial to check that, by starting with any of $\ket{01}$, $\ket{10}$, $\ket{11}$, and by doing the same operations, **we get the other bell states**.

therefore we can convert the **bell basis** to the **standard basis** by *==reversing== these operations*:
i.e. **CNOT** then **H**.
- however, we should to be *careful* so that we know **exactly** how the *results of a standard basis measurement* tell us **which bell state** we had.

if we have qbits x and y, and we apply **CNOT**(y, x), then **H**(y),
the bell basis is mapped to the standard basis as follows:
$\ket{\psi_{+}}= \frac{1}{\sqrt{ 2 }}(\ket{00}+\ket{11})\rightarrowtail \ket{00}$
$\ket{\psi_{-}}= \frac{1}{\sqrt{ 2 }}(\ket{00}-\ket{11})\rightarrowtail \ket{01}$
$\ket{\phi_{+}}= \frac{1}{\sqrt{ 2 }}(\ket{01}+\ket{10})\rightarrowtail \ket{10}$
$\ket{\phi_{-}}= \frac{1}{\sqrt{ 2 }}(\ket{01}-\ket{10})\rightarrowtail \ket{11}$