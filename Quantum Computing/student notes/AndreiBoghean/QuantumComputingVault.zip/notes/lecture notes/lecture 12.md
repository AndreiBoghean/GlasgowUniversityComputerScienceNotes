### quantum secret sharing
this is another quantum cryptographic protocol.

presume *Alice* has a qbit they want to send to either *Bob* or *Carol*.

*Alice* can require both of them to collaborate in order to complete the transfer.
this collaboration is supposed to guard against a dishonest participant.
- the idea goes back to work by hillery, buzek, and berthiaume

#### process
#### setup
*Alice* starts with a qbit x (in an arbitrary state) that she wants to send to either *Bob* or *Carol*.

1. *Alice* constructs a GHZ state on three qbits
   - $a, b, c = \frac{1}{\sqrt{ 2 }}(\ket{000}+\ket{111})$
2. *Alice* **entangles x** with the GHZ state by CNOT to each bit in GHZ
   - not only CNOT(x, a) as in teleportation, but also CNOT (x, b) and CNOT(x, c)
3. *Alice* now sends **b** to *Bob* and **c** to *Carol*.

#### actual transfer
now suppose *Alice* wants to transfer x to *Carol*, requiring collaboration from *Bob*.

1. *Alice* measures x and a in the **Bell basis**, obtaining results $r_{x}$ and $r_{a}$.
2. *Alice* sends $r_{x}$ and $r_{a}$ to *Carol*.
3. *Bob* measures b in the **diagonal basis**, obtaining result $r_{b}$.
4. *Bob* sends $r_{b}$ to *Carol*.

*Carol* now applies operations to c, depending on the values of $r_{x}, r_{a}, r_{b}$

| $x, a$ state     | $r_{x}$ | $r_a$ | b state   | $r_b$ | operations     |
| ---------------- | ------- | ----- | --------- | ----- | -------------- |
| $\ket{\psi_{+}}$ | 0       | 0     | $\ket{+}$ | 0     | none           |
| $\ket{\psi_{+}}$ | 0       | 0     | $\ket{-}$ | 1     | Z(c)           |
| $\ket{\psi_{-}}$ | 0       | 1     | $\ket{+}$ | 0     | Z(c)           |
| $\ket{\psi_{-}}$ | 0       | 1     | $\ket{-}$ | 1     | none           |
| $\ket{\phi_{+}}$ | 1       | 0     | $\ket{+}$ | 0     | X(c)           |
| $\ket{\phi_{+}}$ | 1       | 0     | $\ket{-}$ | 1     | Z(c) then X(c) |
| $\ket{\phi_{-}}$ | 1       | 1     | $\ket{+}$ | 0     | Z(c) then X(c) |
| $\ket{\phi_{-}}$ | 1       | 1     | $\ket{-}$ | 1     | X(c)           |

note: the bell state gives amplitude information, and the diag state gives phase info.
#### "details" TODO: make sense of these.
###### we're starting with the GHZ state $a, b, c = \frac{1}{\sqrt{ 2 }}(\ket{000}+\ket{111})$.
now consider x in state $\alpha \ket{0}+\beta \ket{1}$, meaning overall we have
$$\begin{align}
x, a, b, c = & \frac{1}{\sqrt{ 2 }}(\alpha \ket{0} +\beta \ket{1} )(\ket{000} +\ket{111} )
\\ = & \frac{1}{\sqrt{ 2 }}(\alpha \ket{0000} +\alpha \ket{0111} +\beta \ket{1000} +\beta \ket{1111} )
\\ = & \frac{1}{\sqrt{ 2 }}(\alpha \ket{0000} +\alpha \ket{0111} +\beta \ket{1100} +\beta \ket{1011} ) \text{ after applying CNOT(x, a)}
\\ = & \frac{1}{\sqrt{ 2 }}(\alpha \ket{0000} +\alpha \ket{0111} +\beta \ket{1110} +\beta \ket{1001} ) \text{ after applying CNOT(x, b)}
\\ = & \frac{1}{\sqrt{ 2 }}(\alpha \ket{0000} +\alpha \ket{0111} +\beta \ket{1111} +\beta \ket{1000} ) \text{ after applying CNOT(x, c)}
\end{align}$$
^ note: seemingly, this only swaps 1000 and 1111 in case $\beta$, which does *effectively nothing*?

###### *Alice* now **measures** *x* and *a* **in the bell basis**.
this re-framing in the bell basis follows from the following algebra...
$$\begin{align}
x, a, b, c = & \frac{1}{\sqrt{ 2 }}(\alpha \ket{0000} +\alpha \ket{0111} +\beta \ket{1111} +\beta \ket{1000} )

\\ = & \frac{1}{\sqrt{ 2 }}(\alpha \ket{0000} +\beta \ket{1000} +\alpha \ket{0111} +\beta \ket{1111} )

\\ = & \frac{1}{\sqrt{ 2 }}(\alpha \ket{0000} +\beta \ket{1111} ) + \frac{1}{\sqrt{ 2 }}(\alpha \ket{0111} +\beta \ket{1000})
\end{align}
$$

````col
```col-md
flexGrow=1
===
$$\begin{align}
& \frac{1}{\sqrt{ 2 }}(\alpha \ket{0000} +\beta \ket{1111})
\\ = &  \frac{1}{2}((\alpha \ket{0000} + \beta \ket{1111}) + (\alpha \ket{0000} + \beta \ket{1111}))

\\ = &  \frac{1}{2}((\alpha \ket{0000} + \beta \ket{0011} + \alpha \ket{1100} + \beta \ket{1111}) \\
& + (\alpha \ket{0000} - \beta \ket{0011} - \alpha \ket{1100}  + \beta \ket{1111}))

\\ = &  \frac{1}{2}(\ket{00} +\ket{11} )((\alpha \ket{00} + \beta \ket{11}) \\
& + (\ket{00} - \ket{11} )(\alpha \ket{00} - \beta \ket{11}))

\\ = &  \ket{\psi_{+}} (\alpha \ket{00} + \beta \ket{11}) \\
& + \ket{\psi_{-}} (\alpha \ket{00} - \beta \ket{11})
\end{align}$$
```
```col-md
flexGrow=1
===
$$\begin{align}
& \frac{1}{\sqrt{ 2 }}(\alpha \ket{0111} + \beta \ket{1000})

\\ = &  \frac{1}{2}((\alpha \ket{0111} + \beta \ket{1000}) + (\alpha \ket{0111} + \beta \ket{1000}))

\\ = &  \frac{1}{2}(( \beta \ket{0100} + \alpha \ket{0111} + \beta \ket{1000} + \alpha \ket{1011}) \\
& + (-\beta \ket{0100} + \alpha \ket{0111} + \beta \ket{1000} - \alpha \ket{1011}))

\\ = &  \frac{1}{2}(\ket{01} + \ket{10} )((\beta \ket{00} + \alpha \ket{11}) \\
& + (\ket{01} - \ket{10} )(-\beta \ket{00} + \alpha \ket{11}))

\\ = &  \ket{\phi_{+}} (\beta \ket{00} + \alpha \ket{11}) \\
& + \ket{\phi_{-}} (-\beta \ket{00} + \alpha \ket{11})
\end{align}$$
```
````


$$\begin{align}
x, a, b, c = & \ket{\psi_{+}} (\alpha \ket{00}+\beta \ket{11} )+\ket{\psi_{-}} (\alpha \ket{00} -\beta \ket{11} ) \\
+ & \ket{\phi_{+}} (\beta \ket{00}+\alpha \ket{11} )+\ket{\phi_{-}} (\beta \ket{00} -\alpha \ket{11} )
\end{align}$$

###### *Bob* will measure *b* in the **diagonal** basis.
simiarly as for *Alice*, we  re-write *b* (*Bob*'s **qbit**) in terms of the **diagonal** basis
we can rewrite the four *components* of the state of x, a, b, c as:
$\ket{\psi_{+}}(\alpha \ket{00}+\beta \ket{11})=\ket{\psi_{+}}(\ket{+}(\alpha \ket{0}+\beta \ket{1})+\ket{-}(\alpha \ket{0}-\beta \ket{1}))$
$\ket{\psi_{-}}(\alpha \ket{00}-\beta \ket{11})=\ket{\psi_{-}}(\ket{+}(\alpha \ket{0}-\beta \ket{1})+\ket{-}(\alpha \ket{0}+\beta \ket{1}))$
$\ket{\phi_{+}}(\beta \ket{00}+\alpha \ket{11})=\ket{\phi_{+}}(\ket{+}(\beta \ket{0}+\alpha \ket{1})+\ket{-}(\beta \ket{0}-\alpha \ket{1}))$
$\ket{\phi_{-}}(-\beta \ket{00}+\alpha \ket{11})=\ket{\phi_{-}}(\ket{+}(-\beta \ket{0}+\alpha \ket{1})+\ket{-}(-\beta \ket{0}-\alpha \ket{1}))$

(note: these re-writes follow from the following working)
$$\begin{align}
\ket{\psi_{+}} (\alpha \ket{00} +\beta \ket{11} ) & = \ket{\psi_{+}}(\ket{+} (\alpha \ket{0} +\beta \ket{1} )+\ket{-} (\alpha \ket{0} -\beta \ket{1} )) \\ \\

\alpha \ket{00} +\beta \ket{11} & =\ket{+} (\alpha \ket{0} +\beta \ket{1} )+\ket{-} (\alpha \ket{0} -\beta \ket{1} ) \text{ simplify} \\ \\

\alpha \ket{00} +\beta \ket{11} & =\frac{1}{\sqrt{ 2 }}(\ket{0} +\ket{1} ) (\alpha \ket{0} +\beta \ket{1} )+\frac{1}{\sqrt{ 2 }}(\ket{0} -\ket{1} ) (\alpha \ket{0} -\beta \ket{1} ) \text{ substitute} \\

\alpha \ket{00} +\beta \ket{11} & =\frac{1}{\sqrt{ 2 }}(\alpha \ket{00} +\beta \ket{01} + \alpha \ket{10} +\beta \ket{11} )+\frac{1}{\sqrt{ 2 }}(\alpha \ket{00} -\beta \ket{01} - \alpha \ket{10} + \beta \ket{11} ) \text{ expand} \\

\alpha \ket{00} +\beta \ket{11} & =\frac{1}{\sqrt{ 2 }}(\alpha \ket{00} +\beta \ket{11} )+\frac{1}{\sqrt{ 2 }}(\alpha \ket{00} + \beta \ket{11} ) \text{ simplify} \\

\alpha \ket{00} +\beta \ket{11} & =2 \cdot \frac{1}{\sqrt{ 2 }}(\alpha \ket{00} +\beta \ket{11} ) \text{ finished, but why 2/sqrt(2)??} \\
\end{align}$$

there are $2^3=8$ possible combinations for the measurement results of *x*, *a*, *b*:
each line above has $\ket{+}$ and $\ket{-}$ possibilities for the measurement of *b*,
after measuring *x* and *a* in the **bell** basis.

we can *match up these 8 possibilities* with the table at the end of the protocol transfer process,
and check that, in each case, the final operations put c into the state $\alpha \ket{-}+\beta \ket{1}$.

the tricky ones are the last 2.
if the bell basis measurement gives 11, that means the state is
$$\begin{align}
& \ket{\phi_{-}} (-\beta \ket{00} +\alpha \ket{11} ) = \\
& \ \ket{\phi_{-}} \left[\ \ket{+} (-\beta \ket{0} +\alpha \ket{1} )+\ket{-} (-\beta \ket{0} -\alpha \ket{1} )\ \right]
\end{align}$$
and the measurement of b gives $\ket{+}$.
this means we then have the state $-\beta \ket{0}+\alpha \ket{1}$ for c.

applying Z(c) gives $-\beta \ket{0}-\alpha \ket{1}$
and applying X(c) gives $-\beta \ket{0}-\alpha \ket{0}$.

this is what we want, because the overall multiplication by -1
makes no difference physically. the other case is similar.