### bernstein-vazirani algorithm
a simple quantum algorithm with a linear speedup compared to the best classical algorithm
#### the problem
we are given a function $f \rightarrow \{0, 1\}^n \rightarrow \{0, 1\}$ that is guaranteed to compute the scalar product (modulo 2) of it's input $x=x_{1}x_{2}\dots x_{n}$
i.e. $f(x=x_{1}x_{2}\dots x_{n}) = x_{1}s_{1}\oplus x_{2}s_{2} \oplus x_{n}s_{n}$
- where $\oplus$ is XOR, the same as addition modulo 2.
- $x=x_{1}x_{2}\dots x_{n}$ means a sequence of bits, but in the definition of f, $x_{1}s_{1}$ et.c. means multiplication

we are given f as a black box,
or an **oracle** (something that can answer questions by mysterious methods)

the problem is to **find** *s*

#### classical solution

applying f gives a 1-bit result, so it can noly give us at most one vit of information about s.
we therefore have to apply f at least n times to find the whole of s.

applying f to an input with 1 in position i and 0 in the other positions gives result $s_i$
so we can find s with n applications of f, and this is the best possible.

#### quantum solution

if we assume that f is available in quantum form as the unitary operator $U_f$ defined by
$U_{f} \ket{x}= (-1)^{f(x)}\ket{x}$
- this definition means we're considering $\ket{x}$ to be a standard basis state $\ket{x_{1}x_{2}\dots x_{n}}$
- ^ note that this isnt $x_{1}\cdot x_{2}\dots$ it's literally neighbouring qbits up to n bits.

the action of $U_f$ is to either leave $\ket{x}$ unchanged, or multiply it by -1, according to whether f(x) is 0 or 1.

![[lecture 15 2025-03-10 10.21.52.excalidraw]]

###### protocol
1. start with n qbits, all in state $|0\rangle$
2. apply H to every qbit
3. apply $U_{f}$
4. apply H to every qbit
5. measure all the qbits in the standard basis

the result of the measurement is the bit sequence s, with probability 1.

###### example
3 qbits, with $s=101$
the definition of then is $f(x_{1}x_{2}x_{3})=x_{1}\oplus x_{3}$
and the definition of $U_f$ on the basis states is ...
![[Pasted image 20250310103436.png]]

we start with basis state $\ket{000}$ and apply H. this produces a uniform superposition as usual
$\frac{1}{2\sqrt{ 2 }}(\ket{000}+\ket{001}+\ket{010}+\ket{011}+\ket{100}+\ket{101}+\ket{110}+\ket{111})$

applying $U_{f}$ then gives
$\frac{1}{2\sqrt{ 2 }}(\ket{000}-\ket{001}+\ket{010}-\ket{011}-\ket{100}+\ket{101}-\ket{110}+\ket{111})$


applying H to every qbit turns every term into *8 terms*, and we have a lot of algebra for this.
in a simpler fasion, we can say

$$
\begin{align}
&\frac{1}{2\sqrt{ 2 }}(\ket{000}-\ket{001}+\ket{010}-\ket{011}-\ket{100}+\ket{101}-\ket{110}+\ket{111}) \\
= &\frac{1}{2}(\ket{00} \ket{-} +\ket{01} \ket{-} -\ket{10} \ket{-} -\ket{11} \ket{-} ) \\
= & \frac{1}{\sqrt{ 2 }}(\ket{0} \ket{+} \ket{-} - 1\ket{+} \ket{-}) \\
= & \ket{-} \ket{+} \ket{-} 
\end{align}
$$

after applying H to every qbit, we then get $\ket{101}$
finally, measuring this returns our s value of 101.
#### general analysis

first, we need to know that
$H^{\otimes n}\ket{x}=\frac{1}{(\sqrt{ 2 })^n}\Sigma_{y \in\{0, 1\}^n}(-1)^{x \cdot y}\ket{y}$
- where x and y are n-bit sequences which we expand as $x=x_{1}x_{2}\dots x_{n}$ (similarly for y) when we need to.
- note that the subscript for sigma simply means *applying n to every qbit*

this can be proved by induction on n.

###### base case
the base case is $n=1$.
$$
\begin{align}
H \ket{x_{1}} = & \{\frac{1}{\sqrt{ 2 }}(\ket{0} +\ket{1}) \text{ if } x_1 = 0; \frac{1}{\sqrt{ 2 }}(\ket{0} -\ket{1}) \text{ if } x_1 = 1 \\
= & \frac{1}{\sqrt{ 2 }}((-1)^{x_{1}0}\ket{0}+(-1)^{x_{1}1}\ket{1}  ) \\
= & \frac{1}{\sqrt{ 2 }} \Sigma_{x_{1} \in \{0, 1\}} (-1)^{x_{1}y_{1}}\ket{y_{1}}  )
\end{align}
$$

###### inductive step
... TODO FILL IN FROM SLIDE 11

