### quantum fourier transform
this is an operation that occurs frequently as apart of quantum algorithms

it can be used in the quantum **phase estimation** algorithm

grover's algorithm can be used when you have more than 1 hit on your matches, and you want to find one of them
the number of iterations you have to do is different, and depends on the number of solutions

quantum counting is an algorithm that finds out the number of solutions to a grover problem, without actually finding the solution.

###### background on fourier transforms
in the early 19th century, joseph fourier discovered that any periodic function can be expressed as a sum (possibly infinite) of sine and cosine functions with different frequencies

e.g. the function $\frac{4}{\pi} \Sigma_{n=1,3,5,\dots} \frac{1}{n}\\sin(n \pi x)$
defines a square wave
![[Pasted image 20250310111507.png|500]]

the fourier transform is a *continous* version of the idea on the previous slide, replacing the sum by an integral
$$f(\omega) = \int^{+\inf}_{-\inf} f(x)e^{-2\pi i \omega x}dx$$

the funtion f is the fourier transform of f. the variable $\omega$ represents frequency.
in terms of sound waves, if f represents the amplitude in terms of time (x) then f shows how much of each frequency ($\\omega$) is present in the waveform

the **discrete** fourier transform (DFT) considers a series of sampled values instead of a continous finction, so the integral becomes a *finite sum*

if the input is a vector x consisting of N values $x_{1},\dots,x_{N}$ then the output is y, also with values $y_{1},\dots,y_{N}$ defined by $y_{k}=\frac{1}{\sqrt{ N }}\Sigma^{N-1}_{j=0} x_{j} e^{2 \pi i j k / N}$

... TODO FILL IN FROM SLIDES

