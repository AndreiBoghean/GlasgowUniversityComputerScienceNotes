### complex numbers

###### definition
complex numbers have the form $a+bi$, where $a$ and $b$ are real numbers and $i=\sqrt{-1}$.
generally, $a$ is the *real* part and $i$ is the **imaginary** part.
- complex numbers can be **manipulated** with *regular algebra*.

complex numbers can be movtivated purely mathematically,
since they gives us a **number field** where *each polynomial equation has solutions*.

quantum mechanics is one of many physical theories that takes advantage of complex numbers, others including electromagnetism and fluid dynamics.

###### operations
````col
```col-md
flexGrow=2
===
**addition**
$$(a+bi)+(c+di) = (a+c)+(b+d)i$$
```
```col-md
flexGrow=1
===
**conjugate**
$$\overline{a+bi} = a-bi$$
```
```col-md
flexGrow=1
===
**modulus**
$$|a+bi| = \sqrt{a^2+b^2}$$
```
````
````col
```col-md
flexGrow=1
===
**multiplication**
$$\begin{align}
(a+bi)(c+di) = \\
a(c+di) + bi(c+di) = \\
ac+adi+bic+bdi^2 = \\
ac+adi+bic+bd(-1) = \\
(ac-bd)+(ad+bc)i
\end{align}$$
```
```col-md
flexGrow=1
===
**division**
$$\begin{align}
\frac{a+bi}{c+di} = \\
\frac{(a+bi)(c-di)}{(c+di)(c-di)} = \\
\frac{ac-adi+cbi-dibi}{c^2-cdi+cdi-d^2i^2} = \\
\frac{(ac+db)+(cb-ad)i}{c^2+d^2}
\end{align}$$
```
````
### vectors/matrices
###### operations

**addition**
$$
\begin{pmatrix}
a & b \\
c & d
\end{pmatrix}
+
\begin{pmatrix}
p & q \\
r & s
\end{pmatrix}
=
\begin{pmatrix}
a+p & b+q \\
c+r & d+s
\end{pmatrix}
$$

````col
```col-md
flexGrow=1
===
**multiplication of matrix with vector**
$$
\begin{pmatrix}
a & b \\
c & d
\end{pmatrix}
\begin{pmatrix}
x \\
y
\end{pmatrix}
=
\begin{pmatrix}
ax + by \\
cx + dy
\end{pmatrix}
$$
```
```col-md
flexGrow=1
===
**multiplication of 2 matrices**
$$
\begin{pmatrix}
a & b \\
c & d
\end{pmatrix}
\begin{pmatrix}
p & q \\
r & s
\end{pmatrix}
=
\begin{pmatrix}
ap+br & aq+bs \\
cp+dr & cq+ds
\end{pmatrix}
$$
```
````


**scalar product (inner product) of 2 vectors**
$$
\begin{pmatrix} a \\ b \end{pmatrix}
\cdot
\begin{pmatrix} c \\ d \end{pmatrix}
=
ac +bd
$$

````col
```col-md
flexGrow=1
===
**transpose**
$$
\begin{pmatrix}
a & b \\
c & d
\end{pmatrix}
^\top
=
\begin{pmatrix}
a & c \\
b & d
\end{pmatrix}
$$
```
```col-md
flexGrow=1
===
**conjugate transpose**
$$
\begin{pmatrix}
a & b \\
c & d
\end{pmatrix}
^*
=
\begin{pmatrix}
\overline{a} & \overline{c} \\
\overline{b} & \overline{d}
\end{pmatrix}
$$
```
````

### quantum bits
the bit is the basic unit of quantum information.

a qbit can be seen as an *abstract data type*, that can have various **physical implementations**
- spin-up/spin-down, polarity, etc.

**generally**, a qbit's state is $a|0\rangle + b|1\rangle$
- the qbit is comprised of **basis states**, here $|0\rangle$ and $|1\rangle$
	  - basis states **conceptually** *correspond to classical bit values*, but **physically** depend on *their implementations* as spin/polarity/etc.
- $a$ is the root of the probability for state 0, and similarly for b and 1.
- $|a|^2+|b|^2 = 1$
- the state can also be written as $\begin{pmatrix}a \\ b\end{pmatrix}$
	  - I think it is implied that the state vector is left-multiplied with $\begin{pmatrix}|0\rangle & |1\rangle\end{pmatrix}$
- this **general** state is a *superposition* of the **basis** *states*.
	  - i.e. it's just a linear combination. everything takes place in a vector space.

#### operators (a.k.a. **gates** by analogy with classical logic gates)
###### unitary operators

*unitary operators* are methods of manipulating qbits.
generally they're **any 2x2 complex matrix U** such that $UU^* = I$
- remember $U^*$ is *conjugate transpose*

unitary operators are **reversible**
- because *they have inverses*. (since they're square?)

to apply a unitary operator on a qbit,
multiply the *operator's* **matrix** by the *qbit's* **state vector**
- e.g. applying the X operator to a simple qbit state $a|0\rangle + b|1\rangle$, producing $a|1\rangle + b|0\rangle$
	- $\begin{pmatrix}0 & 1 \\ 1 & 0\end{pmatrix}$$\begin{pmatrix}a \\ b\end{pmatrix}$ = $\begin{pmatrix}b \\ a\end{pmatrix}$
	^ note that you can also figure this out with X's mappings $|0\rangle \rightarrow |1\rangle$ and $|1\rangle \rightarrow |0\rangle$

###### some standard unitary operators (the **pauli** operators)
**identity** $I = \begin{pmatrix}1 & 0 \\ 0 & 1\end{pmatrix}$ that encodes $|0\rangle \rightarrow |0\rangle$ and $|1\rangle \rightarrow |1\rangle$

**X** $X = \begin{pmatrix}0 & 1 \\ 1 & 0\end{pmatrix}$ that encodes $|0\rangle \rightarrow |1\rangle$ and $|1\rangle \rightarrow |0\rangle$

**Z** $Z = \begin{pmatrix}1 & 0 \\ 0 & -1\end{pmatrix}$ that encodes $|0\rangle \rightarrow |0\rangle$ and $|1\rangle \rightarrow |-1\rangle$

**Y** $Y = \begin{pmatrix}0 & -i \\ i & 0\end{pmatrix}$ that encodes $|0\rangle \rightarrow i|1\rangle$ and $|1\rangle \rightarrow -i|0\rangle$

these operators also have *alternative notation* $\sigma_X$, $\sigma_Y$, $\sigma_Z$ respectively

the operators also have **relationships** between them
- such as $\sigma_X\sigma_Y = i\sigma_Z$
- and others, stemming from this relationship.

###### hadamard operator
this operator converts the standard basis states into superpositions.

````col
```col-md
flexGrow=1
===
**in matrix form:**
$$H = \frac{1}{\sqrt{2}}\begin{pmatrix}1 & 1 \\ 1 & -1\end{pmatrix}$$
```
```col-md
flexGrow=2
===
**in formula form:**
$$|0\rangle \rightarrow \frac{1}{\sqrt{2}}(|0\rangle + |1\rangle), |1\rangle \rightarrow \frac{1}{\sqrt{2}}(|0\rangle - |1\rangle)$$
```
````
these states are denoted as $|+\rangle$ and $|-\rangle$.
they form an *alternative* **basis** for the vector space, called the ***diagonal basis***

###### phase operator
this operator multiplies the amplitude of $|1\rangle$ by i.
````col
```col-md
flexGrow=1
===
**in matrix form:**
$$P=\begin{pmatrix}1 & 0 \\ 0 & i\end{pmatrix}$$
```
```col-md
flexGrow=1
===
**in formula form:**
$$|0\rangle \rightarrow |0\rangle, |1\rangle \rightarrow i|1\rangle$$
```
````
###### measurement
another qbit operator is the **measurement** thereof. it is an *irreversible* operation.

if the state of a qbit is $a|0\rangle+b|1\rangle$, then the result of a measurement is **random**, with
- probability $|a|^2$ the result of the measurement is 0 and the state becomes $|0\rangle$,
- and probability $|b|^2$ the result of the measurement  is 1 and the state becomes $|1\rangle$
e.g. for a state $\frac{1}{\sqrt{2}}(|0\rangle+|1\rangle)$, both 0 and 1 have an equal probability of $|\frac{1}{\sqrt{2}}|^2 = \frac{1}{2} = 50\%$

#### multiple qbits
if we want to work with more qbits, we can use a vector space who's *basis* **corresponds** to the $2^n$ sequences of n bits.

notation for multiple qbits may be either $|00\rangle, |01\rangle, |10\rangle, |11\rangle$ or $|0\rangle|0\rangle, |0\rangle|1\rangle, |1\rangle|0\rangle, |1\rangle|1\rangle$

a *general quantum state* is a **superposition** of the *basis* states.
$a|00\rangle+b|01\rangle+c|10\rangle+d|11\rangle$, with $|a|^2+|b|^2+|c|^2+|d|^2=1$

````col
```col-md
flexGrow=4
===
as we work with mulitple qbits, our respective column vectors also change. we work with the basis vectors *in numerical order* of the **corresponding binary numbers**.
```
```col-md
flexGrow=1
===
$\begin{pmatrix}a \\ b \\ c \\ d\end{pmatrix}$
```
````
##### unitary operators on multiple qbits
unitary operators are *unitary*, so we can and do **only apply them qbit-wise**.
e.g. we can **apply** *X* **to the** *2nd* **qbit** of $\frac{1}{2}|000\rangle+\frac{1}{2}|010\rangle-\frac{1}{2}|110\rangle-\frac{1}{2}|111\rangle$
which **gives us** $\frac{1}{2}|010\rangle+\frac{1}{2}|000\rangle-\frac{1}{2}|100\rangle-\frac{1}{2}|101\rangle$

##### 2-qbit operators
2-qbit operators are of course *non-unitary* since they dont just operate on a single *unit* qbit.

###### CNOT
one such example is **CNOT**, defined as follows
````col
```col-md
flexGrow=1
===
**in idek form:**
$$\begin{align}
CNOT|0\rangle|0\rangle = |0\rangle|0\rangle \\
CNOT|0\rangle|1\rangle = |0\rangle|1\rangle \\
CNOT|1\rangle|0\rangle = |1\rangle|1\rangle \\
CNOT|1\rangle|1\rangle = |1\rangle|0\rangle \\
\end{align}$$
```
```col-md
flexGrow=1
===
**in matrix form:**
$$
\begin{pmatrix}
1 & 0 & 0 & 0 \\
0 & 1 & 0 & 0 \\
0 & 0 & 0 & 1 \\
0 & 0 & 1 & 0
\end{pmatrix}
$$
```
````

when applied to a quantum superposition, it acts as follows:
$$CNOT(\frac{1}{\sqrt{2}}|00\rangle+\frac{1}{\sqrt{2}}|11\rangle) = \frac{1}{\sqrt{2}}|00\rangle+\frac{1}{\sqrt{2}}|10\rangle$$
**explanation**:
CNOT means ***CONTROLLED NOT***, and effectively *inverts the 2nd bit according to what the first bit says*. so if bit 1 is high, then it does the inversion. if it's low, then it doesnt.

###### measurement
with several qbits, we are able to **measure** *any amount* of them.
it's **equivalent** to *several* **single-qbit measurements**.

with a 2-qbit state $a|00\rangle+b|01\rangle+c|10\rangle+d|11\rangle$, where we measure the first qbit,
- there is probability $|a|^2+|b|^2$ the result is 0
  and the state becomes $\frac{1}{\sqrt{|a|^2+|b|^2}}(a|00\rangle+b|01\rangle)$
- there is probability $|c|^2+|b|^2$ the result is 1
  and the state becomes $\frac{1}{\sqrt{|c|^2+|d|^2}}(c|10\rangle+d|11\rangle)$
i.e. **for each possible** *measurement result*, we are left with the parts of the superposition which are consistent with **that particular** *measurement result* and are hence **still possible**.

##### entanglement
some quantum states of 2+ qbits can be *decomposed* as the **tensor product** of states on fewer qbits. these states are **NOT ENTANGLED**, specifically *because they were factorisable*

e.g. if we have a first qbit in state $|0\rangle$, and a second in $\frac{1}{\sqrt{2}}(|0\rangle+|1\rangle)$,
then the 2-qbit state is $\frac{1}{\sqrt{2}}|0\rangle(|0\rangle+|1\rangle)=\frac{1}{\sqrt{2}}|00\rangle+\frac{1}{\sqrt{2}}|01\rangle)$.

the state $\frac{1}{\sqrt{2}}|00\rangle+\frac{1}{\sqrt{2}}|11\rangle$ on the other hand, ***IS* ENTANGLED**, which can be *proved by contradiction*
1. suppose $(a|0\rangle+b|1\rangle)(c|0\rangle+d|1\rangle)=|00\rangle+|11\rangle$.
2. trying to solve by multiplying out $ac|00\rangle+ad|01\rangle+bc|10\rangle+bd|11\rangle=|00\rangle+|11\rangle$
   suggests $ac = bd = 1$ and $ad=bc=0$.
3. therefore either $a=0$ or $d=0$, and either $b=0$ or $c=0$
4. if $a=0$ then we cant have $ac=1$, and if $d=$ then we cant have $bd=1$.
hence **it's impossible to decompose that state**.

###### entanglement measurement
suppose we measure the first qbit of the entangled state $\frac{1}{\sqrt{2}}|00\rangle+\frac{1}{\sqrt{2}}|11\rangle$.
- with probabilty $\frac{1}{2}$, the result is 0 and the state becomes $|00\rangle$.
- with probabilty $\frac{1}{2}$, the result is 0 and the state becomes $|11\rangle$.
in either case, the **new state is not entangled** and hence it **makes sense** to *talk about the state of each qbit* **separately**, and they *both have the same state*.

measuring one qbit also *puts the other qbit into the same state*, because e.g. in this case there are no other states where the first qbit=0.
- note that this does not provide a means of long-distance faster-than-light communication because we can not **set** the state of the first qbit.

###### creating entanglement
we can construct an entangled state using **H** and **CNOT**.
starting with $|00\rangle$, applying **H** to the first qbit gives $\frac{1}{\sqrt{2}}(|00\rangle+|10\rangle)$.
subsequently applying **CNOT** gives $\frac{1}{\sqrt{2}}(|00\rangle+|11\rangle)$.

#### quantum circuit diagrams
it's common to use circuit diagrams to describe quantum algorithms or protocols.
e.g. the following diagram shows a circuit that applies the **H** gate to a qbit in *initial state* $|0\rangle$
![[Pasted image 20250120003929.png]]

e.g. 2 here *creates an entangled pair of qbits* as outlined in [[#0.1.3.2.3.2 creating entanglement]]

````col
```col-md
flexGrow=1
===
![[Pasted image 20250120004106.png]]
```
```col-md
flexGrow=2
===
1. 2 qbits x and y, each in initial state $|0\rangle$.
2. **H** is applied to y.
3. **CNOT** is used with y as *control* and x as *target*
```
````

e.g. 3 here creates an entangled pair of qbits, and additionally measures them.
````col
```col-md
flexGrow=1
===
![[Pasted image 20250120004259.png]]
```
```col-md
flexGrow=2
===
1. 2 qbits x and y, each in initial state $|0\rangle$.
2. **H** is applied to y.
3. **CNOT** is used with y as *control* and x as *target*
4. "meters" are applied to x and y, measuring their value and mapping them to classical bits. (denoted by the the double lines)
```
````

#### entangled states
##### bell states
the bell states are an important set of 2-qbit entangled states.
````col
```col-md
flexGrow=1
===
$\frac{1}{\sqrt{2}}(|00\rangle+|11\rangle)$
```
```col-md
flexGrow=1
===
$\frac{1}{\sqrt{2}}(|00\rangle-|11\rangle)$
```
```col-md
flexGrow=1
===
$\frac{1}{\sqrt{2}}(|01\rangle+|10\rangle)$
```
```col-md
flexGrow=1
===
$\frac{1}{\sqrt{2}}(|01\rangle-|10\rangle)$
```
````
they are an *alternative* **basis** for the vector space of 2-qbit states.
- *any* **2-qbit state** can be *expressed* as a **superposition** of the *bell states*.

the *bell states* can also be **transformed into each other** by *applying single-qbit operators*
- first **H**(*x*), then **CNOT**(*x*, *y*)

##### Greenberger-Horne-Zeilinger (GHZ) state
the GHZ state is another that sometimes appears in applications, and is defined by $\frac{1}{\sqrt{2}}(|000\rangle+|111\rangle)$

to construct it: start with $x, y, z = |000\rangle$, apply H(x), CNOT(x, y), then CNOT(y, z)

note that the GHZ state can be generalised to more qbits such as $\frac{1}{\sqrt{2}}(|0000\rangle+|1111\rangle)$

##### W state
the W state is also a well-known enangled state, given by $W = \frac{1}{\sqrt{2}}(|001\rangle+|010\rangle+|100\rangle)$
- it **cannot be constructed using the operators we have seen so far**.

it can also be generalised to more qbits such as $\frac{1}{\sqrt{2}}(|0001\rangle+|0010\rangle+|0100\rangle+|1000\rangle)$