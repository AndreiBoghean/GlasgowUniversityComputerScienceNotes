### Deutsch's algorithm
#### the task
suppose we have an unknown function $f:\{0, 1\} \rightarrow \{0, 1\}$.
fundamentally, it must either be
- **constant**, meaning $f(0) = f(1)$
- or **balanced**, meaning $f(0) \neq f(1)$, implying that $f(0) = 1 - f(1)$

note: this was the **first proof** that quantum algorithms *can improve on classical algorithms*
#### trying to solve the problem
##### classical approach
to classify a problem classically, you *must* **evaluate** f(0), f(1), and compare the results.
- classical computers can *only* **evaluate** f.

how could we possibly do better on this? well, by using quantum.
##### quantum approach
if you can obtain a *quantum version*, **F**, of this algorithm, then you may do better.
###### silly quantum approach
you could expect a version of this algorithm such that $F|0\rangle = |f'(0)\rangle$ and $F|1\rangle = |f(1)\rangle$, 
but this *requires* that F is a **unitary operator** (implicitly also requiring it is *invertible*)
where the **classical algorithm** *f* *may not necessarily be invertable*.
- this may be the case if f takes multiple alguments? maybe.

###### good quantum approach
**instead** we can use a *2-qbit* F such that $F|x\rangle|y\rangle = |x\rangle|f(x)\oplus y\rangle$
- note that $F|x\rangle|0\rangle = |x\rangle|f(x)\rangle$ which allows F to be used to compute f.
- also note that F in invertible, without necessarily requiring f be so.
	  $F(F|x\rangle|y\rangle)=F(|x\rangle|f(x)\oplus y\rangle) = |x\rangle f(x)\oplus f(x)\oplus y\rangle=|x\rangle|y\rangle$

$$ \begin{align}
F|0\rangle|0\rangle = |0\rangle|1\rangle \\
F|0\rangle|1\rangle = |0\rangle|0\rangle \\
F|1\rangle|0\rangle = |1\rangle|1\rangle \\
F|1\rangle|1\rangle = |1\rangle|0\rangle
\end{align}$$
this version of F *seems like a much more reasonable attempt*.
###### investigation of $|x\rangle$ and $|-\rangle$ in the quantum approach
taking this further.... we experiment with them in F "just for fun" using $|+\rangle$ and $|-\rangle$
- may be interesting since this isnt possible classically.

we observe that
- $F|x\rangle|0\rangle = |x\rangle|f(x) \oplus 0\rangle = |x\rangle|f(x)\rangle$
- $F|x\rangle|1\rangle = |x\rangle|f(x) \oplus 1\rangle$
and also recall the states $|+\rangle = \frac{1}{\sqrt{2}}(|0\rangle+|1\rangle)$ and $|-\rangle=\frac{1}{\sqrt{2}}(|0\rangle-|1\rangle)$

now, **first considering** $F|x\rangle|+\rangle$
we can see that $F|x\rangle|+\rangle = F|x\rangle\frac{1}{\sqrt{2}}(|0\rangle+|1\rangle) = \frac{1}{\sqrt{2}}(F|x\rangle|0\rangle+F|x\rangle|1\rangle)$
- i.e. this is either $F|x\rangle|0\rangle$ *or* $F|x\rangle|1\rangle$

we can use the aforementioned substitutions to show that
$F|x\rangle|+\rangle = F|x\rangle\frac{1}{\sqrt{2}}(|0\rangle+|1\rangle) = \frac{1}{\sqrt{2}}(F|x\rangle|0\rangle + F|x\rangle|1\rangle) = \frac{1}{\sqrt{2}}(|x\rangle|f(x)\rangle + |x\rangle|f(x) \oplus 1\rangle)$

````col
```col-md
flexGrow=1
===
if f(x) = 0 then $f(x)\oplus1 = 1$ and we extend the above to say
$$\begin{align}
&\frac{1}{\sqrt{2}}(|x\rangle|f(x)\rangle + |x\rangle|f(x) \oplus 1\rangle) \\
= &\frac{1}{\sqrt{2}}(|x\rangle|0\rangle + |x\rangle|1\rangle) \\
 = &|x\rangle|+\rangle
\end{align}$$
```
```col-md
flexGrow=1
===
otherwise if f(x) = 1 then $f(x)\oplus1 = 0$ and we extend the above to say
$$\begin{align}
&\frac{1}{\sqrt{2}}(|x\rangle|f(x)\rangle + |x\rangle|f(x) \oplus 1\rangle) \\
= &\frac{1}{\sqrt{2}}(|x\rangle|1\rangle + |x\rangle|0\rangle) \\
 = &|x\rangle|+\rangle
\end{align}$$
```
````
which tells us that $F|x\rangle|+\rangle = |x\rangle|+\rangle$ \-\_\-

again with $F|x\rangle|-\rangle$ we can see that F simplifies to
$F|x\rangle|-\rangle = F|x\rangle\frac{1}{\sqrt{2}}(|0\rangle-|1\rangle) = \frac{1}{\sqrt{2}}(F|x\rangle|0\rangle-F|x\rangle|1\rangle) = \frac{1}{\sqrt{2}}(|x\rangle|f(x)\rangle-|x\rangle|f(x)\oplus 1\rangle)$

````col
```col-md
flexGrow=1
===
if f(x) = 0 then $f(x)\oplus1 = 1$ and we extend the above to say
$$\begin{align}
&\frac{1}{\sqrt{2}}(|x\rangle|f(x)\rangle - |x\rangle|f(x) \oplus 1\rangle) \\
= &\frac{1}{\sqrt{2}}(|x\rangle|0\rangle - |x\rangle|1\rangle) \\
= &|x\rangle\frac{1}{\sqrt{2}}(|0\rangle - |1\rangle) \\
= &|x\rangle|-\rangle \\
\end{align}$$
```
```col-md
flexGrow=1
===
otherwise if f(x) = 1 then $f(x)\oplus1 = 0$ and we extend the above to say
$$\begin{align}
&\frac{1}{\sqrt{2}}(|x\rangle|f(x)\rangle - |x\rangle|f(x) \oplus 1\rangle) \\
= &\frac{1}{\sqrt{2}}(|x\rangle|1\rangle - |x\rangle|0\rangle) \\
= &|x\rangle\frac{1}{\sqrt{2}}(|1\rangle - |0\rangle) \\
= &-|x\rangle\frac{1}{\sqrt{2}}(-|1\rangle + |0\rangle) \\
= &-|x\rangle|-\rangle \\
\end{align}$$
```
````
==therefore $F|x\rangle|-\rangle = (-1)^{f(x)}|x\rangle|-\rangle$==
- this is interesting to us because the outcome is a function of f(x)
which then follows the conditions of
- $F|0\rangle|-\rangle = (-1)^{f(0)}|0\rangle|-\rangle$
- $F|1\rangle|-\rangle = (-1)^{f(1)}|1\rangle|-\rangle$
###### using a linear combination of states; $F|+\rangle|-\rangle$
multiplying a **quantum** state by a **scalar** value doesnt have any *physical* significance
- unless you're constructing a **linear combination of states**
- , hence $F|x\rangle|-\rangle$ *is equivalent to* $|x\rangle|-\rangle$, independently of $f(x)$
	- (since $(-1)^{f(x)}$ is simply disregarded)

within the function $F|+\rangle|-\rangle = \frac{1}{\sqrt{2}}(F|0\rangle|-\rangle+F|1\rangle|-\rangle)$, however,
it is a linear combination of states.

hence..
when *f(0) = f(1)* (**constant**), then $F|0\rangle|-\rangle$ and $F|1\rangle|-\rangle$ have **the same** *scalar multiple*
- $(-1)^{f(x)}$ becomes the same value in both cases (either **+1 or -1**)
when *f(0) != f(1)* (**balanced**), then $F|0\rangle|-\rangle$ and $F|1\rangle|-\rangle$ have **different** *scalar multiples*
- $(-1)^{f(x)}$  is **+1** in once case, and **-1** in the other

````col
```col-md
flexGrow=1
===
**so when the function is constant...**
$$\begin{align}
F|+\rangle|-\rangle =&
\frac{1}{\sqrt{2}}(F|0\rangle|-\rangle+F|1\rangle|-\rangle) \\
= &\frac{1}{\sqrt{2}}((-1)^{f(0)}|0\rangle|-\rangle \\
+&(-1)^{f(1)}|1\rangle|-\rangle) \\
\\
= &\frac{1}{\sqrt{2}}(+|0\rangle+|1\rangle)|-\rangle \\
\text{ or } &\frac{1}{\sqrt{2}}(-|1\rangle-|0\rangle)|-\rangle \\
\\
= &|+\rangle|-\rangle \\
\text{ or } -&|+\rangle|-\rangle \\
\\
= \pm &|+\rangle|-\rangle
\end{align}$$
```
```col-md
flexGrow=1
===
**so when the function is balanced...**
$$\begin{align}
F|+\rangle|-\rangle =
&\frac{1}{\sqrt{2}}(F|0\rangle|-\rangle+F|1\rangle|-\rangle) \\
= &\frac{1}{\sqrt{2}}((-1)^{f(0)}|0\rangle|-\rangle \\
+&(-1)^{f(1)}|1\rangle|-\rangle) \\
\\
= &\frac{1}{\sqrt{2}}(|0\rangle-|1\rangle)|-\rangle \\
\text{ or } &\frac{1}{\sqrt{2}}(|1\rangle-|0\rangle)|-\rangle \\
\\
= &|-\rangle|-\rangle \\
\text{ or } = -&|-\rangle|-\rangle \\
\\
=\pm&|-\rangle|-\rangle
\end{align}$$
```
````

more concisely, this is to say that
$F|+\rangle|-\rangle = \pm|+\rangle|-\rangle$ if f(0) = f(1) .. i.e. is constant
$F|+\rangle|-\rangle = \pm|-\rangle|-\rangle$ if f(0) != f(1) .. i.e. is balanced

effectively, the constant/balanced property has been encoded as a quantum bit we can just measure.

now we can just apply H to the first qbit to get the *measurable* states:
- $|0\rangle|-\rangle$ if f is constant
- $|1\rangle|-\rangle$ if f is balanced
note that we can discard $\pm$ because it's a scalar multiple.
also recall from lecture 2 that H does $|+\rangle\rightarrow|0\rangle$ and $|-\rangle\rightarrow|1\rangle$

in summary:  deutch's algorithm allows calculating f(0) and f(1) with just *a single application* of **F**, which crucially **only encodes** the *global property* of **f** *in a single place* and hence **is extractable by *simple* measurement**.

#### the full detsch-jozsa algorithm
is a variant of the regular deutsch problem, that is a generalisation to a function of *n* bits that is known to either be constant or balanced.
- note that *you do not necessarily know* for every function that it is **either constant or balanced**.
- to find out.. *keep applying the function* to **every input** until either *you've exhausted all $2^{n-1}+1$ inputs*, or you *find a result that is different*

### the no-cloning theorem
it's *not possible* to **copy an unknown qbit** state.
i.e. there's no unitary operator U such that $U|s\rangle|e\rangle = |s\rangle|s\rangle$
- where $|s\rangle \forall$ 1-qbit states
- and $|e\rangle$ is some standard initial state for the second qbit.
i.e. ***it takes 2 qbits and copies one to the other***

this is a contrast to classical digital information processing, where **the ability to copy** arbitrary information is a *defining and highly-utilised feature*.

###### **geometric** proof by contradiction
**keep in mind**:
1. a unitary operator is a **rotation**, i.e. it *preserves angles*.
2. the scalar product $\cdot$ of 2 normalised vectors is $\cos \theta$, where $\theta$ is the *angle between them*
3. $(|a\rangle|b\rangle)\cdot|c\rangle|d\rangle)=(|a\rangle\cdot|c\rangle)(|b\rangle\cdot|d\rangle)$

now consider any 2 simple qbit states $|s\rangle$ and $|t\rangle$ with an angle between them $\theta$.
$$\begin{align}
\cos\theta & = |s\rangle\cdot|t\rangle \\
& = (|s\rangle|e\rangle)\cdot(|t\rangle|e\rangle) \text{  (because |e\rangle is normalised)} \\
& = (U|s\rangle|e\rangle)\cdot(U|t\rangle|e\rangle) \text{  (because U is a rotation)} \\
& = (|s\rangle|s\rangle) \cdot (|t\rangle|t\rangle) \\
& = (|s\rangle \cdot |t\rangle)(|s\rangle\cdot|t\rangle) \\
& = (\cos\theta)(\cos\theta) \\
\end{align}$$
hence, if there really exists a unitary cloning operator U, then $(\cos\theta)^2=\cos \theta$
which requires $\cos \theta$ is 0 or 1.
and hence **means** $|s\rangle$ and $|t\rangle$ are either *parallel* or *orthogonal*.
this is of course *not possibly true* for ***all* arbitrary pairs of states** and gives our *contradiction*.

###### **algebraeic** proof by contradiction
$$\begin{align}
\langle s|t\rangle = & \langle s|t\rangle\langle e|e\rangle \\
= & (\langle s|\langle e|)(| t\rangle|e\rangle) \text{ (multiply out)}\\
= & \langle s|\langle e| U^*\ U | t\rangle|e\rangle \text{ (because $U^*\ U$ is the identity)}\\
= & (\langle s|\langle e| U^*)(U | t\rangle|e\rangle) \\
= & (\langle s|\langle s|)(| t\rangle|t\rangle) \text{ (apply $U^*$ and U)}\\
= & \langle s| t\rangle^2\\
\end{align}$$
this proof then finishes similarly to the geometric one above.
### quantum teleportation
we quant copy quantum information, bit we can transfer it, destroying the original.
- note that this is specifically called *teleportation* because the **source** and **target** *qbit* can be **physically separated** by a technically arbitrary distance.
	  - this can be used to beam a person up as in star trek.
#### quantum teleportation protocol
###### protocol steps
1. suppose **alice** and **bob** *already share* an **entangled pair of qbits**, *x* and *y*, in the state $\frac{1}{\sqrt{2}}(|0\rangle|0\rangle+|1\rangle|1\rangle)$

2. **alice** has a qbit *z* in an *unknown state*, and she wishes to transmit this state to **bob**.
- (perhaps the physical form of *z* is not suitable for a direct transfer)

3. **alice** applies **CNOT**(*z*, *x*) and then **H**(*z*). (a.k.a. measures in the bell basis?)

4. **alice** then measures *z* and *x* to yield a **2bit** classical value which *she sends to **bob*** on a channel c.

5. **bob** uses this value to control the *conditional* application of X and Z operators to y.
the result is that the final state of y is the same as the initial state of z.

6. in the end, *z* is on some *different state* that **depends** on exactly how the *measurements* came out.

###### mathematical run-through
we have an *initial entangled state* **x, y**$= \frac{1}{\sqrt{2}}(|0\rangle|0\rangle + |1\rangle|1\rangle)$
**z** has some *general state* $\ = a|0\rangle+b|1\rangle$
hence the *overall state* can be **represented as**
$$\begin{align}
z, x, y = &(a|0\rangle + b|1\rangle)\frac{1}{\sqrt{2}}(|0\rangle|0\rangle+|1\rangle|1\rangle) \\

= \frac{1}{\sqrt{2}}&((a|0\rangle + b|1\rangle)|0\rangle|0\rangle+(a|0\rangle + b|1\rangle)|1\rangle|1\rangle) \\

= \frac{1}{\sqrt{2}}&((a|0\rangle|0\rangle|0\rangle + b|1\rangle|0\rangle|0\rangle)+(a|0\rangle|1\rangle|1\rangle + b|1\rangle|1\rangle|1\rangle)) \\

= \frac{1}{\sqrt{2}}&(a|000\rangle+a|011\rangle+b|100\rangle+b|111\rangle) \\

& \text{now applying CNOT(z, x)...} \\

= \frac{1}{\sqrt{2}}&(a|000\rangle+a|011\rangle+b|110\rangle+b|101\rangle) \\

& \text{now applying H(z)...} \\
\end{align}$$
![[lecture 3 2025-02-04 20.41.08.excalidraw|600]]

**finally**, rearrange to get:
$$\begin{align}
z,x,y = \frac{1}{2} (
& a|000\rangle+b|001\rangle+b|010\rangle+a|011\rangle \\
+&a|100\rangle-b|101\rangle-b|110\rangle+a|111\rangle
) \\
\end{align}$$

now we can measure z and x to get a 2 bit result:
- note that our table here now tells us the last remaining possible state, assuming z and x took the values written in the 2nd column.

````col
```col-md
flexGrow=1
===
**simply...**

| State                                                | 2 bits |
| ---------------------------------------------------- | ------ |
| $z, x, y = a\textbar 000\rangle+b\textbar001\rangle$ | 0, 0   |
| $z, x, y = b\textbar 010\rangle+a\textbar011\rangle$ | 0, 1   |
| $z, x, y = a\textbar 100\rangle-b\textbar101\rangle$ | 1, 0   |
| $z, x, y = -b\textbar 110\rangle+a\textbar111\rangle$ | 1, 1   |

```
```col-md
flexGrow=1
===
**simpler...**

| State                                                | 2 bits |
| ---------------------------------------------------- | ------ |
| $z, x, y = \textbar00\rangle (a\textbar 0\rangle+b\textbar1\rangle)$ | 0, 0   |
| $z, x, y = \textbar01\rangle (b\textbar 0\rangle+a\textbar1\rangle)$ | 0, 1   |
| $z, x, y = \textbar10\rangle (a\textbar 0\rangle-b\textbar1\rangle)$ | 1, 0   |
| $z, x, y = \textbar11\rangle (-b\textbar 0\rangle+a\textbar1\rangle)$ | 1, 1   |
```
````
remember when we represented the transfer subject, **z**,
using an abstract state $z=a|0\rangle+b|1\rangle$?

now, **we can clearly see a and b** (from this abstract state) *encoded* in **y**.
however they're not in the right positions and polarities.

since we measured x and z, we can conditionally apply gates to y to restore it to the proper abstract form.

| State                                                                 | operation                                             | final State                                                          |
| --------------------------------------------------------------------- | ----------------------------------------------------- | -------------------------------------------------------------------- |
| $z, x, y = \textbar00\rangle (a\textbar 0\rangle+b\textbar1\rangle)$  | None                                                  | $z, x, y = \textbar00\rangle (a\textbar 0\rangle+b\textbar1\rangle)$ |
| $z, x, y = \textbar01\rangle (b\textbar 0\rangle+a\textbar1\rangle)$  | invert bits using X(y)                                | $z, x, y = \textbar01\rangle (a\textbar 0\rangle+b\textbar1\rangle)$ |
| $z, x, y = \textbar10\rangle (a\textbar 0\rangle-b\textbar1\rangle)$  | negate non-zero using Z(y)                            | $z, x, y = \textbar10\rangle (a\textbar 0\rangle+b\textbar1\rangle)$ |
| $z, x, y = \textbar11\rangle (-b\textbar 0\rangle+a\textbar1\rangle)$ | invert bits using X(y) and negate non-zero using Z(y) | $z, x, y = \textbar11\rangle (a\textbar 0\rangle+b\textbar1\rangle)$ |
- you may also observe that we're effectively using the *first bit* to apply **Z**, and *2nd* for **X**.
after this, the final state of y is now the same as the initial state of z. yay.
###### information transfer in teleportation.

the **information** sent from alice to bob is *two classical bits*,
which is ***much less*** than the **information content** of a qbit state (*2 complex numbers*)

the pre-preemptively shared pair of qbits are are a standard state, so the preparation process can not be considered information transfer.
it is illogical, but maths and physics says it's correct so live with it.

###### experimental verification of teleportation
suppose we want to check that $|0\rangle$ can be teleported.
we create $z=|0\rangle$ and *run the teleportation protocol*, giving us a *quantum state* **y** at the *receiver*.

**how can we validate** the qbit has been sucessfully sent?
well, we *measure* it's **probability distribution**, by *sampling it enough times* to know for sure.


ok great. but what if something unknown is happening that means our process works for $|0\rangle$ but not other states?
ok, so we run the experiment with other states such as $\frac{1}{\sqrt{2}}(|0\rangle+|1\rangle)$.
we measure the distribution, see that it's more-or-less accurate
- (barring the inaccuracies of state preparation)

ok now but what if the experiment is not actually demonstrating teleportation at all?
in the accepted demosntration, a theoretical analysis was carried out to
find a **statistical measure** that *cant possibly be achieved without entangled states*.
- this is related to the fact that *entangled states* **produce** *measurement statistics* that are **more** *highly correlated* **than is possible** *without* entanglement

in Bosci et al. a threshold of $\frac{3}{4}$ is used, separating classical from quantum "teleportation".
- the aim of the experiment was to show that certain results occured with probability (i.e. frequency) greater than $\frac{3}{4}$

###### quantum teleportation diagram
also reference below the circuit diagram for teleportation
![[Pasted image 20250120113211.png]]