### quantum circuit diagrams
#### description
sometimes the phrase "quantum circuit" is used to mean "quantum algorithm" or "quantum protocol".

a *quantum circuit diagram* is a **mixture** of low-level and high-level approaches.
- **low-level**: in classical computing, circuit diagrams show *electronic* **hardware details**
- **high-level**: a "*wire*" represents a *qbit*, but physically there is no such wire. it's an *abstraction* of the **control flow** involving *one qbit*.
#### example diagrams
###### example diagram for an entangled pair of qbits
![[Pasted image 20250206192651.png]]
- depicts 2 qbits x and y both in *initial state* $|0\rangle$, followed by **H**(y) and lastly a **CNOT**(y, x)
###### circuit diagram for teleportation
note: this diagram *demonstrates all* of the **common notation**.
![[Pasted image 20250120113203.png]]
- *single horizontal lines* are **qbits**
- *double lines* are **classical bits**.
- x and y are *controlled operators*, **conditioned** on **classical bits**.
- the "*meter*" symbol is a **measurement**
also note that this diagram doesnt show the *physical transport* of **classical** bits *required* in actual teleportation.

###### circuit diagram for deutsch's algorithm
recall we have an *unknown function* $f : \{0, 1\} \rightarrow \{0, 1\}$ which is **either** *constant* or *balanced*
and additionally a *quantum variant* $F|x\rangle|y\rangle=|x\rangle|f(x)\oplus y\rangle$
the circuit diagram for this is:
![[Pasted image 20250206194008.png]]

### superdense coding
this quantum communication protocol is semi-similar to teleportation.
it lets **alice** send a 2-bit ***classical*** value to **bob** by using a *pre-existing entangled pair of qbits*.
###### steps
1. just like teleportation, **alice** and **bob** start with qbits *x* and *y* in state $\frac{1}{\sqrt{2}}(|0\rangle|0\rangle+|1\rangle|1\rangle$
2. then **alice** *selectively* applies a **unitary operator** to *x* according to what values they wish to send. (see table below)
3. **alice** then *sends* qbit *x* to **bob** so he has **both** *x* and *y*
4. **bob** now **decodes** by applying **CNOT**(*x*, *y*) and **H**(*x*)
	- at this point, *x* and *y* are now in a **single**-*basis* 2-qbit state corresponding directly to the 2bit value **alice** had *sent*. (i.e. *sending* 00 yields $|00\rangle$, 01 $\Rightarrow$ $|01\rangle$, etc.)
5. bob now **measures** the qbits to find the *classical* bits **alice** sent.

| transmission bits | operation             |
| ----------------- | --------------------- |
| 00                | Identity (do nothing) |
| 01                | apply X to x          |
| 10                | apply Z to x          |
| 11                | apply X then Z to x   |

###### superdense coding exercise

![[Drawing 2025-01-20 11.43.09.excalidraw|999]]

###### superdense coding as secure communication
suppose an attacker, **eve** intercepts qbit *x* while it's being sent from **alice** to **bob**
**eve** has just *part* of an **entangled pair**, and *cant recover the 2bit value* **without the other**.

hence it permits **alice** and **bob** to *communicate securely*,
provided they have **obtained a shared entangled pair** of qbits *beforehand*.
- this process can be likened to *establishing a key* for a **symmetric cryptosystem**

###### superdense coding circuit diagram
see lecture 4 exercises solution.
### diract notation
###### the ket
dirac notation helps make **algebraic calculations** in quantum mechanics *clear and smooth*.
we're already familiar with $|.\rangle$, which is called a ***ket***

*column vectors* from concrete calculations correspond to kets like $a|0\rangle+b|1\rangle = \begin{pmatrix}a \\ b\end{pmatrix}$
- note that vectors can alternatively be represented as *rows* like $\begin{pmatrix}a & b\end{pmatrix}$

also note that a *row vector* is the **transpose** of a *column vector* $\begin{pmatrix}a & b\end{pmatrix} = \begin{pmatrix}a \\ b\end{pmatrix}^T$
- however in quantum mechanics we always use the *conjugate transpose* which not only swaps rows/columns, but also **takes the conjugate of every number**.

###### the bra
if $|\psi\rangle$ is a ket with $|\psi\rangle = a|0\rangle+b|1\rangle$, then it's *conjugate transpose* is called a *bra*, written $\langle\psi|$
- $\langle\psi| = \overline{a}\langle0|+\overline{b}\langle1|$
- if $|\psi\rangle=\begin{pmatrix}a \\ b\end{pmatrix}$, then $\langle\psi|=\begin{pmatrix}\overline{a} & \overline{b}\end{pmatrix}$

###### inner product
the *inner product* is like the **scalar product of 2 vectors**, but including *conjugation*.
- e.g. the inner product of $|\psi\rangle=a|0\rangle+b|1\rangle$ and $|\phi\rangle=c|0\rangle+d|1\rangle$  is $a\overline{c}+b\overline{d}$
- this is written as $\langle\phi|\psi\rangle$ and is called a *bra*-**ket**
concretely, this is effectively just a matrix product $\begin{pmatrix}\overline{c} & \overline{d}\end{pmatrix}\begin{pmatrix}a \\ b\end{pmatrix}$
where the result is a 1x1 matrix we treat as a scalar.

###### outer product
it's also possible to combine a **bra** and a **ket** in the opposite order, e.g.
$|\phi\rangle\langle\psi| = \begin{pmatrix}a \\ b\end{pmatrix}\begin{pmatrix}c & d\end{pmatrix} = \begin{pmatrix}ac & ad \\ bc & bd\end{pmatrix}$

###### combining inner with outer product
what happens if we add another **ket**?
$(|\phi\rangle\langle\psi|)|\theta\rangle = |\phi\rangle\langle\psi|\theta\rangle = \begin{pmatrix}ac & ad \\ bc & bd\end{pmatrix}\begin{pmatrix}e \\ f\end{pmatrix} = \begin{pmatrix}ace+adf \\ bce+bdf\end{pmatrix} = \begin{pmatrix}a \\ b\end{pmatrix}(ce+df)$