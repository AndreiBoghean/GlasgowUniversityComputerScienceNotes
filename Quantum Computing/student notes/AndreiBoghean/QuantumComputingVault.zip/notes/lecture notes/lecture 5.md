dnote: lecture 5 was catch-up for lecture 4. there's only 1 new slide of content:
### calculating probabilities in quantum teleportation
![[Pasted image 20250209171004.png]]