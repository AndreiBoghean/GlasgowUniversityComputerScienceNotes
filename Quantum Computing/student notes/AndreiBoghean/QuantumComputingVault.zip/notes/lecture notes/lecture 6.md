### grover's algorithm
grover's algorithm is often described as an algorithm for **search** in an *unstructured database*
it provides a quadratic speedup compared with a classical algorithm:
- O($\sqrt{N}$) instead of O($N$)
sadly not the exponential improvement you may want, but improvement nonetheless.
#### the problem
imagine an *unknown* **function** f, with n bool imputs and one bool output.
$$f:\{0,1\}^n\rightarrow\{0,1\}$$
the **input** can be *considered* as a **vector** of size *n*

assume there is *one* **particular** *input* vector $w$ for which the **output** is *1*.
all the **other input** vectors *produce* an **output** of *0*.

the whole problem is that of finding this vector, $w$
- this can be *interpreted* as a **database search** problem.
	**e.g.** a telephone directory for  16 people with a *4 bit binary number*
	- executing a reverse lookup, the output is **1** only if the *input number* (the "vector") is the **correct number** of the **person** we're *trying to find*.
	- the records are *not stored in order* of **phone #,** hence this is an *unstructured lookup*

##### complexity of classical attempt
let $N=2^n$, thus making $N$ the size of the search space.
clearly, in the worst case, we have to *evaluate* **f** on $N-1$ input vectors
so the complexity is $O(N)$
- editor's note: on average the complexity is actually $N/2$, but the constant is removed?
##### quantum version
###### unitary operator for f
grover's requires an implementation for *f* as a **unitary operator** $U$.
we can define $U$ by
$$\begin{align}
U|x\rangle = -|x\rangle\text{ if }f(x)=1 \\
U|x\rangle = +|x\rangle\text{ if }f(x)=0\end{align}$$
- here we are thinking of $|x\rangle$ as being one of the *standard basis states* of all the **possible states** for $n$ qbits.
e.g. if n=1 and f(0)=1 then $U=\begin{pmatrix}-1 & 0 \\ 0 & 1\end{pmatrix}$
**exercise: why is U unitary?**
- because in this case it's invertible.
todo: convince yourself of this when you're revising this lecture.
editor's response: no.

###### diffusion operator prerequisite
before we use grover's *diffusion operator* **G**, we need to define $|s\rangle$ to be the uniform superposition of all $2^n$ standards basis states on n qbits: (notes that $N=2^n$ still)
$$|s\rangle = \frac{1}{\sqrt{N}}\Sigma^{N-1}_{x=0}|x\rangle$$
e.g. if n=2 then
$|s\rangle = \frac{1}{\sqrt{4}}(|00\rangle+|01\rangle+|10\rangle+|11\rangle)=\frac{1}{2}\begin{pmatrix}1 \\ 1 \\ 1 \\ 1 \end{pmatrix}$
###### diffusion operator
the grover *diffusion operator* is $G=2|s\rangle\langle s|-I$
e.g. if n=2 then
$$G = \frac{1}{2}\begin{pmatrix}-1 & 1 & 1 & 1 \\ 1 & -1 & 1 & 1 \\ 1 & 1 & -1 & 1 \\ 1 & 1 & 1 & -1 \\ \end{pmatrix}$$
###### the actual algorithm
1. *start* in **state** $|s\rangle$
2. *repeat* **r** amount of times... the application of **U** and then **G**
	- note that *r* is the **closest integer** to $\frac{\pi\sqrt{N}}{4}$ (this is why the complexity is O($\sqrt{N}$))
	- ^ e.g. in the telephone example where $N=2^n=2^4=16$, $r=\frac{\pi\sqrt{N}}{16}=\frac{\pi4}{4}=\pi=4$
3. *measure* all the qbits

at this point, with *high* **probability** (increasing with **N**), the state is now our answer $|w\rangle$

###### examples

**example with 1 bit**
with $n=1$ and $N=2^n=2$, we have $f:\{0,1\}\rightarrow\{0,1\}$
assume $f(0)=0$ and $f(1)=1$, meaning that *target* $|w\rangle=\begin{pmatrix}0 \\ 1\end{pmatrix}$
and the quantum implementation of f is $U=\begin{pmatrix}1 & 0 \\ 0 & -1\end{pmatrix}$
lastly we note that, for 2 bits, $G=\begin{pmatrix}0 & 1 \\ 1 & 0\end{pmatrix}$

we **start** in *state* $|s\rangle = \frac{1}{\sqrt{2}}(|0\rangle+|1\rangle) = \frac{1}{\sqrt{2}}\begin{pmatrix}1 \\ 1\end{pmatrix}$
we note that r = $\frac{pi\sqrt{2}}{4} ~= 1.11$, so we do 1 iteration.
applying U means our state becomes $\frac{1}{\sqrt{2}}\begin{pmatrix}1 & 0 \\ 0 & -1\end{pmatrix}\begin{pmatrix}1 \\ 1\end{pmatrix} = \frac{1}{\sqrt{2}}\begin{pmatrix}1 \\ -1\end{pmatrix}$
now G changes our state to $\frac{1}{\sqrt{2}}\begin{pmatrix}0 & 1 \\ 1 & 0\end{pmatrix}\begin{pmatrix}1 \\ -1\end{pmatrix} = \frac{1}{\sqrt{2}}\begin{pmatrix}-1 \\ 1\end{pmatrix}$

a measurement now gives either $\begin{pmatrix}1 \\ 0\end{pmatrix}$ or $\begin{pmatrix}0 \\ 1\end{pmatrix}$ with a **50/50** *chance of correctness*.
more iterations doesnt help :(

**example with 2 bits**
with $n=2$ and $N=2^n=4$, we have $f:\{0,1\}^2\rightarrow\{0,1\}$
assume $f(0, 0)=1$, meaning that *target* $|w\rangle=\begin{pmatrix}1 \\ 0 \\ 0 \\ 0\end{pmatrix}$
and the quantum implementation of f is $U=\begin{pmatrix}-1 & 0 & 0 & 0 \\ 0 & 1 & 0 & 0 \\ 0 & 0 & 1 & 0 \\ 0 & 0 & 0 & 1\end{pmatrix}$
lastly we note that G here is $\frac{1}{2}\begin{pmatrix}-1 & 1 & 1 & 1 \\ 1 & -1 & 1 & 1 \\ 1 & 1 & -1 & 1 \\ 1 & 1 & 1 & -1\end{pmatrix}$

we **start** in *state* $|s\rangle = \frac{1}{\sqrt{4}}(|00\rangle+|01\rangle+|10\rangle+|11\rangle) = \frac{1}{2}\begin{pmatrix}1 \\ 1 \\ 1 \\ 1\end{pmatrix}$
we note that r = $\frac{pi\sqrt{2}}{4} ~= 1.11$, so we do 1 iteration.
applying U means our state becomes $\frac{1}{2}\begin{pmatrix}-1 & 0 & 0 & 0 \\ 0 & 1 & 0 & 0 \\ 0 & 0 & 1 & 0 \\ 0 & 0 & 0 & 1\end{pmatrix}\begin{pmatrix}1 \\ 1 \\ 1 \\ 1\end{pmatrix}=\begin{pmatrix}-1 \\ 1 \\ 1 \\ 1\end{pmatrix}$
and then G changes our state to $\frac{1}{2}\begin{pmatrix}-1 & 1 & 1 & 1 \\ 1 & -1 & 1 & 1 \\ 1 & 1 & -1 & 1 \\ 1 & 1 & 1 & -1\end{pmatrix}\frac{1}{2}\begin{pmatrix}-1 \\ 1 \\ 1 \\ 1\end{pmatrix}=\begin{pmatrix}1 \\ 0 \\ 0 \\ 0\end{pmatrix} = |w\rangle$
this is a **special case** for 2 bits: gover's algorithm transforms the state to $|w\rangle$ after a single iteration.

**example with 3 bits**
with $n=3$ and $N=2^n=8$, we have $f:\{0,1\}^3\rightarrow\{0,1\}$
- editor's note: 8x8 matrices in latex. ouch :(
assume $f(0, 0, 0)=1$, meaning that *target* $|w\rangle = \begin{pmatrix}1 & 0 & 0 & 0 & 0 & 0 & 0 & 0 \end{pmatrix}$
and the quantum implementation of f is $U=\begin{pmatrix}-1 & 0 & 0 & 0 & 0 & 0 & 0 & 0 \\0 & 1 & 0 & 0 & 0 & 0 & 0 & 0 \\ 0 & 0 & 1 & 0 & 0 & 0 & 0 & 0 \\ 0 & 0 & 0 & 1 & 0 & 0 & 0 & 0 \\ 0 & 0 & 0 & 0 & 1 & 0 & 0 & 0 \\ 0 & 0 & 0 & 0 & 0 & 1 & 0 & 0 \\ 0 & 0 & 0 & 0 & 0 & 0 & 1 & 0 \\ 0 & 0 & 0 & 0 & 0 & 0 & 0 & 1\end{pmatrix}$
lastly we note that G here is $\frac{1}{4}\begin{pmatrix}-3 & 1 & 1 & 1 & 1 & 1 & 1 & 1 \\ 1 & -3 & 1 & 1 & 1 & 1 & 1 & 1 \\ 1 & 1 & -3 & 1 & 1 & 1 & 1 & 1 \\ 1 & 1 & 1 & -3 & 1 & 1 & 1 & 1 \\1 & 1 & 1 & 1 &  -3 & 1 & 1 & 1 \\ 1 & 1 & 1 & 1 & 1 & -3 & 1 & 1 \\ 1 & 1 & 1 & 1 & 1 & 1 & -3 & 1 \\ 1 & 1 & 1 & 1 & 1 & 1 & 1 & -3\end{pmatrix}$

we **start** in *state* $|s\rangle = \frac{1}{2\sqrt{2}}(|000\rangle+|001\rangle+|010\rangle+|011\rangle+|100\rangle+|101\rangle+|110\rangle+|111\rangle) = \frac{1}{2\sqrt{2}}\begin{pmatrix}1 \\ 1 \\ 1 \\ 1 \\ 1 \\ 1 \\ 1 \\ 1\end{pmatrix}$
we note that r = $\frac{pi\sqrt{8}}{4} ~= 2.21$, so we do 2 iterations.
applying U means our state becomes $\frac{1}{2\sqrt{2}}\begin{pmatrix}-1 & 0 & 0 & 0 & 0 & 0 & 0 & 0 \\0 & 1 & 0 & 0 & 0 & 0 & 0 & 0 \\ 0 & 0 & 1 & 0 & 0 & 0 & 0 & 0 \\ 0 & 0 & 0 & 1 & 0 & 0 & 0 & 0 \\ 0 & 0 & 0 & 0 & 1 & 0 & 0 & 0 \\ 0 & 0 & 0 & 0 & 0 & 1 & 0 & 0 \\ 0 & 0 & 0 & 0 & 0 & 0 & 1 & 0 \\ 0 & 0 & 0 & 0 & 0 & 0 & 0 & 1\end{pmatrix}\begin{pmatrix}1 \\ 1 \\ 1 \\ 1 \\ 1 \\ 1 \\ 1 \\ 1\end{pmatrix}=\begin{pmatrix}-1 \\ 1 \\ 1 \\ 1 \\ 1 \\ 1 \\ 1 \\ 1\end{pmatrix}$
and then G changes our state to $\frac{1}{4*2\sqrt{2}}\begin{pmatrix}-3 & 1 & 1 & 1 & 1 & 1 & 1 & 1 \\ 1 & -3 & 1 & 1 & 1 & 1 & 1 & 1 \\ 1 & 1 & -3 & 1 & 1 & 1 & 1 & 1 \\ 1 & 1 & 1 & -3 & 1 & 1 & 1 & 1 \\1 & 1 & 1 & 1 &  -3 & 1 & 1 & 1 \\ 1 & 1 & 1 & 1 & 1 & -3 & 1 & 1 \\ 1 & 1 & 1 & 1 & 1 & 1 & -3 & 1 \\ 1 & 1 & 1 & 1 & 1 & 1 & 1 & -3\end{pmatrix}\begin{pmatrix}-1 \\ 1 \\ 1 \\ 1 \\ 1 \\ 1 \\ 1 \\ 1\end{pmatrix}=\frac{1}{8\sqrt{2}}\begin{pmatrix}10 \\ 2 \\ 2 \\ 2 \\ 2 \\ 2 \\ 2 \\ 2\end{pmatrix}$
at this point, the probability of getting $|w\rangle$ from a measurement is $\frac{100}{128}$ ~= 0.78

our second iteration gives us $\frac{1}{32\sqrt{2}}\begin{pmatrix}-3 & 1 & 1 & 1 & 1 & 1 & 1 & 1 \\ 1 & -3 & 1 & 1 & 1 & 1 & 1 & 1 \\ 1 & 1 & -3 & 1 & 1 & 1 & 1 & 1 \\ 1 & 1 & 1 & -3 & 1 & 1 & 1 & 1 \\1 & 1 & 1 & 1 &  -3 & 1 & 1 & 1 \\ 1 & 1 & 1 & 1 & 1 & -3 & 1 & 1 \\ 1 & 1 & 1 & 1 & 1 & 1 & -3 & 1 \\ 1 & 1 & 1 & 1 & 1 & 1 & 1 & -3\end{pmatrix}\begin{pmatrix}-10 \\ 2 \\ 2 \\ 2 \\ 2 \\ 2 \\ 2 \\ 2\end{pmatrix}=\frac{1}{32\sqrt{2}}\begin{pmatrix}44 \\ -4 \\ -4 \\ -4 \\ -4 \\ -4 \\ -4 \\ -4\end{pmatrix}$
which has a probability of $\frac{1936}{2048}$ ~= 0.95 for getting $|w\rangle$.
remember our value for r was roughly 2, so we stop iterating here.

*with a third iteration*, we would get
$\frac{1}{8\sqrt{2}}\begin{pmatrix}-3 & 1 & 1 & 1 & 1 & 1 & 1 & 1 \\ 1 & -3 & 1 & 1 & 1 & 1 & 1 & 1 \\ 1 & 1 & -3 & 1 & 1 & 1 & 1 & 1 \\ 1 & 1 & 1 & -3 & 1 & 1 & 1 & 1 \\1 & 1 & 1 & 1 &  -3 & 1 & 1 & 1 \\ 1 & 1 & 1 & 1 & 1 & -3 & 1 & 1 \\ 1 & 1 & 1 & 1 & 1 & 1 & -3 & 1 \\ 1 & 1 & 1 & 1 & 1 & 1 & 1 & -3\end{pmatrix}\begin{pmatrix}44 \\ -4 \\ -4 \\ -4 \\ -4 \\ -4 \\ -4 \\ -4\end{pmatrix}=\frac{1}{128\sqrt{2}}\begin{pmatrix}104 \\ -56 \\ -56 \\ -56 \\ -56 \\ -56 \\ -56 \\ -56\end{pmatrix}$
which yields a $\frac{10816}{32768}$ ~= 0.33 probability for $|w\rangle$, *emphasising the importance of respecting r*.

###### grover's algorithm is probabilistic
even when we stop after the correct count of iterations,
there's still a possibility that measurement yields the "wrong" result.

we can *check* whether the result is **correct** bu simply *testing* it with the **classical** f.
if we get the wrong result, we simply re-run the algorithm.
- the probability of measuring the wrong result twice in a row is much lower.

###### further analysis of grover's algorithm.
the first interesting point is that there are never any *complex amplitudes*.

however there are plenty of *negative* **amplitudes**.
this emphasises that amplitudes are not probabilities.
the role of the *negative amplitudes* in the **matrix multiplications** is important.

the second interesting point is that, in every quantum state vector, all the positions from the second onwards have the same value.

###### geometric view of grover's algorithm
consider the 3 bit case. *every state* is a **linear combination** of
$|w\rangle=(1,0,0,0,0,0,0,0)$ and $|t\rangle=\frac{1}{\sqrt{7}}(0,1,1,1,1,1,1,1)$
therefore every state is a vector in the plane with coordinate axes $|w\rangle$ and $|t\rangle$
![[Pasted image 20250209211910.png]]

each application of GU rotates the state vector towards $|w\rangle$ by an angle of $\theta=2\sin^{-1}\frac{1}{\sqrt{N}}$
the closest approach is after $r \approx \frac{\pi\sqrt{N}}{4}$ iterations,
and after that the state vector *overshoots* and starts **rotating away** from $|w\rangle$
(eventually coming back)

at the *closest approach*, the **angle between** the vectors is **less than $\theta$** (which depends on N) hence why the algorithm is *more accurate* with a **bigger N**.
![[Pasted image 20250209212357.png]]

