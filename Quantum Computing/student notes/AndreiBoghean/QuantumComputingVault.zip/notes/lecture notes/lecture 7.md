![[lecture 7 2025-02-03 11.06.20.excalidraw]]

### preface - how to measure in the "*diagonal basis*"
###### **conventionally**..
we're already familiar with quantum states $|0\rangle, |1\rangle, |+\rangle, \text{ and } |-\rangle$
and we can easily state the following:
*measuring* $|0\rangle$ or $|1\rangle$ gives the *same state*, definetly.
*measuring* $|+\rangle$ or $|-\rangle$ gives either $|0\rangle$ or $|1\rangle$, with probability $\frac{1}{2}$

###### **diagonally**..
it's also true that $|0\rangle = \frac{1}{\sqrt{2}}|+\rangle+\frac{1}{\sqrt{2}}|-\rangle$ and $|1\rangle=\frac{1}{\sqrt{2}}|+\rangle-\frac{1}{\sqrt{2}}|-\rangle$
with *this* definition, we can understand how **measuring in the diagonal basis** works.
*measuring* $|+\rangle$ or $|-\rangle$ gives the same state, definetly.
*measuring* $|0\rangle$ or $|1\rangle$ gives either $|+\rangle$ or $|-\rangle$, with probability $\frac{1}{2}$

### cryptography
traditional cryptography relies on a *shared secret key* for encryption and decryption.
e.g. *ceasar cipher*, where the **offset** is the *shared key*.

agreeing on the *shared key* requires you already have some **existing method** of *secure communication* to distribute the key.
- ultimately, a *physical meeting*.

#### classical cryptography
###### one-time pad cryptography
cryptography using a *one-time* **pad** can provide *perfect secrecy*
the key used is a *random binary sequence* the **same length as the message**.

*first*, you must ensure your messages are in the form of sequences of **binary digits**
*to encrypt*, **XOR each bit** of the message with the *corresponding bit* of the **key**
*to decrypt*, similarly **XOR each bit** of the message with the *corresponding bit* of the **key**
this all looks like
- hello -> 01011 01001 11101 00101 10101
  $\oplus$ 1000 00101 01100 01100 01111
  = 00011 01100 10001 01001 11010 as encrypted message

for *highest security*, a **fresh key** should be used for *every message*
- keys are therefore a valuable and scarce resource.

###### symmetric cryptography
the one-time pad is a form of **symmetric cryptography**,
meaning that the same key is used for *encryption* **and** *decryption*.
- sidenote: other symmetric cryptosystems include AES and enigma.

one-time pad algorithms are *reciprocal* cryptosystems
- the *encryption* and *decryption* **algorithm are the same**.

###### public key cryptography
RSA uses two keys
1. the *public* key
   - the *product* of **two large prime numbers**
1. the *private* key
   - the *pair* of the **two prime numbers**.

**security** comes from the fact (or belief) that *factorising large numbers is computationally intractable*

there is however **no proof** that *large factorisation is computationally difficult*. 
- **factorisation isnt thought to be NP-complete**, so an efficient algorithm could theoretically be discovered without disrupting complexity theory, and in fact exists thanks to quantum shor's algorithm

#### quantum key distribution
this is a method for 2 parties to agree on a *shared key*, a binary sequence, *without meeting*.
this key can then be used as a *one-time pad* with **guaranteed secrecy**.

quantum key distribution (QKD) is much easier to implement than quantum algorithms.
##### BB84 - key distribution with quantum methods

###### the method
suppose alice and bob want to establish a **shared private key**

1. **alice** generates a *random sequence of bits*.
   - she represents each bit by a qbit using 1 of 2 schemes:
     (a) use the *standard* **basis** (0 encoded by $|0\rangle$, 1 encoded by $|1\rangle$)
     (b) use the *diagonal* **basis**  (0 encoded by $|+\rangle$, 1 encoded by $|-\rangle$)
	the scheme is chosen randomly for each bit.

2. **alice** *sends* the resulting *sequence of qbits* to **bob**, on a *public channel*
   - this is possible since, practically, qbits *could be* something such as **polarised photons**.

3. **bob** *receives* the sequence of qbits.
4. *for each qbit*, **bob** measures it **randomly**, *either* in the **standard** or **diagonal** basis.
   - if **bob** chose the *same basis* as **alice**, then the resulting bit is the *same as the original*.
   - if **bob** chose a *different basis* as **alice**, then the resulting bit is ***random***.
    ![[Pasted image 20250221174700.png]]

5. **bob** tells **alice** *publicly* his sequence of basis choices, and
   **alice** tells **bob** *publicly* which ones *match* her choices.

6. **bob** and **alice** now *know the positions* in the sequence *for which they should have the same bit values*
   ![[Pasted image 20250221175042.png]]

7. **alice** and **bob** now have a *shared binary sequence*, which they can use as their key for ***one-time pad cryptography***.
   - this sequence is, on average, **half the length** of the sequence of qbits that **alice** *generated originally*

###### security of BB84 during MITM
how does BB84 work in the context of an attacker?
1. the qbits are subject to *interception* or *manipulation* from **alice** to **bob**
2. for an undetected **MITM** approach, the attacker would somehow have to *copy the qbits* before forwarding them further to **bob**.
   - the attacker needs them so they can then *replicate the measurements* and *obtain the key*.

this of course does not work because of the ***no-cloning*** theorem.
the attacker could *maybe* resend **other** qbits, but then **alice** and **bob** shall observe *mis-matched bits in their produced key*, in spaces even when they **both used the same basis**.
- this is because the information of **Alice**'s *inital bit string* is **not known by the attacker**, so they *cant match the qbits alice initally sent*.
	  - even if they waited until **alice** *publicly revealed her chosen basis states*,
	    that still doesnt tell the attacker **alice**'s *inital bit string*.


however.. the resulting bit string is **private**. *how can alice and bob even find out they have different bit strings*?
- they must *publicly share* a **portion** *for comparison*.

after sacrificing enough bits, the **probability** of *attack detection* can be made *arbitrarily high*.

**alice** and **bob** will subsequently have to go through a further stage of ***authentication***,
to check that they are really talking to each other.
- this is *complicated and out of scope*.

###### security of BB84 during *any* attack
if an attacker, for example, captures **alice**'s *qbits*, **entangles them** with qbits he controls, and then sends them on to **bob**, could he then use this to *somehow reveal the key*?
- no. Mayers (2001) proved that **BB84 is secure** in the presence of an attacker who can do *anything allowed by the laws of physics*.

^ i.e. he proved ***unconditional security***

### aside: quantum randomness
according to von neumann, "anyone who *attempts to generate random numbers* by **deterministic means** is living in a *state of sin*"

conventional "*random numbers*" are typically **pseudo-random**, and potentially *seeded* with a **real random number**

for *true and based* **real random numbers**, you need a truly random ***physical process***.
- e.g. constructing $|+\rangle$ and measuring it.

