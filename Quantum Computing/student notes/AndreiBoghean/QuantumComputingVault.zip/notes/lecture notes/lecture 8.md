### entangled states with an alternative basis
###### refresher
recall that an entangled state is one such as $\frac{1}{\sqrt{ 2 }}(|00\rangle+|11\rangle)$
the defining feature being that the *qbits can not be factorised*.
this hence means when *one* qbit is measured, measuring the *other* qbit "*gives the same result*"

###### simple measurement with diagonal basis
how does this change when measuring in the **diagonal basis**?

since $|+\rangle=\frac{1}{\sqrt{ 2 }}(|0\rangle+|1\rangle)$ and $|-\rangle=\frac{1}{\sqrt{ 2 }}(|0\rangle-|1\rangle)$,
we can say that $\frac{1}{\sqrt{2}}(|00\rangle+|11\rangle) = \frac{1}{\sqrt{ 2 }}(|++\rangle+|--\rangle)$
- source: the math works out (see solutions for slide 3 of lecture 8.)

###### measurement with more complicated alternative basis
but measurement doesnt even have to be in the same basis.
what happens when *one qbit* is measured in the **standard** basis, and the other **diagonally**?

we can consider the basis $|a \rangle = \frac{\sqrt{ 3 }}{2}|0\rangle+\frac{1}{2}|1\rangle$, and $|b\rangle=-\frac{1}{2}|0\rangle+\frac{\sqrt{ 3 }}{2}|1\rangle$
and then say that $|0\rangle = \frac{3}{2\sqrt{ 3 }}|a\rangle-\frac{1}{2}|b\rangle$ and $|1\rangle= \frac{1}{2}|a\rangle+\frac{\sqrt{ 3 }}{2}|b\rangle$
- see [[lecture 7#preface - how to measure in the "*diagonal basis*"]]
- obtained using the below scribbles
![[lecture 8 2025-02-24 11.14.06 1 1.excalidraw|999]]
![[lecture 8 2025-02-24 11.14.06 1 1 1.excalidraw|999]]
![[lecture 8 2025-02-24 11.14.06 1.excalidraw|999]]



and then use this to calculate
$$\begin{align}
\frac{1}{\sqrt{ 2 }}(|00\rangle+|11\rangle)
&= \frac{1}{\sqrt{ 2 }}(|0\rangle(\frac{3}{2\sqrt{ 3 }}|a\rangle-\frac{1}{2}|b\rangle)+|1\rangle(\frac{1}{2}|a\rangle+\frac{\sqrt{ 3 }}{2}|b\rangle) \\

&= \frac{1}{\sqrt{ 2 }}(\frac{3}{2\sqrt{ 3 }}|0a\rangle-\frac{1}{2}|0b\rangle+\frac{1}{2}|1a\rangle+\frac{\sqrt{ 3 }}{2}|1b\rangle) \\

&= (\frac{3}{2\sqrt{ 2 }\sqrt{ 3 }}|0a\rangle-\frac{1}{2\sqrt{ 2 }}|0b\rangle+\frac{1}{2\sqrt{ 2 }}|1a\rangle+\frac{\sqrt{ 3 }}{2\sqrt{ 2 }}|1b\rangle) \\

&= (\frac{\sqrt{ 3 }}{2\sqrt{ 2 }}|0a\rangle-\frac{1}{2\sqrt{ 2 }}|0b\rangle+\frac{1}{2\sqrt{ 2 }}|1a\rangle+\frac{\sqrt{ 3 }}{2\sqrt{ 2 }}|1b\rangle) \\
\end{align}$$


where we can now measure either
1. the *first* qbit in the **standard basis**, leaving $\frac{\sqrt{ 3 }}{2}|0a\rangle-\frac{1}{2}|0b\rangle$ **or** $\frac{1}{2}|1a\rangle+\frac{\sqrt{ 3 }}{2}|1b\rangle$
   - with *corresponding probabilities* 3/4,1/4 **or** 1/4, 3/4
2. the *second* qbit in the **alternative basis**, leaving $\frac{\sqrt{ 3 }}{2}|0a\rangle+\frac{1}{2}|1a\rangle$ **or** $\frac{1}{2}|0b\rangle+\frac{\sqrt{ 3 }}{2}|1b\rangle$
   - with *corresponding probabilities* idk
the results are either biased to a in the case of 0, or biased to b in the case of 1.
and vice-versa when measuring the second qbit diagonally first.

### preface: tensor product of two matrices
if we have two 2x2 matrices (*unitary operators*) U and V, how can we calculate the 4x4 matrix that corresponds to *applying U and V simultaneously* to a 2-qbit state?

this is called the tensor produt $U \otimes V$, and it can be derived from first principles as follows:

let $U=\begin{pmatrix}a & b \\ c & d\end{pmatrix}$, and $V=\begin{pmatrix}s & t \\ u & v\end{pmatrix}$

applying $U \otimes V$ to $|0\rangle|0\rangle$ gives $(a|0\rangle+c|1\rangle)(s|0\rangle+u|1\rangle) = as|0\rangle|0\rangle+au|0\rangle|1\rangle+cs|1\rangle|0\rangle+cu|1\rangle|1\rangle$

this goes into the first column of the matrix for $U \otimes V$ like $\begin{pmatrix}as & . & . & . \\ au & . & . & . \\ cs & . & . & . \\ cu & . & . & .\end{pmatrix}$

using similar calculations, the whole matrix is filled out like $\begin{pmatrix}as & at & bs & bt \\ au & av & bu & bv \\ cs & ct & ds & dt \\ cu & cv & du & dv\end{pmatrix}$

which can be conveniently written as $\begin{pmatrix}aV & bV \\ cV & dV\end{pmatrix}$
### bell inequalities

john bell analysed the possible correlations between measurements on states such as $\frac{1}{\sqrt{ 2 }}(|01\rangle-|10\rangle)$. he discovered a way of proving that *quantum mechanics is not* a **local hidden-variable theory**.
- a *hidden variable* would be some other **property** of *particles*, which is **not included in quantum theory** but which *nevertheless influences the results* of measurements.
- *locality* meaning that **influences** between particles *cannot travel faster* than the **speed of light**.

finding a **local hidden-variable theory** that *reproduces the results of quantum mechanics* would be a way of **eliminating the mystery** of entanglement while *remaining consistent* with **relativity theory**.

#### a measurement scenario
1. **Alice** and **Bob** are in separate places. a **third person** prepares a *pair of particles*,
   and sends one each to **Alice** and **Bob**.
2. **Alice** chooses one of two possible measurements $A_{0}$ and $A_1$, at *random*.
3. **Bob** also chooses one of two possible measurements $B_{0}$ and $B_1$, at *random*.

all of the measurements have results +1 or -1.
suppose each measurement reveals the value of a property that the particle has
- the *hidden variable*
if we call these properties $a_0, a_{1}, b_{0},\text{ and } b_{1}$ and then arrange them like
$a_{0}b_{0}+a_{0}b_{1}+a_{1}b_{0}-a_{1}b_{1} = (a_{0}+a_{1})b_{0}+(a_{0}-a_{1})b_{1}$

therefore (on the right hand side), *one term* is **0** and *the other* is **+2**,
and hence either $a_{0}+a_{1}=0$ or $a_{0}-a_{1}=0$ (recall these variables are **either** +1 or -1)

if you *repeat this experiment endlessly*, the **absolute value of the average** is $\leq 2$

using angle brackets to denote averages, this becomes
$|\langle a_{0}b_{0}\rangle+\langle a_{0}b_{1}\rangle+\langle a_{1}b_{0}\rangle-\langle a_{1}b_{1}\rangle - \langle a_{1}a_{1}\rangle|\leq 2$
- this is a ***bell inequality***. (specifically the CHSH inequality)
- editor's note: WTF? u cant just "using angle brackets to denote averages". you must explain why. it's obvious there's a *reason* to "**use angle brackets**", because *later on* in [[#measurement scenario continuation]] these lecture slides **abuse quantum-ness** to combine $\langle A_{0}B_{0}\rangle$ with $|\psi\rangle$ into $\langle\psi|A_{0}\oplus B_{0}|\psi\rangle$ so clearly there's some *other meaning* here.

in an experiment to measure that sum,
any local hidden-variable theory **must** *produce a value less than or equal to* **2**

but with the right choice of $A_{0}, A_{1}, B_{0}, B_{1}$,
quantum mechanics *predicts a result greater than 2*, **violating the Bell inequality**.

###### quantum measurement "*observables*" and eigen
what we measure in quantum theory is an *observable*, which is a **unitary operator** with *certain extra properties*.

if **M** is an *observable*, then $M|v\rangle = \lambda |v\rangle$
- i.e. the possible results of measuring **M** are given by ***eigenvectors*** $|v\rangle$ and ***eigenvalues*** $\lambda$
- this might(?) be interpreted as $\lambda=M$, permitting that we *can* and *do* fully ***observe*** the *observable* M

#### pauli matrices deviation
###### standard basis
the observable corresponding to a standard basis measurement of a single qbit is given by the Pauli matrix $\sigma_{z} = \begin{pmatrix}1 & 0 \\ 0 & -1\end{pmatrix}$

we can check that $\begin{pmatrix}1 & 0 \\ 0 & -1\end{pmatrix} \begin{pmatrix}1 \\ 0\end{pmatrix} = \begin{pmatrix}1 \\ 0\end{pmatrix}$

and that $\begin{pmatrix}1 & 0 \\ 0 & -1\end{pmatrix}\begin{pmatrix}0 \\ 1\end{pmatrix} = \begin{pmatrix}0 \\ -1\end{pmatrix} = -\begin{pmatrix}0 \\ 1\end{pmatrix}$

so the eigenvectors are $|0\rangle=\begin{pmatrix}1 \\ 0\end{pmatrix}$ and $|1\rangle= \begin{pmatrix}0 \\ 1\end{pmatrix}$
with eigenvalues +1 and -1 respectively.

###### diagonal basis
the observable corresponding to a diagonal basis measurement of a single qbit is given
by the pauli matrix $\sigma_{x}=\begin{pmatrix}0 & 1 \\ 1 & 0\end{pmatrix}$

we can check that $\begin{pmatrix}0 & 1 \\ 1 & 0\end{pmatrix}\begin{pmatrix} \frac{1}{\sqrt{ 2 }} \\ \frac{1}{\sqrt{ 2 }}\end{pmatrix} = \begin{pmatrix}\frac{1}{\sqrt{ 2 }} \\ \frac{1}{\sqrt{ 2 }}\end{pmatrix}$

and that $\begin{pmatrix}0 & 1 \\ 1 & 0\end{pmatrix} \begin{pmatrix} \frac{1}{\sqrt{ 2 }} \\ -\frac{1}{\sqrt{ 2 }}\end{pmatrix} = \begin{pmatrix} \frac{1}{\sqrt{ 2 }} \\ -\frac{1}{\sqrt{ 2 }}\end{pmatrix}$

so the eigenvectors are $|+\rangle=\begin{pmatrix}\frac{1}{\sqrt{ 2 }} \\ \frac{1}{\sqrt{ 2 }}\end{pmatrix}$ and $|-\rangle= \begin{pmatrix} \frac{1}{\sqrt{ 2 }} \\ -\frac{1}{\sqrt{ 2 }}\end{pmatrix}$
with eigenvalues +1 and -1 respectively.

#### measurement scenario continuation
**Alice** has two possible *observables* to measure:
$A_{0}=\sigma_{z}=\begin{pmatrix}1 & 0 \\ 0 & -1\end{pmatrix}$, and
$A_{1}=\sigma_{x}=\begin{pmatrix}0 & 1 \\ 1 & 0\end{pmatrix}$

**Bob** has two possible *observables* to measure:
$B_{0} = -\frac{1}{\sqrt{ 2}}(\sigma_{x}+\sigma_{z})=\frac{1}{\sqrt{ 2 }}\begin{pmatrix}-1 & -1 \\ -1 & 1\end{pmatrix}$, and
$B_{1}=\frac{1}{\sqrt{ 2 }}(\sigma_{x}-\sigma_{z})=\frac{1}{\sqrt{ 2 }}\begin{pmatrix}-1 & 1 \\ 1 & 1\end{pmatrix}$

**small sidenote:**
	*we can check that the eigenvectors of $B_0$ are..*
	$\frac{1}{\sqrt{ 4-2\sqrt{ 2 } }}\begin{pmatrix}1-\sqrt{ 2 } \\ 1\end{pmatrix}$ with eigenvalue +1, and
	$\frac{1}{\sqrt{ 4+2\sqrt{ 2 } }}\begin{pmatrix}1+\sqrt{ 2 } \\ 1\end{pmatrix}$ with eigenvalue -1
	*we can also check that the eigenvectors of $B_1$ are*
	$\frac{1}{\sqrt{ 4-2\sqrt{ 2 } }}\begin{pmatrix}\sqrt{ 2 }-1 \\ 1\end{pmatrix}$ with eigenvalue +1, and
	$\frac{1}{\sqrt{ 4+2\sqrt{ 2 } }}\begin{pmatrix}-(1+\sqrt{ 2 }) \\ 1\end{pmatrix}$ with eigenvalue -1.

now, we want to calculate $|\langle A_{0}B_{0}\rangle+\langle A_{0}B_{1}\rangle+\langle A_{0}B_{1}\rangle+\langle A_{1}B_{0}\rangle-\langle A_{1}B_{1}\rangle |$
in the state $|\psi\rangle=\frac{1}{\sqrt{ 2 }}(|01\rangle-|10\rangle)$.

$\langle A_{0}B_{0}\rangle$ in state $|\psi\rangle$ is $\langle\psi|A_{0} \otimes B_{0}|\psi\rangle$
$= \frac{1}{\sqrt{ 2 }}\begin{pmatrix}0 & 1 & -1 & 0\end{pmatrix}(\frac{1}{\sqrt{ 2 }})\begin{pmatrix}-1 & -1 & 0 & 0 \\ -1 & 1 & 0 & 0 \\ 0 & 0 & 1 & 1 \\ 0 & 0 & 1 & -1\end{pmatrix} \frac{1}{\sqrt{ 2 }}\begin{pmatrix}0 \\ 1 \\ -1 \\ 0\end{pmatrix}$

$=\frac{1}{\sqrt{ 2 }}$


similar calculations give $\langle A_{0}B_{1}\rangle = \frac{1}{\sqrt{ 2 }}$, $\langle A_{1}B_{0}\rangle = \frac{1}{\sqrt{ 2 }}$, $\langle A_{1}B_{1}\rangle = -\frac{1}{\sqrt{ 2 }}$
and we find that $|\langle A_{0}B_{0}\rangle+\langle A_{0}B_{1}\rangle+\langle A_{0}B_{1}\rangle-\langle A_{1}B_{1}\rangle|=2\sqrt{ 2 }$

which is larger than the maximum under the assumptions for a local hidden-variable theory.
many experiments (originally by Alain Aspect et al. in 1982) have confirmed that the Bell inequality is violated.
quantum effects are real :D

