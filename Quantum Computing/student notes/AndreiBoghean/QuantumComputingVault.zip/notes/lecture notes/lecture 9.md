### errors and error correction
this is one of the biggest challenges for building **practical** quantum computers.
a qbit in a state $\alpha|-\rangle+\beta|1\rangle$ does not stay in that state forever.
effects such as *decoherence*, *noise*, and *environmental interference* can cause changes in the state or **collapse it** into a basis state.

this can affect both **communication** (*travelling* qbits) and **computation** (*stationary* qbits)

###### simple classical error correction: repetition
if you're sending bits over a **noisy** channel with a hypothetical proability *p* that a bit arbitrarily flips,
a simple workaround is to *send each bit* **three times**, telling the receiver to *take the majority*.

this error correcting code can correct a *single* bit flip in a **group** of *three bits*.
- any more error correction will henceforth fully flip the understood bit.

````col
```col-md
flexGrow=1
===
**encoding**
0 -> 000
1 -> 111
```
```col-md
flexGrow=1
===
**decoding**
000, 001, 010 -> 0
011 -> 1
100 -> 0
101, 110, 111 -> 1
```
````
note that this algorithm naturally doesnt work for quantum because *no-cloning*.
###### quantum error correction: bit flip code
**encoding**
we cant clone the qbits to repeat them, but we may repeat the basis states.
$\alpha|0\rangle+\beta|1\rangle \rightarrow \alpha|000\rangle+\beta|111\rangle$

![[Pasted image 20250210102041.png]]

**decoding**
to decode, we introduce 2 *ancilla* ("extra") qbits that are used for "*syndrome*" **measurements**
![[Pasted image 20250210102357.png|450]]

these subsequent measurements can then inform the application of **X** to correct the mistake.

| $m_0$ | $m_1$ | correction |
| ----- | ----- | ---------- |
| 0     | 0     | none       |
| 1     | 0     | X(x)       |
| 1     | 1     | X(a)       |
| 0     | 1     | X(b)       |

**exercise example**
![[lecture 9 2025-02-10 10.27.54.excalidraw|300]]

**breakdown:**
the CNOT between bit 1 and 2 tell us if they're equal.
similarly for 2 and 3.

logically,
if the *first* **measurement** differs then either of bits *1 or 2* were flipped
and if the *second* **measurement** differs then either bits *2 or 3* were flipped.

after this, we look at the the **other measurement**
if it *doesnt indicate a change*, then that means the **middle bit is still intact**,
so we know the "*edge*" bit was the one flipped in the *first* **measurement**.

if **both** measurements are *different*, then the **middle one** must've been flipped
and then that's the one we correct.

lastly, the original encoding can be reversed by applying the exact same encoding circuit
![[Pasted image 20250227150059.png]]
which will restore the auxillary and b to their original states of $|0\rangle$

note: here is diagram that includes the final classical conditioning.
![[Pasted image 20250210104909.png]]
###### phase flip errors
another kind of error in quantum *communication* is the **phase flip**.
this inverts the *relative phase* of the components of a single qbit superposition,
i.e. $\alpha|0\rangle+\beta|1\rangle \rightarrow \alpha|0\rangle-\beta|1\rangle$
- this type of failure of course **cant be corrected by a bit flip check**, because the *bits were unchanged*.

to correct a phase flip, we can re-frame the qbit phase as states,
by using **H** gates. the following circuit demonstrates this.
![[Pasted image 20250210105254.png|350]]

afterwards, we use H gates again to undo the re-framing and restore the original.

**full circuit**
![[Pasted image 20250210105513.png|400]]

**error correction modification table**
instead of conditional application of X, like is done in regular bit flip correction,
this correction applies Z, since the phase is being corrected rather than the bit.

| $m_0$ | $m_1$ | correction |
| ----- | ----- | ---------- |
| 0     | 0     | none       |
| 1     | 0     | **Z**(*x*) |
| 1     | 1     | **Z**(*a*) |
| 0     | 1     | **Z**(*b*) |

**example attempt**
![[lecture 9 2025-02-10 10.58.08.excalidraw|999]]