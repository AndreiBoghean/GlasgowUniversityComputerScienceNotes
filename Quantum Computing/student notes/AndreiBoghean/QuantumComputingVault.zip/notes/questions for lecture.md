what does the `matrix sub s` notation imply? is it that $\begin{pmatrix}a \\ b\end{pmatrix}_{s} = \begin{pmatrix}\ket{0} & \ket{1}\end{pmatrix}\begin{pmatrix}a \\ b\end{pmatrix}$?
followup: when we e.g. apply the matrix for X to this, does it go inbetween?
followup 2: how does H manage to affect the base?

on lecture 11 slide 8 should the column and row vectors not be swapped?

on lecture 11 slide 13 do you need to apply hadamard again at the end?
because when I tried the working I got the correct coefficients but they're in standard base, not diagonal. see below

![[questions for lecture 2025-04-16 16.23.49.excalidraw]]

if I have 2 operators **a** & **b** that convert to and from and arbitrary basis k
and I want to measure some standard state in that k basis
I should apply **b**? i.e. the operator that converts *from* k?
NOT a, the one that converts *to* k?
- followup question: 

----

in notes..
when you **have a in terms of 0** but *want 0 in terms of a*
- do that by ***substitution***

here..
when you **have a in terms of 0** but *want a in terms of +*
- do that by applying *0*->*+* ; simplifying ; applying *+*->*0*