# 1 hi
## 1.1 hi
### 1.1.1 hi
#### 1.1.1.1 hi
##### 1.1.1.1.1 hi
###### 1.1.1.1.1.1 hi

we can consider the basis $|a \rangle = \frac{\sqrt{ 3 }}{2}|0\rangle+\frac{1}{2}|1\rangle$, and $|b\rangle=-\frac{1}{2}|0\rangle+\frac{\sqrt{ 3 }}{2}|1\rangle$

and then say that $|0\rangle = \frac{\sqrt{ 3 }}{2}|a\rangle+\frac{1}{2}|b\rangle$ and $|1\rangle= -\frac{1}{2}|a\rangle+\frac{\sqrt{ 3 }}{2}|b\rangle$

and then use this to calculate
$$\begin{align}
\frac{1}{\sqrt{ 2 }}(|00\rangle+|11\rangle)
&= \frac{1}{\sqrt{ 2 }}(|0\rangle( \frac{\sqrt{ 3 }}{2}|a\rangle+\frac{1}{2}|b\rangle )+|1\rangle(-\frac{1}{2}|a\rangle+\frac{\sqrt{ 3 }}{2}|b) \\

&= \frac{\sqrt{ 3 }}{2\sqrt{ 2 }}|0a\rangle+\frac{1}{2\sqrt{ 2 }}|0b\rangle-\frac{1}{2\sqrt{ 2 }}|1a\rangle+\frac{\sqrt{ 3 }}{2\sqrt{ 2 }}|1b\rangle
\end{align}$$

![[Pasted image 20250422094554.png]]

https://moodle.gla.ac.uk/pluginfile.php/9637165/mod_resource/content/1/lecture2.pdf