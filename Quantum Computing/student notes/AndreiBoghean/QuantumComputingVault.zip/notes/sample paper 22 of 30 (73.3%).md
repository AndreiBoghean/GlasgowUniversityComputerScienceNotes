![[Pasted image 20250424165125.png]]

1 a 2/3
calculations are not instantaneously transferred because the transfer process includes the communication of classical bits, which itself is limited to how fast you can communicate classical bits to someone, which is not instant.

quantum computers can not break the RSA cryptosystem because it uses 2048 bits but shor's factorisation algorithm has only been implemented for arround 5 bits.

1 b 4/4
|000>

after H

|+00>
1/sq2 (|000> + |100>)

after cnot (x, y)
1/sq2 (|000> + |110>)

after X(x)
1/sq2 (|100> + |010>)

after cnot(y, z)
1/sq2 (|100> + |011>)

1 c 3/3
when measuring the first qbit, there is a 2 * (1/sq(3))^2 = 2/3 chance for 0
and a 2 * (1/sq6)^2 = 2/6 = 1/3 chance for 1.

if a 0 is measured, the remaining state is 1/sq(2) (|00> + |11>)
if a 1 is measured, the remaining state is  1/sq(2) (|01> + |10>)

1 d 2/3
when a basis is orthonormal, that means the basis states are normalised and subsequently all have a value of 1 when taking their dot product with themselves.
i.e. <psi+|psi+> = 1, which effectively means the basis state |psi+> has a 100% chance when on it's own

1 e 2/2
it is not entangled, because it is factorisable.
1/2 (|00> + |01> + |10> + |11>) =
1/2 (|0>(|0> + |1>) + |1>(|0> + |1>)) =
1/2 (|0> + |1>)(|0> + |1>)

2 a 5/7
1.
Alice and Bob have qubits a, b respectively.
ab = 1/sq(2) (|00> + |11>)

2.
Alice has qbit x in an unknown state
x = a|0> + b|1>

combining this with alice and bob's entangled qbits gives state
xab = (a|0> + b|1>)1/sq(2) (|00> + |11>) =
xab = a|0>1/sq(2) (|00> + |11>)  +  b|1>1/sq(2) (|00> + |11>) =
xab = 1/sq(2) (a|000> + a|011>)  +  1/sq(2) (b|100> + b|111>) =
xab = 1/sq(2)(a|000> + a|011> + b|100> + b|111>)

3.
alice applies CNOT(x, a)
xab = 1/sq(2)(a|000> + a|011> + b|110> + b|101>)

4.
alice applies H(x)
xab = 1/sq(2)(a|+00> + a|+11> + b|-10> + b|-01>)

xab = 1/sq(2)(
a/sq(2)(|0>+|1>)|00> + a/sq(2)(|0>+|1>)|11> +
b/sq(2)(|0>-|1>)|10> + b/sq(2)(|0>-|1>)|01>
)

xab = 1/sq(2)(
a/sq(2)(|000>+|100>) + a/sq(2)(|011>+|111>) +
b/sq(2)(|010>-|110>) + b/sq(2)(|001>-|101>)
)

xab = 1/2(
a|000> +a |100> + a|011> + a|111> +
b|010> - b|110> + b|001> - b|101>
)

5.
alice measures x with classical result m.
the questions states the result of m is 0.
this leaves
xab = 1/sq(2)( a |000> + a|011> + b|010> + b|001> )

6.
alice measures a with classical result n.
the question states the result of n is 1
this leaves
xab = a|011> + b|010>

7.
alice sends m and n to bob

8.
bob applies corrections; n->X(b) & m->Z(b)
m is 0 so no Z
n is 1 so apply X(b)
giving xab = a|010> + b|011>

2 b 1/2
x and a are not entangled. in all remaining states, x and a are the same. the only remaining difference is the value and phase of b.

2 c 2/2
no because the qbit a was measured in the process and is no longer entangled. a new entangled qbit in alice's possession would be needed.

2 d 1/4
re-interpreting the diagram with
a1 = a
b2 = b
a2 = c
c1 = d

if I have abc (00 11) 1/sq2 (0 1)
I get 1/2 (000 001 110 111)

I could try to undo the entanglement process on a & b
by H(b) then CNOT(b, a)

and then try to re-entangle a with c
by H(c) then CNOT(c, a)

however c is still entangled with d
so I want to have un-entangled that as well by H(b) CNOT(b, d)

actually, however, I cannot cnot between two remote quantum bits.
if I want to cnot (x, z), what I can first do is cnot(x, y)
and then quantum teleport y's state to z, effectively cnot-ing z.