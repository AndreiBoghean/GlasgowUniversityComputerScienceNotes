portrait A5 export at 100% scale
EXCEPT lecture 1, which is landscape A5 export at 85% scale

use browser print2pdf for all of these to put into 9 pages per page.