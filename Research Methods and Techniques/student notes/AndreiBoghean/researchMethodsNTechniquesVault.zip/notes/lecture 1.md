## what is research?
###### general description
research is a **focused investigation**, guided by specific *research questions*.
- this *investigation* is the **systematic process** of *gathering evidence*, to **test hypotheses**
- alternatively, the act of collecting and analysing data in order to understand something of interest.
###### phases of research

| step | key question                                                                            | generally..                                                                                                                                                                               |
| ---- | --------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| 1    | what do we want to achieve?<br><br>alternatively..<br>**what data** we are looking for? | - find out what is happening;<br>- develop something that works;<br>- evaluate a system/technology;<br>- compare systems (e.g. yours vs existing)<br>- change human behaviour             |
| 2    | **where** does the **data** come from?                                                  | - *how to collect* data?<br>    - read, observe, ask, measure, experiment, model, simulate, mathematical proof<br>- *where to collect* data?<br>    - field, lab, conceptual, theoretical |
| 3    | **what do we do** with the data?                                                        | - identify themes/patterns/quotes/etc<br>- calculate numbers<br>- identify trends<br>- create frameworks-taxonomies                                                                       |
| 4    | have we **achieved our goal**?                                                          | - draw conclusions<br>- evaluate results<br>- identify limitations                                                                                                                        |
the results of a research effort may subsequently lead to other research, **re-starting the process from step 1**
###### computing research methods

| method                     | detail                                                             | output                                | example                                                                                                                                                               |
| -------------------------- | ------------------------------------------------------------------ | ------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| *mathematical proof*       | proving a claim is true                                            | **proof**                             | prove that if L is a language, then $L^*=(L^*)^*$, where \* denotes closure operation, and $L^*$ is all words that can be constructed by concatenating elements of L. |
| *artefact creation*        | building something, measuring it's properties, characterising it   | an **object** and a description of it | an interactive system that presents multivariate data using three visualisation methods                                                                               |
| *hypothesis testing*       | running experiments                                                | **evidence**                          | compiler A is faster than compiler B by a factor of 1.5                                                                                                               |
| *modelling and simulation* | exploring complex systems; build model then simulate what happens. | **insight into a phenomenon**         | modelling and analysing a variety of communication services                                                                                                           |
###### research activities and outcomes

| #   | activity                                                 | notes                                                                        | outcome                                             |
| ---- | -------------------------------------------------------- | ---------------------------------------------------------------------------- | --------------------------------------------------- |
| 1   | read and **understand** a paper                          | read thoroughly and more than once                                           | understanding of the work                           |
| 2   | **summarise** a paper                                    | demonstrate that you understand it, it's key points, and conclusions         | annotated bibliography, notes                       |
| 3   | explain how **different papers relate** to each other    | agreements, contradictions, extensions, replications                         | literature review                                   |
| 4   | **identify a gap** in the literature                     | is it useful, relevant, important?                                           | research idea                                       |
| 5   | identify a **research question**                         | must be a clear and answerable question                                      | research question(s)                                |
| 6   | develop a research plan to address the research question | demonstrate feasibility - can you do it and do you have the right resources? | research proposal                                   |
| 7   | **execute** the research plan                            | multi-faceted. collaborate with others, supervise, learn more.               | data, frameworks, models, systems, algorithms, etc. |
| 8   | write and **publish papers**                             | journals, conference proceedings, etc.                                       | papers and presentations                            |
| 9   | **critically review** papers                             | peer review, discussing papers, etc.                                         | critique, suggestions, decision                     |
these steps all fall into distinct categories of the research process:
1. current knowledge (*1-3*)
2. finding your research idea (*4-6*)
3. executing your research idea (*7-8*)
4. being part of the community (*9*)

## what is science?
science is the *process* of **systematically studying** something, aiming to *identify a reasonable explanation* for it.
collectively over time, science gains knowledge that adds to an *accurate* representation of the world.

#### what is the scientific method?
it is a *philosophical framework* for "doing science"
- intended to produce results **objectively** and free from *bias and prejudice*
- not influenced by *personal feelings or opinions* in **considering and representing facts**

this framework outlines an *iterative* and *systematic* approach
1. collecting **evidence** from *experiments*
2. empirically *testing* beliefs against **data**
3. aiming for **valid** conclusions and **reasonable explanations**

#### scientific inference
inference is "a conclusion reached on the basis of **evidence** and **reasoning**"
*scientific* inference is the process of *reaching conclusions* based on available **evidence and theories**.
- we have some **premises**, from which we *logically* draw **conclusions**

##### deductive & inductive inference
###### **deductive** inference
an inference is **deductive** if there is  *relation between the premises and the conclusion* that **guarantees the truth** of the conclusion (if the premises are true)
- if the *premises hold*, the **inference and subsequently conclusion**, *also hold*.

###### **inductive** inference
an inference is **inductive** if we use the **premises we have** to draw conclusions about *similar but unobserved objects*
e.g.
1. Premise: the first five eggs in the box were fine to eat
2. Premise: all six eggs in the box have the same best-before date
3. Conclusion: therefore, the sixth egg in the box will also be fine to eat

##### inferences in science
###### practicality of inference types *in research*
we cannot test every possible input combination, evaluate each person, test every architecture, etc. therefore **deductive** inference is *typically infeasible* .

==in research, we mostly use **inductive** inference.==
- thus, we usually find ourselves observing a *sample* of a **population** in order to **draw conclusions** we can *generalise*

**however using inductive inference comes with a problem:**
david hume's *problem of induction*.
- when we use inductive inference, we *assume the uniformity of nature*
- hume argued ***induction** cannot be rationally justified*, but dw about it we use it anyways.

###### inference to the best explanation
*inference to the best explanation* tries to draw the **most plausible conclusion** from *observations*
- similar to **inductive inference** (both are ***non-deductive***)

how do we determine the "*best explanation*"?
- **occam's razer** - basically, *The explanation that requires the **fewest assumptions** is usually correct*.

###### causal inference
a common research goal is to explain what **causes** something.
- e.g. why is the text entry poor on touchscreens, or why are these instructions slow on this architecture?

causal inference is the act of using inference to reason about the **cause** of something.
- note that this is classified as *inference* because we can detect **something has been caused**, but *cannot detect* **what caused it**.

but causal inference is subject to the ==**correlation**/*causation* pitfall==.
- correlation does not imply causation.
- observing a **correlation** between X and Y does not mean X *caused* Y.
	  - e.g. *generally poor text entry* on **touchscreens** does ==not necessarily mean== **touchscreens** cause *poor text entry*


to avoid the pitfall, you may use a **controlled experiment** to *support your causal inference*.
- you **control** for factors that *may influence* our variable of interest.
- by controlling, we can **isolate** the interesting variable.
	  - this allows us to *draw conclusions across variables*, i.e. comparing the **treatment** group with the **control** group
- *if there is a difference between* the **treatment** and **control**, any conclusions can be drawn with **relative safety** since we've **made efforts to guarantee** *any changes are only affected by the changing of a single variable*.

e.g.
1. we want to investigate if small button sizes cause poor touchscreen text entry
2. we design an experiment to compare large buttons to small buttons on a touchscreen
3. participants get assigned either to the (large) control group or (small) treatment group
4. assuming all else is equal, by comparing the groups, we're effectively investigating if small keyboard buttons *specifically* cause **poor text entry**

problem: **it's hard to fully control for all variables**.
- the treatment group may have inexperienced users, people with minute physiological differences, etc, all of which can subtly influence the experiment.
solutions:
- *randomised control trials* - participants placed in groups at **random**
- *repeated measure experiments* - participants experience **all conditions**, *if possible*

##### in summary..
inference - reaching **conclusions** through *evidence* and *reasoning*
- ==inductive inference== : drawing conclusions on **unobserved** objects via *observations on similar objects*. challenged by *the uniformity principle* which **cant be assumed**.
- ==inference to the best explanation== : applying **occam's razor** to *inductive inference*.
- ==causal inference== : inferring what *causes* something to occur.
	  - **correlation does not imply causation**; should use *controlled experiments* to account for this.

#### scientific hypothesis
the scientific method follows the following process:
1. **Observe** something you *wish to explain*
2. **Formulate a hypothesis** to *explain and predict* that thing
3. **gather evidence** from a scientific *experiment*
4. **test** the hypothesis against the *empirical evidence*

###### what is a hypothesis?
it's a **specific** and **testable** explanation for a phenomena.
- ==specific== : explains *what you expect to happen* in a certain circumstance
- ==predictive== : *makes a prediction* that **can** *be empirically tested*.
- ==testable== : is *falsifiable* (and hence can be disproven)
- ==parsimonious== : is as **simple** *as* **feasible**. (occam's razor)

it attempts to predict a relationship between *independent* and *dependent* **variables**.
- these are covered in [[lecture 4#preface independent and dependent variables]]
###### what does a hypothesis do?
it attempts to **explain an observation** that *cannot be described*.
- it's an informed guess about the **cause** of the phenomena.

it aims to allow *predictions* about unobserved entities,
that can be **tested** against *empirical data* from experiments

###### hypothesis vs theory
hypotheses and theories are not the same.
- a scientific **hypothesis** is a *testable prediction*
- a scientific **theory** is a hypothesis that's *already been proven* by testing.
	  - i.e. the predictions were *empirically validated*.

###### example hypotheses
**H1** - if I *eat 500 less kcal* per day, I will **loose weight**
- specific: yes ("if I do x")
- predictive: yes ("I will loose weight")
- testable: yes (by weighing myself)
- parsimonious: yes (no unnecessary details)
- **explains an observation**: "*I dont loose weight because I eat too much*"

**H2** - if I *drink coffee* before going to lectures, I'll **take more notes**
- specific: yes ("if I do x during condition y")
- predictive: yes ("I will take more notes")
- testable: yes (I have comparatively more notes)
- parsimonious: yes (no unnecessary details)
- **explains an observation**: "*I dont take many notes because I'm tired*"

**H3** - if you *turn the thermostat down*, your **gas bill will be lower**
- specific: yes ("if I do x")
- predictive: yes ("gas bill will be lower")
- testable: yes (by checking gas bill)
- parsimonious: yes (no unnecessary details)
- **explains an observation**: "*bill is high because the thermostat is high*"

**H4** - if you *practice reading french* for an extra 15 minutes per day and *wear red socks*, your **french reading level will improve**
- specific: yes (if I do x)
- predictive: yes ("will get better french")
- testable: yes (french is better)
- parsimonious: no (red socks is potentially unnecessary.)
- **explains an observation**: "*I'm not getting better because I'm not practicing*"

###### summary on scientific hypothesis & method
it's an **iterative** process aiming to develop **accurate** explanations.
1. begin with **observations** that *cannot be adequately explained* with current info
2. construct a **hypothesis** that *offers an explanation* (granted it is true)
3. use **experiments** to *gather empirical data to test the hypothesis*
4. if the test fails.. **modify** the hypothesis and *repeat the process*.

#### scientific experiments
**experiments** gather empirical data to test hypotheses against.

recall from earlier that if we want to make **valid use of inference**, we need to use *carefully controlled experiments*

experiment designs vary, especially in computer science, but all serve the same purpose.
- ==gathering data against which we can test our hypotheses==.

###### how to use experiment data?
we apply **inductive inference**.
- since we cannot have data about every entity, but can observe a representative *sample* from which we can **obtain generalisable results** for the *rest of the unobserved population*

often you may use [[lecture 6#inferential statistical analysis]] to test hypotheses
- e.g. did variance in data occur by chance or because of our experiment?
- a form of causal inference, trying to ensure our variables are properly controlled.

#### overall summary:
==scientific method== : general principles and processes for testing beliefs using empirical data from experiments
1. gather **data** to *test your hypotheses*
2. use **inference** to *reach conclusions from the data*
3. provide **objective and valid answers** to *research questions*

this here framework is foundational for the rest of the course.
- critically engaging with research papers - are the findings robust?
- designing your own experiments - is the data sound?
- analysing your experiment data - are the results valid?