# experiment design 1
## converting hypotheses into experiment design
### converting hypotheses into an experiment design
#### preface: independent and dependent variables
##### independent variables (IVs)
IVs are *factors* that are **controlled/manipulated** by the *experimenter*.
- they often relate to the thing you've designed, e.g. algorithm/interaction/system
- note that their values are usually referred to as "==levels==" so alg A vs alg B has 2 levels.

these variables are **categorical**, with *different levels*.
- e.g. Algorithm **A** vs algorithm **B** (or e.g. audio with low/med/high background noise)

IVs subsequently ==*determine your experiment conditions*==
- e.g. {(A, low), (A, med), (A, high), (B, low), (B, med), (B, high)}
##### dependent variables (DVs)
these are *factors* that are *not* **controlled/manipulated**.
they are **dependent** on the *environmental conditions*.

dependency implies a **causal** relationship.
you can test if *independent variables* **cause outcomes** in *dependent variables*.
- e.g. *magic pointing* causes **faster selection times**
- e.g. *super search rank* causes **improved relevance**
- e.g. *super sort* causes **faster sort times**

you can use ==inferential statistical analysis== to test. see [[lecture 6#inferential statistical analysis]]
##### examples
###### hypothesis example 1
the *magic pointing technique* will lead to significantly faster **target selection times** than conventional *ray-case pointing*
*IV*: interaction technique (ray-cast vs magic pointing)
**DV**: target selection time
###### hypothesis example 2
the *super search rank algorithm* will improve **perceived relevance ratings** of search results.
*IV*: ranking algorithm (baseline vs super search rank)
**DV**: document relevancy judgements
###### hypothesis example 3
the *super sort algorithm* will be **faster** than *quicksort*.
*IV*: sort algorithm (quicksort vs super sort)
**DV**: sort execution time
#### correlation between hypotheses and experiment design
hypotheses make *predictions* in terms of **independent and dependent** variables.
- the subsequent experiment **attempts** to *fairly* test the predictions.

well-designed experiments enable *fair comparison*.
- we want to isolate our factors of interest (using **experimental control**)
- **control** helps *minimise confounding factors*

## experiment design focusing on control
### preface: confounding factors ==and fairness==
confounding factors may lead to **incorrect conclusions**.
- e.g. did *magic pointing* cause faster **selection time** or was it because ==task targets were positioned closer to the cursor than for baseline==
- e.g. did *super search rank* cause improved **relevance** or did ==the users issue less complex queries than for the baseline tasks?==
###### identifying confounds
suppose a hypothesis "the super sort algorithm will be faster than quicksort"
we need to design a **==fair experiment==** to compare these.

what would an **unfair** comparison be like?
- implemented in different languages
- execution on different computers
- varying input sets
- test inputs biased to one algorithm
- one algorithm was run at the same time the experimenter was playing apex
- one algorithm was mistakenly run in power saving mode

^ ==these are all *confounds*==

how could we mitigate them? simply - you *must be aware of them and take the necessary steps*.
- the problem is usually concerning the thinking of all the potential confounds

### controlled experiment design
the idea of running a **controlled** experiment design hinges on *managing these confounding factors*.
- controlling confounds leads to a ==fairer experiment==

you need to identify ways of mitigating confounding effects
- by minimising their effect, we aim to **reduce their impact** on data.

however *some things cannot be anticipated or controlled*
- **random variables**
- things whose values change randomly or in unpredictable ways.
	  - e.g. people, skill levels, intelligence, motor control skills

## summary so far
experiments *test the predictions* made by hypotheses.
- by collecting empirical data to test if the data supports their predictions.

experiment variables glossary:
- ==independent== variables - those you **systematically manipulate**
- ==dependent== variables - those you **measure**
- ==control== variables - those you *control* to **reduce confounds** and influence on the DV
- ==random== variables - those you **cannot control**
## experiment design for usefulness (generalisability)
#### generalisation
an experiment needs to **lead to generalisable findings**
- if your results only apply to your condition, it's useless to others.

**conclusions** should be *widely applicable*
- is magic pointing faster *in general*? or just specifically?
- is super search rank *generally better*? or just specifically?

this is all *necessary* for **inductive inference**
- since cant evaluate new input device with every person alive;
  we **need** generalisable results *if we want to inductively infer to others*.

so basically, make sure to pick an *appropriate sample of inputs*
- there **may** be instances where the algorithm is *faster*
- there **may** be instances where the algorithm is *slower*
this intends to pick a sample set representative of the general case.
#### sample selection
**subject**: entities in an experiment (people, images)
**population**: the set of all subjects (all people, all images)
**sample**: the set of subjects in an experiment

as aforementioned, generalisation requires a ==representative sample==
- inductive inference - observe entities to extrapolate findings to "like" entities
- i.e. ensure the sample is representative of the population

###### sample selection examples
"CV" uses **sets of images** to draw general conclusions about how recognition algorithms perform on *most images*
- considerations: images representative of the intended use case?
	  - e.g. self-driving car sensors or variety of backgrounds and lighting conditions?

"HCI" uses **groups of participants** to draw general conclusions about how *most people* will interact with technology
- considerations: people representative?
	  - e.g. people with *visual impairments* or different *physiological or perceptual response*?

![[Pasted image 20250424202447.png]]
## within- vs between- subject designs
some experiments hinge on exposing subjects to circumstances and investigating their behaviour.
- this is a **within-subject** design.

however, in home experiments you may have problems with exposing the same subject to multiple circumstances.
instead, you may choose to *expose subject **a** to circumstance **1**, and **b** to **2*** and compare. this is a **between-subject** design.
### what these concepts are
###### within-subject design
**subjects exposed to all conditions.** (all *levels* of the independent variable)
- a.k.a. repeated-measures design, because you *repeat the measurement* for every condition
###### between-subject design
subjects placed into *groups*; **each group exposed to one condition**.
- a.k.a. independent-measures design, since *measurements are independent* 4 each condition
### comparing concept differences
within-subject designs are less common in other fields
- e.g. in medicine, the participants cannot really take the *treatment and control drug together*

between-subject designs are **typically necessary in other fields because** the subjects can ==reasonably only be exposed to one of the conditions==

in computing science, within-subject designs are more common because
- digital systems can be *reset easily* to their **initial state**
- human subjects are minimally affected by the experiment
	  - e.g. the "lasting effects" of one interaction technique are kinda limited.
### advantages/disadvantages
###### within-subject advantages
within-subject designs are *sometimes fairer*.
- reduces **confounding effects of subject properties**.

within-subject designs are typically *cheaper and easier*
- if recruiting x humans on y conditions, you get x\*y experiments
  whereas with between-subject, you only get x number of experiments, since y is forced to 1 as per the nature of within-subject. meaning you need y\* more subjects for the same amount of experiments.

###### within-subject disadvantages
**within-subject designs are subject to ==order effects==**
- where the order of experimentation may potentially impact DVs.
- most common in experiments with human participants who respond to stimulus (learn, get bored, etc.) but also possible in machines e.g. those who cache execution.

the most common order effect that you'll likely have to deal with are **learning effects**.
- when experiment participants *gain knowledge and experience* that benefits the conditions.
- e.g. participants performing better l8r as they *learn how to use an interface*
## order effects
### order effects
order effects are a phenomenon arising from experiments where the order of conditions has a potential impact on the DVs.

![[Pasted image 20250425104329.png]]
- learning occurs during the *first condition*, so performance naturally improves in the **second**.
==**this can then lead to variance in our dependent variable**==

##### dealing with them
###### randomising
*presenting conditions* in **random order** for each participant
may **distribute the order effect across conditions**, kind-off cancelling them out.

this is, however, not optimal. it's not ideal for small samples or lots of conditions.
![[Pasted image 20250425104623.png]]
- not ideal for small samples, where there arent enough people to average out the effect
- not ideal for lots of conditions (apparently? idk why tho.)

###### counterbalancing (and **latin squares**)
**counterbalanced** designs try to *systematically balance* the order of experiments.

how to counterbalance?
it's impractical to use every unique condition ordering; for n conditions u need n! orders.
instead, you use a **latin square**
- that is an $n\times n$ array where *each symbol occurs only* **once in each row** and **once in each column**
- a practical compromise that produces **n** condition orders such that *each condition appears exactly once in each position in the sequence*

````col
```col-md
flexGrow=1
===
![[Pasted image 20250425105323.png]]

![[Pasted image 20250425105340.png]]
```
```col-md
flexGrow=1
===
![[Pasted image 20250425105333.png]]

![[Pasted image 20250425105352.png]]
```
````

## lecture summary
experiment design includes identifying **independent** and *dependent* variables
- things you **control**; things you *measure*.

a good experiment should be fair and generalisable
- in order to support *valid* **causal inference**

note: a good experiment should also be **valid**
- see future lecture [[lecture 5#task validity]]

experiments are commonly either
- within-subjects - each participant experiences every condition
- between-subjects - each group of participants experiences one condition

between-subject designs are subject to order effects.
most notably learning effects when using humans.
- randomisation or latin squares can counterbalance order effects.