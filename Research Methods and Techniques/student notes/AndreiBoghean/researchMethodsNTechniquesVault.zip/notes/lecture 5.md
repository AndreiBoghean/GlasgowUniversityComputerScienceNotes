experiment design dictates *how* data will be collected
- aim to test the predictions in a way that is **fair**, **generalisable**, and **valid**

## building an experiment
### experimental validity
the **validity** of an experiment relates to whether it *credibly* achieves it's **aims**.

of course, experiments aim to be **controlled**
- (see [[lecture 4#controlled experiment design]])
but *they also want* **generalisability**.
- (see [[lecture 4#experiment design for usefulness (generalisability)]])

this is a contradiction, because they try to both control the random world
but also be applicable to it.

as such, not all such experiment designs lead to **correct** and **applicable** *conclusions*

##### the concept of validity
##### types of validity
###### internal validity
is it valid to *infer* a **causal** relationship between the *independent* and **dependent** variables?
- e.g. does the experiment design *support the conclusion*?
###### external validity
is it valid to *generalise* findings from ur experiment to another context or population?
- e.g. *generalise* to a **different sample** or a **different task**?
###### ecological validity
is it valid to *extrapolate* the findings to **authentic** application contexts?
- e.g. does this example reasonably **represent** the real world?
###### external vs ecological validity
*external* : *any* **other** contexts | *ecological* : **realistic** contexts

### controlling for experiment environment (lab-based / wild)
suppose your experiment relates to a particular environment e.g. an airport
should you execute it in the lab? or in an actual airport?
- this is the difference between **lab-based** or **in-the-wild**

**lab-based** - better *control*, but less ecological validity
- *less* **variability and unpredictability**; *less* **authenticity**.
- (though your design can still make a good effort on external validity)

**in-the-wild** - better *ecological validity*,but less control
- *more* **variability and unpredictability**; *more* **authenticity**.

a controlled study may *try* to replicate ==authentic== scenarios
- more realistic setting? make prototype system authentic? task comparable to a real one? do the participants face demands similar to the real ones?
#### experiment environment examples
````col
```col-md
flexGrow=1
===
##### experiment environment example 1
![[Pasted image 20250425174333.png]]
##### experiment environment example 3
![[Pasted image 20250425174410.png]]
```
```col-md
flexGrow=1
===
##### experiment environment example 2
![[Pasted image 20250425174351.png]]
##### experiment environment example 4
![[Pasted image 20250425174424.png]]
```
````
### experiment tasks
an **experiment task** is simply *one instance* of the "event" being observed.
- this is transient across IV levels.
- e.g. process this image. carry out this action sequence. classify this input.

at minimum, there must be one task per **condition**.
- so that you can actually measure any dependent variables on a condition.
but most experiments typically have *multiple tasks* per **condition**.
- taking average across **n** tasks reduces the effect of *outliers* for reliable data.
- allows for *natural variability* across task instances.
#### task validity
for a valid task, you must consider:
- **internal** - does data from this task address the *research question*?
- **external** - do findings from this task tell us about *other* tasks?
- **ecological** - are these findings *practically realistic*?
#### task abstraction
sometimes, experiment control necessitates **abstraction**.
- e.g. to manipulate *independent variables* in an **abstract task**.
- e.g. to limit **confounding factors**.
abstract tasks help **generalise**:
- systematically investigate input performance in a generic interface to extrapolate to *any* user interface design.
````col
```col-md
flexGrow=1
===
![[Pasted image 20250425182426.png]]
```
```col-md
flexGrow=1
===
![[Pasted image 20250425182438.png]]
```
````
### experiment samples
###### sample terminology and explanation
````col
```col-md
flexGrow=1
===
**subject**: entities in an experiment, e.g. people/images
**population**: the set of all subjects e.g. all people / all images
**sample**: the set of subjects in an experiment
```
```col-md
flexGrow=2
===
![[Pasted image 20250425182609.png]]
```
````
#### sample validity
**david hume's problem of induction** asks whether there is *uniformity of nature*.
- i.e. is the unobserved "the same as" the observed?

this can be extended to sample selection to ask:
- is your sample **representative** of the *unobserved*? (externally valid)
- is your sample **representative** of *practice*? (ecologically valid)

if the sample is not representative, we cant draw conclusions.
![[Pasted image 20250425183556.png|400]]
the sample should aim to have the same characteristics as the population.
##### practicality
in sample validity, there is generally a **tradeoff** between *validity* and *practicallity*.
- difficulty of accessing "more relevant" participants
- safeguarding potentially vulnerable participants

you should generally consider the current research process in the area.
- is the general research around mature enough to the point where your own experiment may be reasonably expected to test with a "more valid" sample than what you're currently considering?
- e.g. with [[#sample validity example 1]] below, it was part of a larger project area, and worked with many impaired children across 4 countries.
  a "less valid" sample made sense, specifically because on such a scale you **couldnt be strict with the participants, because you're trying to get as many as possible**.
##### examples
````col
```col-md
flexGrow=1
===
###### sample validity example 1
![[Pasted image 20250425183651.png]]
```
```col-md
flexGrow=1
===
###### sample validity example 2
![[Pasted image 20250425183701.png]]
```
````
##### sample validity summary
you should consider validity during experiment design.
- will the design allow you to *answer your hypotheses*? (**internal**)
- could your results *generalise* beyond the experiment? (**external**)
- do your results *apply to realistic scenarios*? (**ecological**)

validity is **continuous**; not discrete.
- there is no threshold where an experiment suddenly becomes valid
- there is no perfectly valid experiment. there are always tradeoffs

validity needs to be *balanced* against **fairness** and **generalisability**
- all while being **practical** so you can actually do it.
#### sample size (by extension **statistical power**)
how large should the sample size be?
- too homogeneous of a sample **lacks variability** and then means *bad representation*

sample size has implications for ==inferential statistical analysis==.
- lack of statistical power -> failing to recognise an existing effect
	  - known as- too homogenenous of a sample lacks variability and then means bad representation a **==type II error==**, or a false negative error

we use experiments to test our hypotheses,
but **statistical power indicates whether your conclusion is correct or not**.
##### statistical power
statistical power is the **probability** that you've detected an existing effect.
as statistical power increases, the probability of a type II error decreases.
- **low** power strongly suggests *your experiment **failed*** to detect the effect
- **high** power strongly suggests *your experiment **succeeded*** in detection.

statistical power is ==indicated== by **power analysis**, and depends on
	1. a statistical test, 2. sample size, and 3. the data.
it helps you estimate the "*necessary*" **sample size**
- in practice, the ideal sample size should be *balanced with practicality*

**statistical power is determined by**
1. factors you *control* (experiment design, sample size, etc.)
2. factors you **dont** *control* (effect size)

a larger sample size **increases statistical power**
and increases likelihood your sample size is **representative**
but you must balance against practicality
- note: humans (your payroll) are finite, but machines will do everything you ask; can throw as much at them as you feel like it so go ham on algorithms (storage and time permitting).
###### statistical power example (with **t-test**)
this test tests if two conditions have significantly different **mean values**
- e.g. comparing **task completion times** for two *input techniques*
- e.g. comparing **transcription time** for two *speech transcription algorithms*

considering a hypothetical experiment with 100 subjects,
comparing data from two conditions using this t-test,
with effect sizes ranging from 0.1 (weak) to 0.9 (strong)
- cohen's effect size for t-test is: ratio of standard deviations between conditions
![[Pasted image 20250425185401.png|500]]
- notice that as the experiment varies into ones with more prominent effect sizes,
  the statistical power of the experiment increases.
##### statistical power threshold myth
a student may ask themselves how many participants are needed..
however there is no "*threshold*" where **your experiment suddenly becomes valid**.
![[Pasted image 20250425190143.png]]
##### local standards
when using humans, recruit as many as practical
- ideally at least 15-20 people
but be consistent with "local standards" in the field.
- how many participants are there in *existing similar studies*?

analysis of papers at CHI 2014 found:
- sample size ranged from 1to 916,000 participant
- most commonly 12, median of 18.
#### experiment samples summary
experiments are conducted on *samples* of a **population**.
- not practical to recruit the population.

a sample should be **representative** of the population.
- so that we can *generalise* our findings beyond the sample.

**ideal sample size** is a difficult question; power analysis aims to give a systematic *estimate*.
- ==at minimum, aim to match "local standards"==.
### checklist for experiment design
1. start with **research questions / hypotheses**
2. identify **independent variables**
	   - identify the *conditions* arising from the IVs
3. identify **dependent variables**
	   - what needs to be *measured? how?*
4. outline the **experimental process**
	   - experiment *tasks*, *objects*, *artefacts*, etc.
	   *- consider target sample size*
5. sus out **confounding factors**
	   - any *control variables*?
### lecture summary
scientific experiments test predictions made by hypotheses.

do validity:
- **internal** - does data from this task address the *research question*?
- **external** - do findings from this task tell us about *other* tasks?
- **ecological** - are these findings *practically realistic*?

experiments use samples from the population
- samples are not just people; can be digital (audio, datasets, images)
- strive to choose a **representative** sample
- be conscious of the *implications* of **sample size** on validity