### statistical tests
hi there r multiple statistical tests.
they all calculate *==test statistics==* from data
- t-test calculates the **t statistic** (ratio of difference to variability)
- ANOVA calcutes the **F statistic** (ratio of variance across groups)
- Wilcoxon test calculates the **W statistic** (sum of ordinal ranks)

each such statistical test has a null and alternative hypothesis.
- t-test: no difference/significant difference between the *two group means*
- ANOVA: no difference/significant difference between **at least two** *group means*

#### choosing a test
statistical tests are just functions *you can throw at **any** numbers*;
*for them to work*, they require you throw them at the **correct data, in the correct way**.
- **nothing stopping you from misusing them if you're dumb.**
	  - *not aggregating repeated measures*, *improper outlier handling*, *incorrect model params*
- the *t-test also wont let you know if you should be using wilcoxon* istead.


thus it's important to know how to choose and use tests correctly
though it's not strictly necessary you *understand* the test you're using.
- you do still need to be able to justify your methods.

##### choosing a test - assumptions (i.e. parametric vs non-parametric)
some statistical tests make **assumptions** about the data.
- e.g. many assume a normal distribution.
- you could *check you've got a normal distribution* either with a **shapiro-wilk test**,
  or by **visualising the distribution**.
![[Pasted image 20250427123138.png|400]]

##### choosing a test - big flowchart
![[Pasted image 20250427123915.png]]

##### choosing a test - parametric vs non-parametric
###### definition of parametric vs non-parametric
**parametric** tests make assumptions about the *data distribution*.
- e.g. assumes data is from a normal distribution, poisson distribution, etc.

**non-parametric** tests do *not* make assumptions about data.
- data is often **ranked**, then then ranks are analysed.

most *parametric* tests have a **non-parametric** equivalent.
- e.g. choose *t-test* or **wilcoxon signed-rank test** when comparing two groups
- e.g. choose *ANOVA* or **friedman's test** when comparing more than two groups

###### parametric *vs* on-parametric
*parametric* tests are usually used for *continuous* data.
- e.g. processing time, F1 score, task completion time

there is a lack of consensus for how to handle **ordinal** data.
- e.g. survey scale ratings, which dont need some of the needed assumptions for parametric tests.
- **many researchers use parametric anyways**. (it's *probably* valid? says some source)

##### summary on choosing tests
there are many statistical tests.
- they can be used to calculate *test statistics* such as the **p-value**
- each test has it's own **null** and **alternative** hypothesis
- different tests can make their own assumptions which you need to be aware of.

there are different tests for repeated-measures and independent-measures.
- your **dependent variables** imply your choice of (non-)parametric tests.
#### running statistical tests
commonly done in
**python+jupyter**
- maybe using pandas, numpy, matplotlib, seaborn, scipy, scikit learn, pinguin
**R+Rstudio**
- idk it's just a screenshot of an IDE
**JASP**
- lecture slides refuse to elaborate

##### examples
###### simulated experiment example 1
suppose you're comparing two algorithms to see if one is faster.
- IV: the algorithm
- DV: processing time
- sample: 1000 sets of input data
- task: running the algorithm with the given input data
- analysis: repeated-measures t-test

hypotheses:
- $H_{0}$: there's no difference between the **mean processing times**
- $H_{A}$: there's a *significant* difference between the **mean processing times**

````col
```col-md
flexGrow=1
===
summary statistics show the mean times are 2019ms and 2135ms
```
```col-md
flexGrow=1
===
![[Pasted image 20250427133827.png|150]]
```
````
````col
```col-md
flexGrow=1
===
an exploratory distribution plot shows the distribution of execution time.
algorithm 1 **looks** *mainly* faster, but this is not convincing evidence for a meaningful difference.
```
```col-md
flexGrow=1
===
![[Pasted image 20250427134029.png|200]]
```
````

since we have a normal distribution and two groups, we can use a t-test.
we're told $p=4.214\dots e-41$.
with a p value of less than 0.001, we can then safely reject $H_{0}$
therefore the data supports $H_{A}$, that there is meaningful difference between algs.

###### simulated experiment example 2
suppose you're comparing three interface designs in terms of task time
- IV: the interface
- DV: the task time
- sample: 20 participants who've learned each design already.
- task: doing something with the user interface
- analysis: repeated-measures analysis of variance

hypothesis:
- $H_0$: there is no difference between the interfaces
- $H_{A}$: there is a significant difference between at least two user interface designs

our testing environment tells us:
````col
```col-md
flexGrow=1
===
![[Pasted image 20250427140424.png]]
```
```col-md
flexGrow=1
===
![[Pasted image 20250427140432.png]]
```
````
since we're using repeated measures on more than two groups, we use ANOVA.
````col
```col-md
flexGrow=1
===
![[Pasted image 20250427140506.png]]
```
```col-md
flexGrow=1
===
![[Pasted image 20250427142610.png]]
```
````
we get a p value of 0.009, which allows us to reject $H_{0}$,
which subsequently **suggests a significant difference between two group means**.
- but.. *which groups is that?*

we need a ==post-hoc pairwise comparison== to find out.
we have three conditions, which pair like A:B, A:C, B:C
we can then run a pair-wise comparison for each of these.
- i.e. we t-test for each combination.
![[Pasted image 20250427140704.png]]
this then tells us numbers. what do the numbers mean mason?
![[Pasted image 20250427150420.png|500]]

##### post-hoc procedure
multi-group tests like ANOVA indicate the *presence* of a difference,
but dont indicate **what** the difference is.

if (and only if) there exists a significant difference,
you can perform post-hoc pairwise comparisons.

use **p-value** *correction* for multiple comparisons (if appropriate)
- e.g. we applied bonferroni correction for 3 comparisons in e.g. 2 above.
- sometimes this may be done automatically

if there's no significant difference, you cannot do post-hoc tests
- nothing stopping u, but it's just illogical to do so.

##### factorial analysis (and interaction effects)
our previous examples had a **single** *IV*.
- i.e. two conditions (t-test) or three conditions (ANOVA)

but what if we have **multiple** *IVs*?
- e.g. image recognition algorithm (A, B) x pre-processing (True, False)
  giving 2x2 = 4 different possible conditions

we'd want to investigate:
- if the algorithm affects recognition performance
- if pre-processing affects recognition performance

we could do that with *factorial analysis*.
- basically lets u investigate the impact from **each factor**, and whether there's an  **interaction effect**

###### interaction effects
this is basically when different factors in an experiment can potentially interact.

if we use ANOVA to investigate the effect of each of a factor, we may get
1. the "**main effect**" of algorithm (A, B) on our *dependent variable*
2. the "**main effect**" of pre-processing (True, False) on our *dependent variable*
3. the "**interaction effect**" between *algorithm* and *pre-processing*

we can then use the p-value to determine which **main effects** are *significant*.
- and follow up with post-hoc pairwise comparisons if appropriate

==however== this is where ==interaction effects may come in==.
- **algorithm B may only be better than A** when *pre-processing is False*.
![[Pasted image 20250427153408.png|400]]

##### summary on running statistical tests so far
focus on basic principles of null-hypothesis significance testing
- most tests are based on the idea of **falsifying the null hypothesis of no effect**.
- (^ consequently implying that there *is* an effect)

##### poor statistical practice
there is a natural desire to avoid "negative results" e.g. where p >= 0.05
- more difficult to publish (*positive outcome bias*)

hence bad practice can arise in pursuit of positive results.
- manipulating or fabricating data
- misusing or misinterpreting p-values (a.k.a **p-hacking**; *try different stuff until p <= 0.05*)
- **HARKing**: hypothesising after results are known (*changing hypotheses to suit the data*)

###### this could be combated by:
a drive towards improved statistical transparency
- making it easier for others to check your work

registered reports : pre-registered experiment and analysis
- *peer review papers **before** the experiment begins*
- reduces the desire to abuse analysis to avoid "negative results"

increased scrutiny of published results

##### overall analysis process
1. design experiment and analysis
	   - implicitly aligned - your hypotheses map to the test hypotheses.
2. pilot test the experiment
	   - confirm data is usable - test your analysis
3. run the experiment
	   - check up on the data occsaionally - make sure there are no problems
4. exploratory visualisation
	   - get a sense of what data "looks like" - differences, patterns, trends
5. run the planned statistical tests
	   - using post-hoc tests, only where appropriate
6. interpret the results and write up your findings
	   - following the expectations for transparent statistics

#### overall summary on statistical tests
statistical tests have **their own** *hypotheses* and *assumptions*
- your experiment design and data *imply the appropriate tests*
- *your hypotheses* need to be **aligned** with those of the *tests*
  (you cant reach conclusions if the test methodology doesnt support them)
- be able to justify the analysis methods used in your work

be aware of proper analysis process
- some tests give *straightforward* answers, **others need** *post-hoc tests*
- **be careful interpreting** *main effects* if there is an *interaction effect*
- play by the "rules" of null-hypothesis significance testing.