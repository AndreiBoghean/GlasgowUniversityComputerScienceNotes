## qualitative research
#### what is it?
qualitative research investigates the aspects of a research topic that cannot be necessarily quantified in numbers.
- e.g. *subjective* **human** opinion, behaviours, emotions, experience, social factors, etc.
##### examples of qualitative data
*software engineering*
- ethnographic observation of teams to understand working practices
- interviews with software developers for their perspectives
- analysis of version control use (commit logs, branch use, etc.)

*human-computer interaction*
- interview participants to try to understand their mental models?
- observing users to see how they currently do things?
- focus group discussions with domain experts to get requirements?

*computing science education*
- interview students about their current understanding of a topic?
- observe teachers to identify aspects of their teaching practice?
- student focus groups to discuss their reflection and revision habits?

these are just examples. *qualitative* and *mixed method* approaches are used **across all** of CS.
### qualitative research is subjective
qualitative research is inherently *subjective* in nature.
this is because **analysis is based on the researcher**'s *interpretations* and *judgements*
- researchers can have their own beliefs, opinions, perspectives, and values.
- people *naturally have prejudices*. these affect **how they see the research problem**.
### biases
#### what biases are there in types of research
##### qualitative bias
qualitative research is potentially subject to **bias**
- **==confirmation==** bias - favouring interpretation that fits *hypothesis*
**==reflexivity==** bias - favouring the interpretation that fits *beliefs, culture, etc.*

aside: qualitative research isnt biased?
- "All research involves subjectivity and interpretation, both qualitative and quantitative. Facts aren’t self-generating or self-interpreting. Rigour in qualitative research is being reflexive and making clear the how and why of your research processes.”

regardless, **qualitative bias is not typically an issue**.
it's just important to highlight that the researchers are highly involved.
- this degree of involvement may actually be a good thing - connections, empathy, etc.
##### quantitative bias?
quantitative research is a more *objective* process.
- i.e. a systematic process, following rules, e.g. NHST.
however still subject to *bias* and **misuse**, since the researchers are still *interpreting* the **results**.

if you try to establish "objective" research criteria, you may start using **questionable research practices**, e.g. trying to *manufacture a "good" p-value for significance*, or *changing hypotheses to fit the data*

#### dealing with biases (mixed-methods research)
##### mixed methods research
using both **qualitative** *and* **quantitative** is known as "mixed methods" research.
it benefits from the *relative strengths* of each approach.
- quantitative: objective rigour, measurement
- qualitative: context, insight, exploration

the combination can give richer insights than each method alone.
##### mixed methods research - validation
when using mixed methods, you can use what you've found to provide relatively **stronger** *validation for your findings*.
- e.g. qualitative interview comments that support quantitative measured data.

you can increase ***internal** validity* using qualitative data to support quantitative results
you can also increase ***ecological** validity* demonstrating the real-world context of ur results.
##### mixed methods research - benefits
###### explanations / direct justifications of qualitative data.
you can use your **qualitative *insight*** to help "*explain*" **quantitative** results.
- e.g. can *participant perspectives* explain why **input technique A was faster** than B?
- e.g. can *survey responses* explain why participants **preferred interacting with LLM A?**
- e.g. can *analysis of annotated images* explain why some image processing algorithm **detected on-road hazards more accurately?**
###### perspectives / an alternative closer more detailed look
**qualitative data** can give a *different perspective* on **quantitative results**
- e.g. 2 input methods with **similar task times** where *one was more disliked* because of **more focus required**
- e.g. 2 code review methods that **identify a similar number of bugs** but where one leads to *increased tension between team members*.

quantitative data can be hard to find in an easy format.
- not everything can be quantified.
- qualitative methods can **help uncover the bigger picture**.
### collecting qualitative data
qualitative data comes in many forms from many sources.
some common data collection methods are:
- surveys
- interviews/focus groups
- observation notes
#### possible sources
##### survey design
- ensure questions **measure** the concepts you intend to measure.
	  - could answers to this *tell me what I want* it to?
- ensure questions are **not ambiguous**.
	  - will all *participants know what this means*?
- ensure questions are **neutral** and **non-leading**
	  - *could this question bias participant*s towards a certain response?
##### interview design
- plan an interview *structure* with important and relevant questions.
- be **reflexive** to what participants are saying
	  - *deviate from the structure* for **interesting comments** ("semi-structured interview")
	  - if unanticipated but **interesting topics arise**, ask *future participants too*
- ask *neutral* questions, do not make *assumptions*, avoid *leading questions*
#### analysing qualitative data / **coding** of qualitative data
how do you analyse predominantly *text-based* data? well, you categorise it basically.
##### what it is
==**qualitative** coding== is the process of assigning **codes** to portions of text data.
**codes** are *labels* that identify some kind of *thematic categorisation*

**coding** gives a variety of *insights*
- codes themselves identify *common themes* in the data
	  - e.g. what advantages of this input technique did participants talk about?
- code *counts* ==quantify== **prevelence**
	  - e.g. which interaction issues and misunderstandings were raised most often?
- looking at **coincidence** and **interaction** between codes
	  - e.g. how often do these two codes occur together?
##### approaches for it
###### deductive coding
when you have already identified the codes **before** *analysis begins*
- e.g. assigning codes taken from an **established framework**, **model**, or **hypothesis**
###### inductive coding
when you identify the codes **during** *analysis*.
- i.e. identifying codes and modifying codes as you discover a need for them

this is **responsive** and **organic**
- i.e. being open to what the data "says" rather than imposing beliefs on it.
###### in vivo coding
a kind of *inductive coding* where codes are **direct quotes**
- i.e. labelling the data using ==participants' own words==
##### the iterative process
regardless of how you get your codes, coding is an iterative process.
- especially so in inductive coding.

coding iterations (as used in *grounded theory*):
**open coding** : initial *labelling* of text

**axial coding** : *structuring* codes into *broader themes*
- e.g. by identifying similarities or **connectedness between codes**

**selective coding** : focusing on the *most important* codes
- e.g. *another iteration* focusing on applying a **subset of the most important codes**.
##### how to "execute" qualitative coding
there are many ways to "do" coding.

an example process may follow:
1. **formalise** the approach - write the *methods* section of your paper.
2. **familiarise** yourself with the data - e.g. *read a few transcripts*
3. **open coding** - go through data and *identify initial codes*.
4. **axial coding** - *restructure* codes into key themes, *discuss* with team.
5. **selective** coding - do *another pass* (if needed)
6. **analysis** - e.g. look at *prevalence*, *identify themes*, *review coded text*
7. **writeup** - write your *interpretation* of the coded data; *what does it mean*?
##### qualitative coding examples
###### **method** example
"We coded transcripts … using the ***constant comparative*** method to identify and develop themes in the transcripts. After an *initial round* *of coding*, these were **structured into the higher-level themes** discussed later.”
basically, these guys just done *open coding* and then **axial coding**
- ***constant comparative***: comparing related text to *identify connections* and *suitable labels*
###### **codes** example
these guys identified and assigned 10 codes within 2 categories to several hours of interview discussions with 32 participants.

````col
```col-md
flexGrow=1
===
clutch interractions
![[Pasted image 20250427211947.png]]
voice, gesture, gaze, active zone
```
```col-md
flexGrow=1
===
touchless interaction
![[Pasted image 20250427211957.png]]
integration with clinical workflow, fatigue and cognitive load, benefits of sterility for clinical use, hospotal environment, adoption by medical professionals, clinical applications of touchless
```
````
###### **presenting** example
````col
```col-md
flexGrow=1
===
we used the codes to structure discussion in the paper. we used **prevalent themes** and *points relating to each code*. used lots of **exemplary quotes** to help explain what we meant and *increase credibility*.
```
```col-md
flexGrow=1
===
![[Pasted image 20250427212631.png]]
```
````
###### **presenting** example 2
**section headings** identified *key themes* arising from the **axial coding** process.
we directly attributed our interpretations to participants.
- this provides transparency about prevalence. without this, there's no way of knowing if all N=20 said this, or (as is the  case here), only N=5.

##### qualitative coding - teamwork coordination example
one way to execute coding in a team would be by
1. having the *lead researcher* carry out **open coding** (creating the codes)
2. **axial coding** (sorting codes into themes/groups) by the *whole team*
and then **iteratively adjusting** according to *disagreements*.
- *themes* with **two or more overlapping codes** were **reassessed and combined** where necessary.
##### qualitative coding reliability
**reliability** concerns the *validity* with which codes are applied.
- i.e. are ==codes being applied accurately and consistently==?

**inter-code** reliability
- how *consistently* are codes applied by *multiple people*?
- especially important if *coding is distributed* across the research team.

**intra-code** reliability
- how *consistently* are code applied by *one person*?
- can be assessed by ==repeat coding== - were codes used **consistently each time**?

### qualitative research summary
qualitative research provides **context**, **explanation**, **insights**
- often complementary to *qualitative* findings (i.e. *mixed methods*)

qualitative "data" is **non-numerical**, predominantly **text-based**
- e.g. interview transcripts, survey responses, observation notes.

qualitative ==coding== is *the process* of **applying meaningful labels**
- structured concepts that *describe* **meaning** in the data.
- an iterative process based on *refinement* and *reliability*
- part of **deriving insight** from data, e.g. through *key themes*.